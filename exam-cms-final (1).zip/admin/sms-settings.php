<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  if(($_POST['act']??'')==='save'){
    Settings::set('kavenegar_apikey', trim($_POST['apikey']??''));
    Settings::set('kavenegar_sender', trim($_POST['sender']??''));
    Settings::set('kavenegar_template', trim($_POST['template']??''));
    Settings::set('sms_enabled', isset($_POST['sms_enabled'])?'1':'0');
    Settings::set('otp_validity_minutes', max(1,(int)($_POST['otp_validity_minutes']??60)));
    Settings::set('otp_resend_seconds', max(30,(int)($_POST['otp_resend_seconds']??120)));
    $_SESSION['flash']=['success','تنظیمات پیامک ذخیره شد.'];
  } elseif(($_POST['act']??'')==='test'){
    $m=fa2en(trim($_POST['test_mobile']??''));
    if(valid_mobile($m)){ $r=Kavenegar::send($m,'پیام آزمایشی از '.setting('site_name','پورتال')); $_SESSION['flash']=[$r['ok']?'success':'error', $r['ok']?'پیام آزمایشی ارسال شد (یا شبیه‌سازی شد).':'ارسال ناموفق بود؛ لاگ را بررسی کنید.']; }
    else $_SESSION['flash']=['error','شماره موبایل آزمایشی معتبر نیست.'];
  }
  header('Location: sms-settings.php'); exit;
}
$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$active='sms-settings'; $heading='تنظیمات پیامک';
require __DIR__.'/_header.php';
?>
<?= flashbox($flash ?? null) ?>
<div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
  <div class="card-modern p-6">
    <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-comment-sms text-blue-500 ml-1.5"></i>سرویس کاوه‌نگار</h3>
    <form method="post" class="space-y-4">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="save">
      <div><label class="block font-bold text-xs text-gray-700 mb-1.5">API Key</label><input name="apikey" class="input-modern" dir="ltr" value="<?= htmlspecialchars(setting('kavenegar_apikey','')) ?>" placeholder="کلید API کاوه‌نگار"></div>
      <div><label class="block font-bold text-xs text-gray-700 mb-1.5">شماره ارسال‌کننده</label><input name="sender" class="input-modern" dir="ltr" value="<?= htmlspecialchars(setting('kavenegar_sender','')) ?>" placeholder="مثال: 10004346"></div>
      <div>
        <label class="block font-bold text-xs text-gray-700 mb-1.5">نام تمپلیت (Verify Lookup)</label>
        <input name="template" class="input-modern" dir="ltr" value="<?= htmlspecialchars(setting('kavenegar_template','')) ?>" placeholder="مثال: verify-login">
        <p class="text-[11px] text-gray-400 mt-1.5 leading-relaxed text-justify">اگر این فیلد را پر کنید، کد تأیید از طریق <b>تمپلیت تأییدیه‌ی کاوه‌نگار</b> (Verify Lookup) ارسال می‌شود — روش پیشنهادی و بدون مشکل برای کد یک‌بارمصرف. در تمپلیت کاوه‌نگار باید یک پارامتر <span dir="ltr">%token</span> داشته باشید. اگر خالی بماند، پیامک متنی معمولی با خط ارسال‌کننده فرستاده می‌شود.</p>
      </div>
      <label class="flex items-center gap-2 text-sm font-bold text-gray-600 bg-gray-50 rounded-lg px-3 py-2.5 border border-gray-100">
        <input type="checkbox" name="sms_enabled" <?= setting('sms_enabled','0')==='1'?'checked':'' ?>> فعال‌سازی ارسال پیامک واقعی
      </label>
      <p class="text-[11px] text-gray-400 leading-relaxed">اگر این گزینه غیرفعال باشد، سیستم در «حالت شبیه‌سازی» کار می‌کند: پیامکی ارسال نمی‌شود و کد OTP برای تست در صفحه ورود نمایش داده می‌شود.</p>
      <div class="grid grid-cols-2 gap-3 pt-2 border-t border-gray-100">
        <div><label class="block font-bold text-xs text-gray-700 mb-1.5">اعتبار OTP (دقیقه)</label><input type="number" name="otp_validity_minutes" min="1" class="input-modern" dir="ltr" value="<?= (int)setting('otp_validity_minutes',60) ?>"></div>
        <div><label class="block font-bold text-xs text-gray-700 mb-1.5">فاصله ارسال مجدد (ثانیه)</label><input type="number" name="otp_resend_seconds" min="30" class="input-modern" dir="ltr" value="<?= (int)setting('otp_resend_seconds',120) ?>"></div>
      </div>
      <button class="w-full py-3 rounded-xl bg-primary text-white font-bold text-sm hover:bg-blue-800 transition"><i class="fa-solid fa-floppy-disk text-xs ml-1"></i> ذخیره تنظیمات</button>
    </form>
  </div>
  <div class="card-modern p-6 h-fit">
    <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-paper-plane text-emerald-500 ml-1.5"></i>ارسال آزمایشی</h3>
    <form method="post" class="space-y-3">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="test">
      <div><label class="block font-bold text-xs text-gray-700 mb-1.5">شماره موبایل</label><input name="test_mobile" class="input-modern tabular-nums" dir="ltr" placeholder="09xxxxxxxxx"></div>
      <button class="w-full py-2.5 rounded-xl bg-emerald-500 text-white font-bold text-sm hover:bg-emerald-600 transition">ارسال پیام آزمایشی</button>
    </form>
    <div class="mt-4 bg-blue-50/50 border border-blue-100 rounded-xl p-3 text-[11px] text-gray-600 leading-relaxed">
      <i class="fa-solid fa-circle-info text-blue-500 ml-1"></i> برای مشاهده‌ی نتیجه و وضعیت ارسال‌ها به بخش «لاگ پیامک‌ها» مراجعه کنید.
    </div>
  </div>
</div>
<?php require __DIR__.'/_footer.php'; ?>
