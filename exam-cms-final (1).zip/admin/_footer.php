    </main>
  </div>
</div>
<script src="<?= asset('assets/js/app.js') ?>"></script>
<script>
function toggleSidebar(open){
  var sb=document.getElementById('sidebar'), bd=document.getElementById('sb-backdrop');
  if(open===undefined) open = sb.classList.contains('translate-x-full');
  sb.classList.toggle('translate-x-full', !open);
  bd.classList.toggle('hidden', !open);
}
</script>
</body>
</html>
