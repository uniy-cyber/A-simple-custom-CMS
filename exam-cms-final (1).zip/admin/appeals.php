<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();
$now = ServerTime::now();

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  $id=(int)($_POST['id']??0);
  $act=$_POST['act']??'';
  if ($act==='reply') {
    $reply=trim((string)($_POST['admin_reply']??''));
    $status=in_array($_POST['status']??'',['pending','accepted','rejected'],true)?$_POST['status']:'pending';
    DB::q("UPDATE appeals SET admin_reply=?, status=?, replied_at=? WHERE id=?", [$reply!==''?$reply:null,$status,$now,$id]);
    $ap = DB::one("SELECT ap.student_id, c.title FROM appeals ap JOIN courses c ON c.id=ap.course_id WHERE ap.id=?", [$id]);
    if ($ap) notify_student((int)$ap['student_id'], 'پاسخ به اعتراض درس «'.$ap['title'].'»', 'وضعیت/پاسخ اعتراض شما به‌روزرسانی شد. برای مشاهده به کارنامه مراجعه کنید.', 'appeal');
    $_SESSION['flash']=['success','پاسخ اعتراض ثبت شد.'];
  } elseif ($act==='delete') {
    DB::q("DELETE FROM appeals WHERE id=?", [$id]);
    $_SESSION['flash']=['success','اعتراض حذف شد.'];
  }
  header('Location: appeals.php'); exit;
}

$filter=$_GET['status']??'';
$where = in_array($filter,['pending','accepted','rejected'],true) ? "WHERE ap.status='".$filter."'" : "";
$appeals = DB::all(
  "SELECT ap.*, st.first_name, st.last_name, st.student_id, c.title AS course_title,
          e.grade
   FROM appeals ap
   JOIN students st ON st.id=ap.student_id
   JOIN courses  c  ON c.id=ap.course_id
   LEFT JOIN enrollments e ON e.student_id=ap.student_id AND e.course_id=ap.course_id
   $where
   ORDER BY (ap.status='pending') DESC, ap.created_at DESC");

$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$active='appeals'; $heading='اعتراض به نمره';
require __DIR__.'/_header.php';
function gFmt2($g){ if($g===null) return '—'; $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,rtrim(rtrim(number_format((float)$g,2,'.',''),'0'),'.')); }
$stt=['pending'=>['در حال بررسی','bg-amber-50 text-amber-600 border-amber-200'],'accepted'=>['پذیرفته شد','bg-emerald-50 text-emerald-600 border-emerald-200'],'rejected'=>['رد شد','bg-red-50 text-red-500 border-red-200']];
?>
<?= flashbox($flash ?? null) ?>

<div class="flex items-center gap-2 mb-4 text-xs font-bold flex-wrap">
  <?php $tabs=['' =>'همه','pending'=>'در حال بررسی','accepted'=>'پذیرفته','rejected'=>'رد شده']; foreach($tabs as $k=>$lbl): ?>
    <a href="appeals.php<?= $k?('?status='.$k):'' ?>" class="px-3 py-1.5 rounded-lg transition <?= $filter===$k?'bg-primary text-white':'bg-white text-gray-500 border border-gray-100 hover:bg-gray-50' ?>"><?= $lbl ?></a>
  <?php endforeach; ?>
</div>

<?php if(!$appeals): ?>
  <div class="card-modern p-8 text-center text-sm text-gray-400"><i class="fa-solid fa-gavel text-2xl mb-2 block"></i>اعتراضی یافت نشد.</div>
<?php else: foreach($appeals as $a): $s=$stt[$a['status']]??['نامشخص','bg-gray-100 text-gray-500 border-gray-200']; ?>
  <div class="card-modern p-5 mb-4">
    <div class="flex items-start justify-between gap-3 flex-wrap mb-3">
      <div class="min-w-0">
        <p class="font-extrabold text-sm text-gray-800"><?= htmlspecialchars($a['first_name'].' '.$a['last_name']) ?> <span class="text-[10px] text-gray-400 tabular-nums" dir="ltr"><?= htmlspecialchars($a['student_id']) ?></span></p>
        <p class="text-[11px] text-gray-500 mt-1"><i class="fa-solid fa-book text-blue-400 text-[10px] ml-1"></i><?= htmlspecialchars($a['course_title']) ?> — نمره فعلی: <span class="font-extrabold text-gray-700 tabular-nums"><?= gFmt2($a['grade']) ?></span></p>
      </div>
      <div class="flex items-center gap-2 shrink-0">
        <span class="text-[10px] font-bold px-2.5 py-1 rounded-md border <?= $s[1] ?>"><?= $s[0] ?></span>
        <span class="text-[9px] text-gray-300 tabular-nums"><?= jdatetime((int)$a['created_at']) ?></span>
      </div>
    </div>

    <div class="bg-gray-50/70 rounded-xl p-3 mb-3">
      <p class="text-[11px] text-gray-600 leading-relaxed text-justify"><?= nl2br(htmlspecialchars($a['message'])) ?></p>
    </div>

    <form method="post" class="space-y-2">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="act" value="reply">
      <input type="hidden" name="id" value="<?= $a['id'] ?>">
      <textarea name="admin_reply" rows="2" placeholder="پاسخ به دانشجو (اختیاری)..." class="input-modern text-xs" style="text-align:justify;font-weight:500"><?= htmlspecialchars($a['admin_reply']??'') ?></textarea>
      <div class="flex items-center gap-2 flex-wrap">
        <select name="status" class="input-modern text-xs w-40 py-2">
          <option value="pending"  <?= $a['status']==='pending' ?'selected':'' ?>>در حال بررسی</option>
          <option value="accepted" <?= $a['status']==='accepted'?'selected':'' ?>>پذیرفته شد</option>
          <option value="rejected" <?= $a['status']==='rejected'?'selected':'' ?>>رد شد</option>
        </select>
        <button class="px-4 py-2 rounded-xl bg-primary text-white text-xs font-bold hover:bg-blue-800 transition"><i class="fa-solid fa-reply ml-1"></i>ثبت پاسخ</button>
        <a href="grades.php?course=<?= (int)$a['course_id'] ?>" class="px-4 py-2 rounded-xl bg-amber-50 text-amber-600 text-xs font-bold hover:bg-amber-100 transition"><i class="fa-solid fa-pen ml-1"></i>ویرایش نمره</a>
        <span class="flex-1"></span>
      </div>
    </form>
    <form method="post" data-confirm="این اعتراض حذف شود؟" class="mt-2">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $a['id'] ?>">
      <button class="text-[11px] text-red-400 font-bold hover:text-red-600"><i class="fa-solid fa-trash text-[10px] ml-1"></i>حذف اعتراض</button>
    </form>
  </div>
<?php endforeach; endif; ?>
<?php require __DIR__.'/_footer.php'; ?>
