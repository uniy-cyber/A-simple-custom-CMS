<?php require __DIR__.'/../includes/bootstrap.php';
unset($_SESSION['admin_id']);
header('Location: '.base_url('admin/login.php')); exit;
