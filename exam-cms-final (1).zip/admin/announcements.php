<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();

/* پوشه‌ی پیوست اطلاعیه‌ها */
$ANN_DIR = APP_ROOT.'/uploads/announcements';
/* پسوندهای مجاز و سقف حجم هر فایل (مگابایت) */
$ANN_ALLOWED = ['pdf','doc','docx','xls','xlsx','ppt','pptx','zip','rar','7z','jpg','jpeg','png','gif','webp','txt','csv','mp4','mp3'];
$ANN_MAX_MB  = 25;

/* ذخیره‌ی فایل‌های پیوست آپلودشده برای یک اطلاعیه */
function ann_save_files(int $aid, string $dir, array $allowed, int $maxMb): array {
  $errors = [];
  if (empty($_FILES['files']) || !is_array($_FILES['files']['name'])) return $errors;
  if (!is_dir($dir)) @mkdir($dir,0755,true);
  $descs = $_POST['file_desc'] ?? [];
  $maxBytes = $maxMb*1024*1024;
  foreach ($_FILES['files']['name'] as $k=>$nm) {
    $err = $_FILES['files']['error'][$k] ?? UPLOAD_ERR_NO_FILE;
    if ($err === UPLOAD_ERR_NO_FILE) continue;
    if ($err !== UPLOAD_ERR_OK) { $errors[]='خطا در آپلود «'.$nm.'».'; continue; }
    $size = (int)($_FILES['files']['size'][$k] ?? 0);
    if ($size > $maxBytes) { $errors[]='حجم «'.$nm.'» بیش از حد مجاز ('.$maxMb.' مگابایت) است.'; continue; }
    $ext = strtolower(pathinfo($nm, PATHINFO_EXTENSION));
    if (!in_array($ext,$allowed,true)) { $errors[]='نوع فایل «'.$nm.'» مجاز نیست.'; continue; }
    $safe = 'ann'.$aid.'_'.bin2hex(random_bytes(5)).'.'.$ext;
    if (!move_uploaded_file($_FILES['files']['tmp_name'][$k], $dir.'/'.$safe)) { $errors[]='ذخیره‌ی «'.$nm.'» ناموفق بود.'; continue; }
    $desc = trim((string)($descs[$k] ?? ''));
    DB::q("INSERT INTO announcement_files (announcement_id,file_path,original_name,file_size,description,download_count,created_at) VALUES (?,?,?,?,?,0,?)",
      [$aid,'announcements/'.$safe,$nm,$size,mb_substr($desc,0,500),ServerTime::now()]);
  }
  return $errors;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  $act=$_POST['act']??'';
  if ($act==='save') {
    $id=(int)($_POST['id']??0);
    $course_id = ($_POST['course_id']??'')==='' ? null : (int)$_POST['course_id'];
    $title=trim($_POST['title']??''); $body=trim($_POST['body']??'');
    $publish=dt_to_ts($_POST['publish_at']??'') ?? ServerTime::now();
    if ($title===''||$body==='') { $_SESSION['flash']=['error','عنوان و متن اطلاعیه الزامی است.']; }
    else {
      if ($id) {
        DB::q("UPDATE announcements SET course_id=?,title=?,body=?,publish_at=? WHERE id=?",[$course_id,$title,$body,$publish,$id]);
        $msg='اطلاعیه ویرایش شد.';
      } else {
        $id = DB::insert("INSERT INTO announcements (course_id,title,body,publish_at,created_at) VALUES (?,?,?,?,?)",[$course_id,$title,$body,$publish,ServerTime::now()]);
        $msg='اطلاعیه ثبت شد.';
      }
      $errs = ann_save_files($id, $ANN_DIR, $ANN_ALLOWED, $ANN_MAX_MB);
      if ($errs) { $_SESSION['flash']=['error', $msg.' اما برخی فایل‌ها ذخیره نشدند: '.implode(' ', $errs)]; }
      else { $_SESSION['flash']=['success', $msg]; }
      header('Location: announcements.php?edit='.$id); exit;
    }
  } elseif ($act==='delete') {
    $id=(int)$_POST['id'];
    foreach (DB::all("SELECT file_path FROM announcement_files WHERE announcement_id=?", [$id]) as $f) {
      $abs=APP_ROOT.'/uploads/'.$f['file_path']; if(is_file($abs)) @unlink($abs);
    }
    DB::q("DELETE FROM announcements WHERE id=?", [$id]);
    $_SESSION['flash']=['success','اطلاعیه حذف شد.'];
  } elseif ($act==='delfile') {
    $fid=(int)$_POST['file_id']; $aid=(int)$_POST['id'];
    $f=DB::one("SELECT * FROM announcement_files WHERE id=? AND announcement_id=?", [$fid,$aid]);
    if ($f) {
      $abs=APP_ROOT.'/uploads/'.$f['file_path']; if(is_file($abs)) @unlink($abs);
      DB::q("DELETE FROM announcement_files WHERE id=?", [$fid]);
      $_SESSION['flash']=['success','فایل حذف شد.'];
    }
    header('Location: announcements.php?edit='.$aid); exit;
  }
  header('Location: announcements.php'); exit;
}

$edit = isset($_GET['edit']) ? DB::one("SELECT * FROM announcements WHERE id=?", [(int)$_GET['edit']]) : null;
$editFiles = $edit ? DB::all("SELECT * FROM announcement_files WHERE announcement_id=? ORDER BY id", [$edit['id']]) : [];
$courses = DB::all("SELECT id,title FROM courses ORDER BY title");
$list = DB::all("SELECT a.*, c.title course_title,
                   (SELECT COUNT(*) FROM announcement_files f WHERE f.announcement_id=a.id) AS file_count,
                   (SELECT COALESCE(SUM(f.download_count),0) FROM announcement_files f WHERE f.announcement_id=a.id) AS dl_total
                 FROM announcements a LEFT JOIN courses c ON c.id=a.course_id ORDER BY a.publish_at DESC");
$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$now=ServerTime::now();
$active='announcements'; $heading='اطلاعیه‌ها';
require __DIR__.'/_header.php';
?>
<?= flashbox($flash ?? null) ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
  <div class="lg:col-span-1">
    <div class="card-modern p-5 sticky top-20">
      <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-<?= $edit?'pen':'plus' ?> text-amber-500 ml-1.5"></i><?= $edit?'ویرایش اطلاعیه':'اطلاعیه جدید' ?></h3>
      <form method="post" enctype="multipart/form-data" class="space-y-3">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $edit['id']??'' ?>">
        <div><label class="block font-bold text-[11px] text-gray-600 mb-1">درس مرتبط</label>
          <select name="course_id" class="input-modern text-xs">
            <option value="">عمومی (همه‌ی دانشجویان)</option>
            <?php foreach($courses as $c): ?><option value="<?= $c['id'] ?>" <?= ($edit['course_id']??null)==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['title']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div><label class="block font-bold text-[11px] text-gray-600 mb-1">عنوان *</label><input name="title" required class="input-modern" value="<?= htmlspecialchars($edit['title']??'') ?>"></div>
        <div><label class="block font-bold text-[11px] text-gray-600 mb-1">متن *</label><textarea name="body" rows="4" required class="input-modern font-normal leading-relaxed"><?= htmlspecialchars($edit['body']??'') ?></textarea></div>
        <div><label class="block font-bold text-[11px] text-gray-600 mb-1">زمان انتشار</label><input type="datetime-local" name="publish_at" class="input-modern text-xs" dir="ltr" value="<?= ts_to_dt($edit['publish_at']??$now) ?>"></div>

        <!-- پیوست فایل با توضیحات -->
        <div class="pt-1">
          <label class="block font-bold text-[11px] text-gray-600 mb-1.5"><i class="fa-solid fa-paperclip text-amber-500"></i> فایل‌های پیوست</label>
          <div id="ann-files" class="space-y-2"></div>
          <button type="button" id="ann-add-file" class="mt-1.5 w-full py-2 rounded-xl border border-dashed border-gray-300 text-gray-500 font-bold text-[11px] hover:bg-gray-50 transition"><i class="fa-solid fa-plus text-[10px]"></i> افزودن فایل</button>
          <p class="text-[10px] text-gray-400 mt-1.5 leading-relaxed">حداکثر <?= pnum($ANN_MAX_MB) ?> مگابایت برای هر فایل. مجاز: <?= implode('، ', array_slice($ANN_ALLOWED,0,8)) ?> و ...</p>
        </div>

        <div class="flex gap-2 pt-1">
          <button class="flex-1 py-2.5 rounded-xl bg-primary text-white font-bold text-sm hover:bg-blue-800 transition"><?= $edit?'ذخیره':'انتشار' ?></button>
          <?php if($edit): ?><a href="announcements.php" class="px-4 py-2.5 rounded-xl bg-gray-100 text-gray-600 font-bold text-sm">انصراف</a><?php endif; ?>
        </div>
      </form>

      <!-- فایل‌های پیوست فعلی (هنگام ویرایش) -->
      <?php if($edit && $editFiles): ?>
        <div class="mt-5 pt-4 border-t border-gray-100">
          <p class="font-bold text-[11px] text-gray-600 mb-2">فایل‌های پیوست‌شده (<?= pnum(count($editFiles)) ?>)</p>
          <div class="space-y-2">
            <?php foreach($editFiles as $f): $ic=file_icon($f['original_name']); ?>
              <div class="flex items-center gap-2 bg-gray-50 rounded-xl p-2">
                <div class="w-8 h-8 rounded-lg <?= $ic[1] ?> flex items-center justify-center shrink-0"><i class="fa-solid <?= $ic[0] ?> text-xs"></i></div>
                <div class="min-w-0 flex-1">
                  <p class="font-bold text-[11px] text-gray-700 truncate"><?= htmlspecialchars($f['original_name']) ?></p>
                  <p class="text-[9px] text-gray-400 tabular-nums"><?= human_size((int)$f['file_size']) ?> · <i class="fa-solid fa-download"></i> <?= pnum((int)$f['download_count']) ?> دانلود</p>
                  <?php if($f['description']): ?><p class="text-[9px] text-gray-500 mt-0.5 leading-relaxed"><?= htmlspecialchars($f['description']) ?></p><?php endif; ?>
                </div>
                <a href="download.php?ann=<?= $f['id'] ?>" class="w-7 h-7 rounded-lg bg-blue-50 text-primary flex items-center justify-center hover:bg-blue-100 transition shrink-0" title="دانلود"><i class="fa-solid fa-download text-[10px]"></i></a>
                <form method="post" data-confirm="این فایل حذف شود؟" class="shrink-0">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="delfile"><input type="hidden" name="id" value="<?= $edit['id'] ?>"><input type="hidden" name="file_id" value="<?= $f['id'] ?>">
                  <button class="w-7 h-7 rounded-lg bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-100 transition"><i class="fa-solid fa-trash text-[10px]"></i></button>
                </form>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
  <div class="lg:col-span-2">
    <div class="card-modern p-5">
      <?php if(!$list): ?><p class="text-center text-xs text-gray-400 py-10">اطلاعیه‌ای ثبت نشده است.</p>
      <?php else: ?>
      <div class="space-y-0">
        <?php foreach($list as $a): $future=$a['publish_at']>$now; ?>
          <div class="timeline-item">
            <div class="timeline-dot" style="<?= $future?'background:#f59e0b':'' ?>"></div>
            <div class="flex items-start justify-between gap-2">
              <div class="min-w-0">
                <p class="font-extrabold text-sm text-gray-800 leading-7 no-justify"><?= htmlspecialchars($a['title']) ?>
                  <?php if($future): ?><span class="text-[9px] bg-amber-50 text-amber-600 font-bold px-1.5 py-0.5 rounded mr-1">زمان‌بندی‌شده</span><?php endif; ?>
                </p>
                <?php if($a['course_title']): ?><span class="text-[9px] bg-blue-50 text-primary font-bold px-1.5 py-0.5 rounded"><?= htmlspecialchars($a['course_title']) ?></span><?php else: ?><span class="text-[9px] bg-gray-100 text-gray-500 font-bold px-1.5 py-0.5 rounded">عمومی</span><?php endif; ?>
                <?php if((int)$a['file_count']>0): ?><span class="text-[9px] bg-amber-50 text-amber-600 font-bold px-1.5 py-0.5 rounded mr-1"><i class="fa-solid fa-paperclip"></i> <?= pnum((int)$a['file_count']) ?> فایل · <i class="fa-solid fa-download"></i> <?= pnum((int)$a['dl_total']) ?></span><?php endif; ?>
                <p class="text-[11px] text-gray-500 mt-1 leading-relaxed"><?= nl2br(htmlspecialchars($a['body'])) ?></p>
                <p class="text-[9px] text-gray-300 mt-1 tabular-nums"><?= jdatetime((int)$a['publish_at']) ?></p>
              </div>
              <div class="flex items-center gap-1.5 shrink-0">
                <a href="announcements.php?edit=<?= $a['id'] ?>" class="w-7 h-7 rounded-lg bg-blue-50 text-primary flex items-center justify-center hover:bg-blue-100 transition"><i class="fa-solid fa-pen text-[10px]"></i></a>
                <form method="post" data-confirm="این اطلاعیه و همه‌ی فایل‌های آن حذف شود؟">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $a['id'] ?>">
                  <button class="w-7 h-7 rounded-lg bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-100 transition"><i class="fa-solid fa-trash text-[10px]"></i></button>
                </form>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
(function(){
  var wrap = document.getElementById('ann-files');
  var addBtn = document.getElementById('ann-add-file');
  if(!wrap || !addBtn) return;
  function row(){
    var d = document.createElement('div');
    d.className = 'flex items-start gap-2 bg-gray-50 rounded-xl p-2';
    d.innerHTML =
      '<div class="flex-1 space-y-1.5">'+
        '<input type="file" name="files[]" class="block w-full text-[11px] file:ml-2 file:rounded-lg file:border-0 file:bg-blue-50 file:text-primary file:px-2.5 file:py-1 file:font-bold file:text-[11px]">'+
        '<input type="text" name="file_desc[]" placeholder="توضیح فایل (اختیاری)" class="input-modern text-[11px] py-1.5">'+
      '</div>'+
      '<button type="button" class="rm w-7 h-7 mt-0.5 rounded-lg bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-100 transition shrink-0"><i class="fa-solid fa-xmark text-[11px]"></i></button>';
    d.querySelector('.rm').addEventListener('click', function(){ d.remove(); });
    wrap.appendChild(d);
  }
  addBtn.addEventListener('click', row);
})();
</script>
<?php require __DIR__.'/_footer.php'; ?>
