<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();
// عملیات CRUD
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  $act=$_POST['act']??'';
  if ($act==='save') {
    $id=(int)($_POST['id']??0);
    $data=[
      trim($_POST['title']??''), trim($_POST['code']??'') ?: null,
      dt_to_ts($_POST['reg_start']??''), dt_to_ts($_POST['reg_end']??''),
      isset($_POST['reg_unlimited'])?1:0,
      dt_to_ts($_POST['exam_start']??''), dt_to_ts($_POST['exam_end']??''),
      max(1,(int)($_POST['max_file_mb']??10)),
      trim($_POST['allowed_types']??'pdf,zip,rar,docx'),
      isset($_POST['active'])?1:0,
      dt_to_ts($_POST['appeal_start']??''), dt_to_ts($_POST['appeal_end']??''),
      trim($_POST['question_desc']??'') ?: null,
    ];
    if ($data[0]==='') { $_SESSION['flash']=['error','عنوان درس الزامی است.']; }
    elseif ($id) {
      DB::q("UPDATE courses SET title=?,code=?,reg_start=?,reg_end=?,reg_unlimited=?,exam_start=?,exam_end=?,max_file_mb=?,allowed_types=?,active=?,appeal_start=?,appeal_end=?,question_desc=? WHERE id=?",
        array_merge($data,[$id]));
      $cid=$id; $_SESSION['flash']=['success','درس ویرایش شد.'];
    } else {
      $cid = DB::insert("INSERT INTO courses (title,code,reg_start,reg_end,reg_unlimited,exam_start,exam_end,max_file_mb,allowed_types,active,appeal_start,appeal_end,question_desc,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        array_merge($data,[ServerTime::now()]));
      $_SESSION['flash']=['success','درس جدید افزوده شد.'];
    }
    // مدیریت فایل سوالات (اختیاری)
    if ($data[0]!=='' && $cid) {
      $cur = DB::one("SELECT question_file FROM courses WHERE id=?", [$cid]);
      $qdir = APP_ROOT.'/uploads/questions';
      if (!is_dir($qdir)) @mkdir($qdir,0755,true);
      // حذف فایل فعلی
      if (isset($_POST['remove_question']) && !empty($cur['question_file'])) {
        $abs=APP_ROOT.'/uploads/'.$cur['question_file']; if(is_file($abs)) @unlink($abs);
        DB::q("UPDATE courses SET question_file=NULL, question_original=NULL WHERE id=?", [$cid]);
      }
      // آپلود فایل جدید
      if (!empty($_FILES['question_file']['name']) && ($_FILES['question_file']['error']??0)===UPLOAD_ERR_OK) {
        $qf=$_FILES['question_file'];
        $ext=strtolower(pathinfo($qf['name'],PATHINFO_EXTENSION));
        $okExt=['pdf','zip','rar','doc','docx','jpg','jpeg','png','txt','ppt','pptx','xls','xlsx'];
        if ($qf['size'] > 30*1024*1024) { $_SESSION['flash']=['error','حجم فایل سوالات بیش از حد مجاز است (حداکثر ۳۰ مگابایت).']; }
        elseif (!in_array($ext,$okExt,true)) { $_SESSION['flash']=['error','نوع فایل سوالات مجاز نیست.']; }
        else {
          $safe='q_'.$cid.'_'.bin2hex(random_bytes(4)).'.'.$ext;
          if (move_uploaded_file($qf['tmp_name'], $qdir.'/'.$safe)) {
            if (!empty($cur['question_file'])) { $old=APP_ROOT.'/uploads/'.$cur['question_file']; if(is_file($old)) @unlink($old); }
            DB::q("UPDATE courses SET question_file=?, question_original=? WHERE id=?", ['questions/'.$safe, $qf['name'], $cid]);
          }
        }
      }
    }
  } elseif ($act==='delete') {
    DB::q("DELETE FROM courses WHERE id=?", [(int)$_POST['id']]);
    $_SESSION['flash']=['success','درس حذف شد.'];
  }
  header('Location: courses.php'); exit;
}
$edit = isset($_GET['edit']) ? DB::one("SELECT * FROM courses WHERE id=?", [(int)$_GET['edit']]) : null;
$courses = DB::all("SELECT c.*, (SELECT COUNT(*) FROM enrollments e WHERE e.course_id=c.id) enrolled FROM courses c ORDER BY c.id DESC");
$flash = $_SESSION['flash']??null; unset($_SESSION['flash']);
$active='courses'; $heading='دروس و آزمون‌ها';
require __DIR__.'/_header.php';
?>
<?= flashbox($flash ?? null) ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
  <!-- فرم -->
  <div class="lg:col-span-1">
    <div class="card-modern p-5 sticky top-20">
      <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-<?= $edit?'pen':'plus' ?> text-blue-500 ml-1.5"></i><?= $edit?'ویرایش درس':'افزودن درس' ?></h3>
      <form method="post" enctype="multipart/form-data" class="space-y-3">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $edit['id']??'' ?>">
        <div><label class="block font-bold text-[11px] text-gray-600 mb-1">عنوان درس *</label><input name="title" required class="input-modern" value="<?= htmlspecialchars($edit['title']??'') ?>"></div>
        <div><label class="block font-bold text-[11px] text-gray-600 mb-1">کد درس</label><input name="code" class="input-modern" dir="ltr" value="<?= htmlspecialchars($edit['code']??'') ?>"></div>
        <div class="grid grid-cols-2 gap-2">
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1">شروع ثبت‌نام</label><input type="datetime-local" name="reg_start" class="input-modern text-xs" dir="ltr" value="<?= ts_to_dt($edit['reg_start']??null) ?>"></div>
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1">پایان ثبت‌نام</label><input type="datetime-local" name="reg_end" class="input-modern text-xs" dir="ltr" value="<?= ts_to_dt($edit['reg_end']??null) ?>"></div>
        </div>
        <label class="flex items-center gap-2 text-xs font-bold text-gray-600"><input type="checkbox" name="reg_unlimited" <?= ($edit['reg_unlimited']??0)?'checked':'' ?>> ثبت‌نام بدون محدودیت زمانی</label>
        <div class="grid grid-cols-2 gap-2">
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1">شروع آزمون</label><input type="datetime-local" name="exam_start" class="input-modern text-xs" dir="ltr" value="<?= ts_to_dt($edit['exam_start']??null) ?>"></div>
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1">پایان آزمون</label><input type="datetime-local" name="exam_end" class="input-modern text-xs" dir="ltr" value="<?= ts_to_dt($edit['exam_end']??null) ?>"></div>
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1"><i class="fa-solid fa-gavel text-amber-500 text-[9px] ml-1"></i>شروع اعتراض</label><input type="datetime-local" name="appeal_start" class="input-modern text-xs" dir="ltr" value="<?= ts_to_dt($edit['appeal_start']??null) ?>"></div>
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1"><i class="fa-solid fa-gavel text-amber-500 text-[9px] ml-1"></i>پایان اعتراض</label><input type="datetime-local" name="appeal_end" class="input-modern text-xs" dir="ltr" value="<?= ts_to_dt($edit['appeal_end']??null) ?>"></div>
        </div>
        <p class="text-[10px] text-gray-400 -mt-1 text-justify leading-relaxed">اگر بازه‌ی اعتراض را خالی بگذارید، ثبت اعتراض برای این درس غیرفعال خواهد بود.</p>
        <div class="grid grid-cols-2 gap-2">
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1">حداکثر حجم (MB)</label><input type="number" name="max_file_mb" min="1" class="input-modern" dir="ltr" value="<?= htmlspecialchars((string)($edit['max_file_mb']??10)) ?>"></div>
          <div><label class="block font-bold text-[11px] text-gray-600 mb-1">فرمت‌های مجاز</label><input name="allowed_types" class="input-modern text-xs" dir="ltr" value="<?= htmlspecialchars($edit['allowed_types']??'pdf,zip,rar,docx') ?>"></div>
        </div>
        <label class="flex items-center gap-2 text-xs font-bold text-gray-600"><input type="checkbox" name="active" <?= ($edit['active']??1)?'checked':'' ?>> درس فعال است</label>

        <div class="border-t border-gray-100 pt-3 mt-1">
          <p class="font-extrabold text-[11px] text-gray-700 mb-2"><i class="fa-solid fa-file-circle-question text-emerald-500 ml-1"></i>سوالات آزمون (اختیاری)</p>
          <label class="block font-bold text-[11px] text-gray-600 mb-1">توضیحات / متن سوالات</label>
          <textarea name="question_desc" rows="3" class="input-modern text-xs" style="text-align:justify;font-weight:500" placeholder="توضیحات یا متن سوالات که در صفحه‌ی آزمون به دانشجو نمایش داده می‌شود (در صورت خالی بودن نمایش داده نمی‌شود)"><?= htmlspecialchars($edit['question_desc']??'') ?></textarea>
          <label class="block font-bold text-[11px] text-gray-600 mb-1 mt-2">فایل دانلودی سوالات</label>
          <input type="file" name="question_file" class="input-modern text-xs file:ml-3 file:rounded-lg file:border-0 file:bg-blue-50 file:text-primary file:px-3 file:py-1.5 file:font-bold file:text-xs">
          <?php if(!empty($edit['question_file'])): ?>
            <div class="flex items-center justify-between gap-2 mt-2 bg-emerald-50 border border-emerald-100 rounded-lg px-3 py-2">
              <span class="text-[11px] font-bold text-emerald-700 truncate"><i class="fa-solid fa-paperclip text-[10px] ml-1"></i><?= htmlspecialchars($edit['question_original']??'فایل سوالات') ?></span>
              <label class="flex items-center gap-1.5 text-[10px] font-bold text-red-500 cursor-pointer shrink-0"><input type="checkbox" name="remove_question" class="w-3.5 h-3.5 accent-red-500"> حذف</label>
            </div>
            <p class="text-[10px] text-gray-400 mt-1">برای جایگزینی، فایل جدید انتخاب کنید.</p>
          <?php endif; ?>
          <p class="text-[10px] text-gray-400 mt-1.5 text-justify leading-relaxed">این بخش اختیاری است؛ اگر فایل یا توضیحی تنظیم نشود، صفحه‌ی آزمون مثل قبل کار می‌کند. فایل سوالات فقط در بازه‌ی آزمون برای دانشجو قابل دانلود است.</p>
        </div>
        <div class="flex gap-2 pt-2">
          <button class="flex-1 py-2.5 rounded-xl bg-primary text-white font-bold text-sm hover:bg-blue-800 transition"><?= $edit?'ذخیره':'افزودن' ?></button>
          <?php if($edit): ?><a href="courses.php" class="px-4 py-2.5 rounded-xl bg-gray-100 text-gray-600 font-bold text-sm">انصراف</a><?php endif; ?>
        </div>
      </form>
    </div>
  </div>

  <!-- لیست -->
  <div class="lg:col-span-2 space-y-3">
    <?php if(!$courses): ?><div class="card-modern p-8 text-center text-sm text-gray-400">درسی ثبت نشده است.</div>
    <?php else: foreach($courses as $c): ?>
      <div class="card-modern p-4 flex items-center justify-between gap-3">
        <div class="min-w-0">
          <div class="flex items-center gap-2">
            <p class="font-extrabold text-sm text-gray-800 truncate"><?= htmlspecialchars($c['title']) ?></p>
            <?php if(!$c['active']): ?><span class="text-[9px] bg-gray-100 text-gray-400 font-bold px-1.5 py-0.5 rounded">غیرفعال</span><?php endif; ?>
          </div>
          <p class="text-[11px] text-gray-400 mt-1">
            <i class="fa-solid fa-users text-[9px]"></i> <?= toPersianNumPHP($c['enrolled']) ?> ثبت‌نام
            <?php if($c['exam_start']): ?> · <i class="fa-regular fa-clock text-[9px]"></i> آزمون: <?= jdatetime((int)$c['exam_start']) ?><?php endif; ?>
          </p>
        </div>
        <div class="flex items-center gap-1.5 shrink-0">
          <a href="courses.php?edit=<?= $c['id'] ?>" class="w-8 h-8 rounded-lg bg-blue-50 text-primary flex items-center justify-center hover:bg-blue-100 transition" title="ویرایش"><i class="fa-solid fa-pen text-xs"></i></a>
          <form method="post" data-confirm="این درس و تمام داده‌های مرتبط آن حذف شود؟">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button class="w-8 h-8 rounded-lg bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-100 transition" title="حذف"><i class="fa-solid fa-trash text-xs"></i></button>
          </form>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>
<?php
function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
require __DIR__.'/_footer.php';
?>
