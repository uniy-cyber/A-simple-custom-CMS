<?php
require __DIR__.'/../includes/bootstrap.php';
$admin = require_admin();
$active = $active ?? '';
$nav = [
  'index'=>['داشبورد','fa-gauge-high'],
  'courses'=>['دروس و آزمون‌ها','fa-book'],
  'submissions'=>['پاسخ‌های ارسالی','fa-file-arrow-down'],
  'grades'=>['ثبت نمرات','fa-pen-to-square'],
  'appeals'=>['اعتراض به نمره','fa-gavel'],
  'activity-log'=>['فعالیت دانشجویان','fa-timeline'],
  'students'=>['دانشجویان','fa-users'],
  'announcements'=>['اطلاعیه‌ها','fa-bullhorn'],
  'sms-settings'=>['تنظیمات پیامک','fa-comment-sms'],
  'site-settings'=>['تنظیمات سایت','fa-sliders'],
  'otp-logs'=>['لاگ پیامک‌ها','fa-clock-rotate-left'],
];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/../partials/head.php'; ?></head>
<body class="min-h-screen bg-slate-50">
<div id="toast-container"></div>

<!-- پس‌زمینه‌ی تیره هنگام باز بودن منو در موبایل -->
<div id="sb-backdrop" onclick="toggleSidebar(false)" class="fixed inset-0 bg-black/40 z-40 lg:hidden hidden"></div>

<div class="flex min-h-screen">
  <!-- سایدبار -->
  <aside id="sidebar" class="w-64 max-w-[80vw] bg-white border-l border-gray-100 fixed inset-y-0 right-0 flex flex-col z-50 transform transition-transform duration-300 translate-x-full lg:translate-x-0">
    <div class="h-16 flex items-center justify-between gap-2 px-5 border-b border-gray-100">
      <div class="flex items-center gap-2">
        <div class="w-9 h-9 rounded-lg bg-primary text-white flex items-center justify-center shadow-md"><i class="fa-solid fa-shield-halved text-sm"></i></div>
        <h1 class="font-black text-gray-800 text-sm">پنل مدیریت</h1>
      </div>
      <button onclick="toggleSidebar(false)" class="lg:hidden w-8 h-8 rounded-lg text-gray-400 hover:bg-gray-100 flex items-center justify-center"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <nav class="flex-1 p-3 space-y-1 overflow-y-auto">
      <?php foreach($nav as $key=>$item): ?>
        <a href="<?= $key ?>.php" class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition <?= $active===$key?'bg-blue-50 text-primary':'text-gray-500 hover:bg-gray-50' ?>">
          <i class="fa-solid <?= $item[1] ?> w-4 text-center"></i><?= $item[0] ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="p-3 border-t border-gray-100">
      <a href="logout.php" class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold text-red-500 hover:bg-red-50 transition"><i class="fa-solid fa-right-from-bracket w-4 text-center"></i> خروج</a>
    </div>
  </aside>

  <!-- محتوا -->
  <div class="flex-1 lg:mr-64 min-w-0">
    <header class="glass-header h-16 flex items-center justify-between px-4 md:px-6 sticky top-0 z-30">
      <div class="flex items-center gap-3 min-w-0">
        <button onclick="toggleSidebar(true)" class="lg:hidden w-9 h-9 rounded-lg bg-gray-50 border border-gray-100 text-gray-600 flex items-center justify-center shrink-0"><i class="fa-solid fa-bars"></i></button>
        <h2 class="font-extrabold text-gray-800 text-sm md:text-base truncate"><?= htmlspecialchars($heading ?? 'پنل مدیریت') ?></h2>
      </div>
      <div class="flex items-center gap-2 md:gap-3 shrink-0">
        <!-- ساعت دسکتاپ (در موبایل پنهان و به نوار زیر منتقل می‌شود) -->
        <div class="hidden lg:flex bg-gray-50 px-2 py-1 rounded border border-gray-100 items-center gap-1.5">
          <i class="fa-solid fa-server text-blue-500 text-[9px]"></i>
          <span class="js-clock tabular-nums font-medium text-[11px] text-gray-600" dir="ltr">--:--:--</span>
        </div>
        <span class="hidden sm:inline text-xs font-bold text-gray-600 truncate max-w-[120px]"><?= htmlspecialchars($admin['full_name']) ?></span>
      </div>
    </header>
    <!-- نوار ساعت چسبیده زیر هدر — فقط موبایل -->
    <div class="lg:hidden sticky top-16 z-20 bg-white/80 backdrop-blur border-b border-gray-100 px-4 py-1.5 flex items-center justify-center gap-1.5">
      <i class="fa-solid fa-server text-blue-500 text-[9px]"></i>
      <span class="text-[10px] text-gray-400 font-bold ml-1">ساعت سرور</span>
      <span class="js-clock tabular-nums font-extrabold text-[12px] text-gray-700" dir="ltr">--:--:--</span>
    </div>
    <main class="p-4 md:p-6 fade-in">
