<?php
require __DIR__.'/../includes/bootstrap.php';
if (current_admin()) { header('Location: '.base_url('admin/index.php')); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check_form();
  $u=trim($_POST['username']??''); $p=$_POST['password']??'';
  $a=DB::one("SELECT * FROM admins WHERE username=?", [$u]);
  if ($a && password_verify($p,$a['password_hash'])) { login_admin((int)$a['id']); header('Location: '.base_url('admin/index.php')); exit; }
  $error='نام کاربری یا رمز عبور نادرست است.';
}
function csrf_check_form(){ if(!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')){ http_response_code(419); die('توکن نامعتبر'); } }
$page_title='ورود مدیر';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/../partials/head.php'; ?></head>
<body class="min-h-screen flex items-center justify-center px-4">
<div class="w-full max-w-sm fade-in">
  <div class="text-center mb-6">
    <div class="w-14 h-14 bg-blue-50 text-primary rounded-2xl flex items-center justify-center text-xl mx-auto mb-3 border border-blue-100"><i class="fa-solid fa-shield-halved"></i></div>
    <h2 class="font-extrablack text-xl text-gray-800">ورود به پنل مدیریت</h2>
  </div>
  <div class="card-modern p-6 md:p-8">
    <?php if($error): ?><div class="mb-4 bg-red-50 border border-red-200 text-red-700 text-xs font-bold rounded-lg p-3"><i class="fa-solid fa-circle-exclamation ml-1"></i><?= $error ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <div class="mb-4"><label class="block font-bold text-xs text-gray-700 mb-1.5">نام کاربری</label><input name="username" required class="input-modern" dir="ltr" autofocus></div>
      <div class="mb-5"><label class="block font-bold text-xs text-gray-700 mb-1.5">رمز عبور</label><input name="password" type="password" required class="input-modern" dir="ltr"></div>
      <button class="w-full py-3 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2 text-sm"><i class="fa-solid fa-right-to-bracket text-xs"></i> ورود</button>
    </form>
  </div>
</div>
</body>
</html>
