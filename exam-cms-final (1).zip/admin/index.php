<?php $active='index'; $heading='داشبورد';
require __DIR__.'/_header.php';
$stats=[
  'students'=>DB::one("SELECT COUNT(*) n FROM students")['n'],
  'courses'=>DB::one("SELECT COUNT(*) n FROM courses")['n'],
  'submissions'=>DB::one("SELECT COUNT(*) n FROM submissions")['n'],
  'sms'=>DB::one("SELECT COUNT(*) n FROM sms_logs")['n'],
];
$cards=[
  ['دانشجویان',$stats['students'],'fa-users','blue'],
  ['دروس',$stats['courses'],'fa-book','emerald'],
  ['پاسخ‌های ارسالی',$stats['submissions'],'fa-file-arrow-down','amber'],
  ['پیامک‌های ارسالی',$stats['sms'],'fa-comment-sms','purple'],
];
$recent=DB::all("SELECT s.*, st.first_name,st.last_name,st.student_id,c.title FROM submissions s JOIN students st ON st.id=s.student_id JOIN courses c ON c.id=s.course_id ORDER BY s.id DESC LIMIT 8");

// ثبت‌نام‌ها به تفکیک درس
$byCourse=DB::all("SELECT c.id AS cid, c.title, s.first_name, s.last_name, s.student_id, s.mobile
                   FROM courses c
                   JOIN enrollments e ON e.course_id=c.id
                   JOIN students s ON s.id=e.student_id
                   ORDER BY c.title, s.last_name, s.first_name");
$groups=[];
foreach($byCourse as $r){ $groups[$r['title']][]=$r; }
function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
?>
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
  <?php $cmap=['blue'=>'bg-blue-50 text-primary','emerald'=>'bg-emerald-50 text-emerald-600','amber'=>'bg-amber-50 text-amber-600','purple'=>'bg-purple-50 text-purple-600'];
  foreach($cards as $c): ?>
  <div class="card-modern p-5">
    <div class="w-10 h-10 rounded-xl <?= $cmap[$c[3]] ?> flex items-center justify-center mb-3"><i class="fa-solid <?= $c[2] ?>"></i></div>
    <p class="text-2xl font-extrablack text-gray-800 tabular-nums"><?= number_format((int)$c[1]) ?></p>
    <p class="text-xs text-gray-500 font-bold mt-1"><?= $c[0] ?></p>
  </div>
  <?php endforeach; ?>
</div>
<div class="card-modern p-5">
  <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-clock-rotate-left text-blue-500 ml-1.5"></i>آخرین پاسخ‌های ارسالی</h3>
  <?php if(!$recent): ?><p class="text-center text-xs text-gray-400 py-6">موردی ثبت نشده است.</p>
  <?php else: ?>
  <div class="overflow-x-auto"><table class="w-full text-sm">
    <thead><tr class="text-[11px] text-gray-400 border-b border-gray-100"><th class="text-right py-2 font-bold">دانشجو</th><th class="text-right font-bold">درس</th><th class="text-right font-bold">فایل</th><th class="text-right font-bold">زمان</th></tr></thead>
    <tbody>
    <?php foreach($recent as $r): ?>
      <tr class="border-b border-gray-50">
        <td class="py-2.5 font-bold text-gray-700"><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?> <span class="text-[10px] text-gray-400 tabular-nums" dir="ltr"><?= htmlspecialchars($r['student_id']) ?></span></td>
        <td class="text-gray-600"><?= htmlspecialchars($r['title']) ?></td>
        <td class="text-gray-500 text-xs"><?= htmlspecialchars($r['original_name']) ?></td>
        <td class="text-gray-400 text-xs tabular-nums"><?= jdatetime((int)$r['submitted_at']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</div>

<!-- ثبت‌نام‌ها به تفکیک درس -->
<div class="card-modern p-5 mt-6">
  <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-users-between-lines text-emerald-500 ml-1.5"></i>ثبت‌نام‌ها به تفکیک درس</h3>
  <?php if(!$groups): ?>
    <p class="text-center text-xs text-gray-400 py-6">هنوز ثبت‌نامی انجام نشده است.</p>
  <?php else: foreach($groups as $title=>$list): ?>
    <details class="mb-3 rounded-xl border border-gray-100 overflow-hidden group">
      <summary class="flex items-center justify-between gap-2 px-4 py-3 cursor-pointer bg-gray-50/60 hover:bg-gray-50 select-none">
        <span class="font-extrabold text-sm text-gray-700"><i class="fa-solid fa-book-open text-primary text-xs ml-1.5"></i><?= htmlspecialchars($title) ?></span>
        <span class="flex items-center gap-2">
          <span class="text-[10px] font-bold bg-blue-50 text-primary px-2 py-1 rounded-md"><?= toPersianNumPHP(count($list)) ?> دانشجو</span>
          <i class="fa-solid fa-chevron-down text-gray-300 text-[10px] transition-transform group-open:rotate-180"></i>
        </span>
      </summary>
      <div class="overflow-x-auto px-4 pb-3 pt-1">
        <table class="w-full text-sm whitespace-nowrap">
          <thead><tr class="text-[11px] text-gray-400 border-b border-gray-100">
            <th class="text-right py-2 font-bold">#</th><th class="text-right font-bold">نام و نام خانوادگی</th><th class="text-right font-bold">شماره دانشجویی</th><th class="text-right font-bold">موبایل</th>
          </tr></thead>
          <tbody>
          <?php foreach($list as $i=>$st): ?>
            <tr class="border-b border-gray-50">
              <td class="py-2 text-gray-300 text-xs tabular-nums"><?= toPersianNumPHP($i+1) ?></td>
              <td class="font-bold text-gray-700"><?= htmlspecialchars($st['first_name'].' '.$st['last_name']) ?></td>
              <td class="text-gray-500 text-xs tabular-nums" dir="ltr"><?= htmlspecialchars($st['student_id']) ?></td>
              <td class="text-gray-500 text-xs tabular-nums" dir="ltr"><?= htmlspecialchars($st['mobile']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </details>
  <?php endforeach; endif; ?>
</div>
<?php require __DIR__.'/_footer.php'; ?>
