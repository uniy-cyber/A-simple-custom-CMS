<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();
$now = ServerTime::now();

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  if (($_POST['act']??'')==='save') {
    $grades = $_POST['grade']   ?? [];
    $pubs   = $_POST['publish'] ?? [];
    foreach ($grades as $eid=>$g) {
      $eid=(int)$eid; $g=trim(fa2en((string)$g));
      $pub = isset($pubs[$eid]) ? 1 : 0;
      $prev = DB::one("SELECT e.grade_published, e.student_id, c.title FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.id=?", [$eid]);
      if ($g==='') {
        DB::q("UPDATE enrollments SET grade=NULL, grade_published=?, graded_at=? WHERE id=?", [$pub,$now,$eid]);
      } else {
        $val=(float)$g; if($val<0)$val=0;
        DB::q("UPDATE enrollments SET grade=?, grade_published=?, graded_at=? WHERE id=?", [$val,$pub,$now,$eid]);
      }
      // اعلان فقط هنگام اولین انتشار نمره
      if ($pub && $g!=='' && $prev && (int)$prev['grade_published']===0) {
        notify_student((int)$prev['student_id'], 'نمره‌ی درس «'.$prev['title'].'» اعلام شد', 'نمره‌ی شما در کارنامه قابل مشاهده است.', 'grade');
      }
    }
    $_SESSION['flash']=['success','نمرات با موفقیت ذخیره شد.'];
  }
  header('Location: grades.php?course='.(int)($_POST['course']??0)); exit;
}

$courses = DB::all("SELECT id,title FROM courses ORDER BY title");
$cid = (int)($_GET['course'] ?? ($courses[0]['id'] ?? 0));
$rows = $cid ? DB::all(
  "SELECT e.id AS enroll_id, e.grade, e.grade_published,
          st.first_name, st.last_name, st.student_id,
          sub.id AS sub_id, sub.original_name, sub.submitted_at, sub.file_path, sub.file_path2, sub.original_name2, sub.files_json
   FROM enrollments e
   JOIN students st ON st.id=e.student_id
   LEFT JOIN submissions sub ON sub.student_id=e.student_id AND sub.course_id=e.course_id
   WHERE e.course_id=? ORDER BY st.last_name, st.first_name", [$cid]) : [];

$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$active='grades'; $heading='ثبت نمرات';
require __DIR__.'/_header.php';
function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
function gFmt($g){ if($g===null) return ''; return rtrim(rtrim(number_format((float)$g,2,'.',''),'0'),'.'); }
?>
<?= flashbox($flash ?? null) ?>

<div class="card-modern p-5 mb-4">
  <form method="get" class="flex flex-col sm:flex-row sm:items-center gap-3">
    <label class="text-sm font-extrabold text-gray-700 shrink-0"><i class="fa-solid fa-book text-blue-500 ml-1.5"></i>انتخاب درس:</label>
    <select name="course" onchange="this.form.submit()" class="input-modern sm:w-72">
      <?php foreach($courses as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $c['id']==$cid?'selected':'' ?>><?= htmlspecialchars($c['title']) ?></option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<?php if(!$courses): ?>
  <div class="card-modern p-8 text-center text-sm text-gray-400">ابتدا یک درس تعریف کنید.</div>
<?php elseif(!$rows): ?>
  <div class="card-modern p-8 text-center text-sm text-gray-400"><i class="fa-solid fa-inbox text-2xl mb-2 block"></i>برای این درس دانشجویی ثبت‌نام نکرده است.</div>
<?php else: ?>
<form method="post">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
  <input type="hidden" name="act" value="save">
  <input type="hidden" name="course" value="<?= $cid ?>">
  <div class="card-modern p-5">
    <div class="flex items-center justify-between mb-4">
      <h3 class="font-extrabold text-gray-800"><i class="fa-solid fa-pen-to-square text-blue-500 ml-1.5"></i>نمرات دانشجویان <span class="text-xs text-gray-400 font-bold">(<?= toPersianNumPHP(count($rows)) ?>)</span></h3>
      <label class="flex items-center gap-2 text-[11px] font-bold text-gray-500 cursor-pointer">
        <input type="checkbox" onchange="document.querySelectorAll('.pub-cb').forEach(c=>c.checked=this.checked)" class="w-4 h-4 accent-emerald-500"> انتشار همه
      </label>
    </div>
    <div class="overflow-x-auto"><table class="w-full text-sm whitespace-nowrap">
      <thead><tr class="text-[11px] text-gray-400 border-b border-gray-100">
        <th class="text-right py-2 font-bold">دانشجو</th><th class="text-right font-bold">پاسخ ارسالی</th><th class="text-center font-bold">نمره</th><th class="text-center font-bold">انتشار</th>
      </tr></thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <tr class="border-b border-gray-50 hover:bg-gray-50/50">
          <td class="py-2.5 font-bold text-gray-700"><?= htmlspecialchars($r['first_name'].' '.$r['last_name']) ?> <span class="text-[10px] text-gray-400 tabular-nums" dir="ltr"><?= htmlspecialchars($r['student_id']) ?></span></td>
          <td>
            <?php if($r['sub_id']):
              $gf = !empty($r['files_json']) ? (json_decode($r['files_json'],true)?:[]) : [];
              if(!$gf){ if(!empty($r['file_path'])) $gf[]=['n'=>$r['original_name']]; if(!empty($r['file_path2'])) $gf[]=['n'=>$r['original_name2']]; }
              $hj=!empty($r['files_json']);
            ?>
              <?php foreach($gf as $i=>$fl): $u=$hj?('download.php?id='.$r['sub_id'].'&i='.$i):('download.php?id='.$r['sub_id'].($i==0?'':'&f=2')); ?>
                <a href="<?= $u ?>" class="text-primary text-xs font-bold hover:underline block"><i class="fa-solid fa-download text-[10px]"></i> <?= htmlspecialchars(mb_strimwidth($fl['n']??'فایل',0,22,'…')) ?></a>
              <?php endforeach; ?>
            <?php else: ?>
              <span class="text-[11px] text-red-400 font-bold">بدون پاسخ</span>
            <?php endif; ?>
          </td>
          <td class="text-center"><input type="text" inputmode="decimal" name="grade[<?= $r['enroll_id'] ?>]" value="<?= gFmt($r['grade']) ?>" placeholder="—" class="input-modern w-20 text-center py-1.5 tabular-nums" dir="ltr"></td>
          <td class="text-center"><input type="checkbox" class="pub-cb w-4 h-4 accent-emerald-500" name="publish[<?= $r['enroll_id'] ?>]" <?= (int)$r['grade_published']===1?'checked':'' ?>></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <div class="flex items-center justify-between mt-5 pt-4 border-t border-gray-100 gap-3">
      <p class="text-[11px] text-gray-400 text-justify max-w-md leading-relaxed">می‌توانید برای دانشجوی بدون پاسخ هم نمره ثبت کنید. فقط نمراتی که «انتشار» داشته باشند در کارنامه‌ی دانشجو دیده می‌شوند و امکان اعتراض می‌یابند.</p>
      <button class="px-6 py-2.5 rounded-xl bg-primary text-white text-sm font-bold shadow-md hover:bg-blue-800 transition shrink-0"><i class="fa-solid fa-floppy-disk ml-1.5"></i>ذخیره نمرات</button>
    </div>
  </div>
</form>
<?php endif; ?>
<?php require __DIR__.'/_footer.php'; ?>
