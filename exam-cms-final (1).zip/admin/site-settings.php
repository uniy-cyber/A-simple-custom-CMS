<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();

$DEF_HERO_TITLE='سامانه‌ی جامع آزمون آنلاین';
$DEF_HERO_SUB='برگزاری امن آزمون‌های پایان ترم با کنترل زمان سرور، احراز هویت پیامکی و بارگذاری پاسخ‌ها.';
$DEF_CARDS=[['fa-shield-halved','کنترل زمان سرور'],['fa-comment-sms','تایید پیامکی OTP'],['fa-file-shield','بارگذاری امن'],['fa-bullhorn','تایم‌لاین اطلاعیه']];

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  // دسترسی ورود/ثبت‌نام
  Settings::set('login_enabled', isset($_POST['login_enabled'])?'1':'0');
  Settings::set('register_enabled', isset($_POST['register_enabled'])?'1':'0');
  Settings::set('login_disabled_msg', trim($_POST['login_disabled_msg']??''));
  Settings::set('register_disabled_msg', trim($_POST['register_disabled_msg']??''));
  Settings::set('answer_max_files', (string)max(1,min(10,(int)($_POST['answer_max_files']??1))));
  Settings::set('exam_over_submitted_msg', trim($_POST['exam_over_submitted_msg']??''));
  Settings::set('exam_over_nosubmit_msg', trim($_POST['exam_over_nosubmit_msg']??''));
  // محتوای صفحه‌ی اصلی
  Settings::set('home_hero_title', trim($_POST['home_hero_title']??''));
  Settings::set('home_hero_subtitle', trim($_POST['home_hero_subtitle']??''));
  $cards=[];
  for($i=0;$i<4;$i++){
    $ic=trim($_POST['card_icon'][$i]??''); $ti=trim($_POST['card_title'][$i]??'');
    if($ti!=='') $cards[]=[$ic!==''?$ic:'fa-circle-dot',$ti];
  }
  Settings::set('home_cards', json_encode($cards, JSON_UNESCAPED_UNICODE));
  $_SESSION['flash']=['success','تنظیمات سایت ذخیره شد.'];
  header('Location: site-settings.php'); exit;
}

$loginOn = setting('login_enabled','1')==='1';
$regOn   = setting('register_enabled','1')==='1';
$loginMsg= setting('login_disabled_msg','ورود به سیستم موقتاً غیرفعال است.');
$regMsg  = setting('register_disabled_msg','ثبت‌نام موقتاً غیرفعال است.');
$heroTitle = setting('home_hero_title',$DEF_HERO_TITLE);
$heroSub   = setting('home_hero_subtitle',$DEF_HERO_SUB);
$cards = json_decode(setting('home_cards',''), true); if(!is_array($cards)||!$cards) $cards=$DEF_CARDS;
while(count($cards)<4) $cards[]=['',''];

$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$active='site-settings'; $heading='تنظیمات سایت';
require __DIR__.'/_header.php';
?>
<?= flashbox($flash ?? null) ?>

<form method="post" class="space-y-5">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">

  <!-- دسترسی ورود و ثبت‌نام -->
  <div class="card-modern p-6">
    <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-door-closed text-red-500 ml-1.5"></i>دسترسی ورود و ثبت‌نام</h3>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <div class="space-y-2">
        <label class="flex items-center gap-2 text-sm font-bold text-gray-700 bg-gray-50 rounded-lg px-3 py-2.5 border border-gray-100">
          <input type="checkbox" name="login_enabled" class="w-4 h-4 accent-emerald-500" <?= $loginOn?'checked':'' ?>> صفحه‌ی ورود فعال باشد
        </label>
        <label class="block font-bold text-[11px] text-gray-600">پیام هنگام غیرفعال بودن ورود</label>
        <textarea name="login_disabled_msg" rows="2" class="input-modern text-xs" style="text-align:justify;font-weight:500"><?= htmlspecialchars($loginMsg) ?></textarea>
      </div>
      <div class="space-y-2">
        <label class="flex items-center gap-2 text-sm font-bold text-gray-700 bg-gray-50 rounded-lg px-3 py-2.5 border border-gray-100">
          <input type="checkbox" name="register_enabled" class="w-4 h-4 accent-emerald-500" <?= $regOn?'checked':'' ?>> صفحه‌ی ثبت‌نام فعال باشد
        </label>
        <label class="block font-bold text-[11px] text-gray-600">پیام هنگام غیرفعال بودن ثبت‌نام</label>
        <textarea name="register_disabled_msg" rows="2" class="input-modern text-xs" style="text-align:justify;font-weight:500"><?= htmlspecialchars($regMsg) ?></textarea>
      </div>
    </div>
    <p class="text-[11px] text-gray-400 mt-3 text-justify leading-relaxed">با برداشتن تیک، صفحه‌ی مربوطه برای دانشجویان کاملاً بسته می‌شود و پیام بالا نمایش داده می‌شود (هم در صفحه و هم در سمت سرور اعمال می‌گردد).</p>
    <div class="mt-4 pt-4 border-t border-gray-100">
      <label class="block font-bold text-xs text-gray-700 mb-1.5"><i class="fa-solid fa-paperclip text-blue-500 ml-1"></i>حداکثر تعداد فایل پاسخ برای هر دانشجو</label>
      <input type="number" name="answer_max_files" min="1" max="10" class="input-modern sm:w-40" dir="ltr" value="<?= (int)setting('answer_max_files',1) ?>">
      <p class="text-[11px] text-gray-400 mt-2 text-justify leading-relaxed">اگر روی <b>۱</b> باشد، دانشجو فقط یک فایل ارسال می‌کند. با عددی بزرگ‌تر، دکمه‌ی «افزودن فایل» برای دانشجو فعال می‌شود و می‌تواند تا این تعداد فایل اضافه کند.</p>
    </div>
  </div>

  <!-- محتوای صفحه‌ی اصلی -->
  <div class="card-modern p-6">
    <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-house text-blue-500 ml-1.5"></i>محتوای صفحه‌ی اصلی</h3>
    <div class="space-y-4">
      <div><label class="block font-bold text-xs text-gray-700 mb-1.5">عنوان اصلی (Hero)</label><input name="home_hero_title" class="input-modern" value="<?= htmlspecialchars($heroTitle) ?>"></div>
      <div><label class="block font-bold text-xs text-gray-700 mb-1.5">توضیح زیر عنوان</label><textarea name="home_hero_subtitle" rows="2" class="input-modern text-xs" style="text-align:justify;font-weight:500"><?= htmlspecialchars($heroSub) ?></textarea></div>
    </div>

    <h4 class="font-extrabold text-sm text-gray-700 mt-6 mb-3"><i class="fa-solid fa-grip text-amber-500 ml-1.5"></i>کارت‌های ویژگی (۴ مورد)</h4>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <?php for($i=0;$i<4;$i++): ?>
        <div class="border border-gray-100 rounded-xl p-3 bg-gray-50/40">
          <p class="text-[10px] font-bold text-gray-400 mb-2">کارت <?= ['اول','دوم','سوم','چهارم'][$i] ?></p>
          <label class="block text-[10px] font-bold text-gray-500 mb-1">آیکن (کلاس Font Awesome)</label>
          <input name="card_icon[]" class="input-modern text-xs mb-2" dir="ltr" placeholder="fa-shield-halved" value="<?= htmlspecialchars($cards[$i][0]??'') ?>">
          <label class="block text-[10px] font-bold text-gray-500 mb-1">عنوان</label>
          <input name="card_title[]" class="input-modern text-xs" placeholder="عنوان کارت (خالی = حذف)" value="<?= htmlspecialchars($cards[$i][1]??'') ?>">
        </div>
      <?php endfor; ?>
    </div>
    <p class="text-[11px] text-gray-400 mt-3 text-justify leading-relaxed">برای آیکن‌ها از کلاس‌های Font Awesome 6 استفاده کنید (مثل <span dir="ltr">fa-lock</span>، <span dir="ltr">fa-clock</span>). اگر عنوان یک کارت را خالی بگذارید، آن کارت نمایش داده نمی‌شود.</p>
  </div>

  <!-- پیام‌های سیستم -->
  <div class="card-modern p-6">
    <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-comment-dots text-emerald-500 ml-1.5"></i>پیام‌های سیستم (پایان آزمون)</h3>
    <div class="space-y-4">
      <div>
        <label class="block font-bold text-xs text-gray-700 mb-1.5">پیام پایان آزمون — وقتی دانشجو پاسخ ثبت کرده</label>
        <textarea name="exam_over_submitted_msg" rows="2" class="input-modern text-xs" style="text-align:justify;font-weight:500" placeholder="پیش‌فرض: پاسخ شما با موفقیت ثبت شده و مهلت آزمون به پایان رسیده است."><?= htmlspecialchars(setting('exam_over_submitted_msg','')) ?></textarea>
      </div>
      <div>
        <label class="block font-bold text-xs text-gray-700 mb-1.5">پیام پایان آزمون — وقتی پاسخی ثبت نشده</label>
        <textarea name="exam_over_nosubmit_msg" rows="2" class="input-modern text-xs" style="text-align:justify;font-weight:500" placeholder="پیش‌فرض: مهلت آزمون به پایان رسیده و پاسخی از شما ثبت نشده است."><?= htmlspecialchars(setting('exam_over_nosubmit_msg','')) ?></textarea>
      </div>
      <p class="text-[11px] text-gray-400 text-justify leading-relaxed">برای حذف یک پیام سفارشی، کادر آن را خالی کنید؛ در این صورت متن پیش‌فرض نمایش داده می‌شود.</p>
    </div>
  </div>

  <button class="w-full py-3 rounded-xl bg-primary text-white font-bold text-sm hover:bg-blue-800 transition"><i class="fa-solid fa-floppy-disk text-xs ml-1"></i> ذخیره‌ی همه‌ی تنظیمات</button>
</form>
<?php require __DIR__.'/_footer.php'; ?>
