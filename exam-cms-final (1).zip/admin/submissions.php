<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();

// حذف یک پاسخ
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  if (($_POST['act']??'')==='delete') {
    $sub = DB::one("SELECT * FROM submissions WHERE id=?", [(int)$_POST['id']]);
    if ($sub) {
      $abs = APP_ROOT.'/uploads/'.$sub['file_path'];
      if (is_file($abs)) @unlink($abs);
      DB::q("DELETE FROM submissions WHERE id=?", [(int)$sub['id']]);
      $_SESSION['flash']=['success','پاسخ حذف شد.'];
    }
  }
  header('Location: submissions.php'.(isset($_POST['course'])?'?course='.(int)$_POST['course']:'')); exit;
}

$filter = (int)($_GET['course'] ?? 0);
$allCourses = DB::all("SELECT id,title FROM courses ORDER BY title");
$params=[]; $where='';
if ($filter) { $where='WHERE s.course_id=?'; $params[]=$filter; }
$subs = DB::all("SELECT s.*, st.first_name,st.last_name,st.student_id, c.title
                 FROM submissions s JOIN students st ON st.id=s.student_id JOIN courses c ON c.id=s.course_id
                 $where ORDER BY s.id DESC", $params);
$flash = $_SESSION['flash']??null; unset($_SESSION['flash']);
$active='submissions'; $heading='پاسخ‌های ارسالی';
require __DIR__.'/_header.php';

function fsize_fa($b){ $u=['B','KB','MB','GB']; $i=0; while($b>=1024&&$i<3){$b/=1024;$i++;} return round($b,1).' '.$u[$i]; }
function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
?>
<?= flashbox($flash ?? null) ?>

<div class="card-modern p-5">
  <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
    <h3 class="font-extrabold text-gray-800"><i class="fa-solid fa-file-arrow-down text-blue-500 ml-1.5"></i>پاسخ‌های ارسالی <span class="text-xs text-gray-400 font-bold">(<?= toPersianNumPHP(count($subs)) ?> مورد)</span></h3>
    <form method="get" class="flex items-center gap-2">
      <select name="course" onchange="this.form.submit()" class="input-modern text-xs py-2 w-52">
        <option value="0">همه‌ی دروس</option>
        <?php foreach($allCourses as $c): ?><option value="<?= $c['id'] ?>" <?= $filter==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['title']) ?></option><?php endforeach; ?>
      </select>
    </form>
  </div>

  <?php if(!$subs): ?>
    <p class="text-center text-xs text-gray-400 py-10"><i class="fa-solid fa-folder-open text-2xl block mb-2"></i>پاسخی ثبت نشده است.</p>
  <?php else: ?>
  <div class="overflow-x-auto">
    <table class="w-full text-sm whitespace-nowrap">
      <thead><tr class="text-[11px] text-gray-400 border-b border-gray-100">
        <th class="text-right py-2 font-bold">دانشجو</th><th class="text-right font-bold">شماره</th><th class="text-right font-bold">درس</th>
        <th class="text-right font-bold">فایل</th><th class="text-right font-bold">حجم</th><th class="text-right font-bold">زمان ارسال</th><th class="text-center font-bold">عملیات</th>
      </tr></thead>
      <?php
      function sub_files_list($s){
        $f = (!empty($s['files_json'])) ? (json_decode($s['files_json'],true)?:[]) : [];
        if(!$f){ if(!empty($s['file_path'])) $f[]=['n'=>$s['original_name'],'s'=>$s['file_size']]; if(!empty($s['file_path2'])) $f[]=['n'=>$s['original_name2'],'s'=>$s['file_size2']]; }
        return $f;
      } ?>
      <tbody>
      <?php foreach($subs as $s): $ff=sub_files_list($s); $hasJson=!empty($s['files_json']); ?>
        <tr class="border-b border-gray-50 hover:bg-gray-50/50">
          <td class="py-2.5 font-bold text-gray-700"><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></td>
          <td class="text-gray-500 text-xs tabular-nums" dir="ltr"><?= htmlspecialchars($s['student_id']) ?></td>
          <td class="text-gray-600 text-xs"><?= htmlspecialchars($s['title']) ?></td>
          <td class="text-gray-500 text-xs max-w-[180px]"><?php foreach($ff as $fl): ?><div class="truncate"><i class="fa-solid fa-paperclip text-[8px] text-gray-400"></i> <?= htmlspecialchars($fl['n']??'فایل') ?></div><?php endforeach; ?></td>
          <td class="text-gray-400 text-xs tabular-nums" dir="ltr"><?= fsize_fa((int)$s['file_size']) ?></td>
          <td class="text-gray-400 text-xs tabular-nums"><?= jdatetime((int)$s['submitted_at']) ?></td>
          <td class="text-center">
            <div class="flex items-center justify-center gap-1.5">
              <?php foreach($ff as $i=>$fl): $url=$hasJson?('download.php?id='.$s['id'].'&i='.$i):('download.php?id='.$s['id'].($i==0?'':'&f=2')); ?>
              <a href="<?= $url ?>" class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center hover:bg-emerald-100 transition" title="دانلود فایل <?= toPersianNumPHP($i+1) ?>"><i class="fa-solid fa-download text-xs"></i></a>
              <?php endforeach; ?>
              <form method="post" data-confirm="این پاسخ حذف شود؟">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>"><input type="hidden" name="course" value="<?= $filter ?>">
                <button class="w-8 h-8 rounded-lg bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-100 transition" title="حذف"><i class="fa-solid fa-trash text-xs"></i></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php require __DIR__.'/_footer.php'; ?>
