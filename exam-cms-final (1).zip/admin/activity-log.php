<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  if (($_POST['act']??'')==='clear') { DB::q("DELETE FROM activity_log"); $_SESSION['flash']='لاگ فعالیت‌ها پاک شد.'; }
  header('Location: activity-log.php'); exit;
}

$sid = (int)($_GET['student'] ?? 0);
$per = 30;
$cond = $sid ? "WHERE a.student_id=".$sid : "";
$total = (int)(DB::one("SELECT COUNT(*) n FROM activity_log a $cond")['n'] ?? 0);
$pages = max(1,(int)ceil($total/$per));
$page  = max(1,min($pages,(int)($_GET['page']??1)));
$off   = ($page-1)*$per;
$logs  = DB::all("SELECT a.*, s.first_name, s.last_name, s.student_id
                  FROM activity_log a JOIN students s ON s.id=a.student_id
                  $cond ORDER BY a.id DESC LIMIT $per OFFSET $off");
$students = DB::all("SELECT id, first_name, last_name FROM students ORDER BY first_name");

$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$active='activity-log'; $heading='فعالیت دانشجویان';
require __DIR__.'/_header.php';
$meta=[
  'login'=>['fa-right-to-bracket','text-blue-500 bg-blue-50','ورود'],
  'register'=>['fa-user-plus','text-emerald-500 bg-emerald-50','ثبت‌نام'],
  'upload'=>['fa-cloud-arrow-up','text-amber-500 bg-amber-50','ارسال پاسخ'],
  'appeal'=>['fa-gavel','text-rose-500 bg-rose-50','اعتراض'],
];
?>
<?= flashbox($flash ?? null) ?>
<div class="card-modern p-5">
  <div class="flex items-center justify-between gap-2 mb-5 flex-wrap">
    <h3 class="font-extrabold text-gray-800"><i class="fa-solid fa-timeline text-blue-500 ml-1.5"></i>تایم‌لاین فعالیت <span class="text-xs text-gray-400 font-bold">(<?= pnum($total) ?>)</span></h3>
    <div class="flex items-center gap-2">
      <form method="get" class="flex items-center gap-2">
        <select name="student" onchange="this.form.submit()" class="input-modern text-xs py-2 w-44">
          <option value="0">همه‌ی دانشجویان</option>
          <?php foreach($students as $st): ?><option value="<?= $st['id'] ?>" <?= $sid==$st['id']?'selected':'' ?>><?= htmlspecialchars($st['first_name'].' '.$st['last_name']) ?></option><?php endforeach; ?>
        </select>
      </form>
      <?php if($total): ?>
      <form method="post" data-confirm="کل لاگ فعالیت‌ها پاک شود؟ این عمل بازگشت‌ناپذیر است.">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="clear">
        <button class="text-[11px] font-bold text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2 hover:bg-red-100 transition"><i class="fa-solid fa-trash-can text-[10px] ml-1"></i>پاک‌سازی</button>
      </form>
      <?php endif; ?>
    </div>
  </div>

  <?php if(!$logs): ?>
    <p class="text-center text-xs text-gray-400 py-12"><i class="fa-solid fa-timeline text-2xl mb-2 block"></i>فعالیتی ثبت نشده است.</p>
  <?php else: ?>
  <div class="relative pr-3">
    <div class="absolute top-2 bottom-2 right-[22px] w-px bg-gray-100"></div>
    <?php foreach($logs as $l): $m=$meta[$l['action']]??['fa-circle-info','text-gray-400 bg-gray-50',$l['action']]; ?>
      <div class="relative flex items-start gap-3 pb-5">
        <div class="w-9 h-9 rounded-full <?= $m[1] ?> flex items-center justify-center shrink-0 z-10 ring-4 ring-white"><i class="fa-solid <?= $m[0] ?> text-xs"></i></div>
        <div class="min-w-0 flex-1 pt-1">
          <div class="flex items-center justify-between gap-2 flex-wrap">
            <p class="font-extrabold text-sm text-gray-800"><?= htmlspecialchars($l['first_name'].' '.$l['last_name']) ?> <span class="text-[10px] text-gray-400 tabular-nums" dir="ltr"><?= htmlspecialchars($l['student_id']) ?></span></p>
            <span class="text-[10px] text-gray-300 tabular-nums"><?= jdatetime((int)$l['created_at']) ?></span>
          </div>
          <p class="text-xs text-gray-500 mt-0.5"><span class="font-bold <?= str_replace(['bg-blue-50','bg-emerald-50','bg-amber-50','bg-rose-50','bg-gray-50'],'',$m[1]) ?>"><?= $m[2] ?></span><?= $l['detail']?' — '.htmlspecialchars($l['detail']):'' ?></p>
          <?php if($l['ip']): ?><p class="text-[10px] text-gray-300 mt-0.5" dir="ltr">IP: <?= htmlspecialchars($l['ip']) ?></p><?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php if($pages>1): ?>
  <div class="flex items-center justify-center gap-1.5 mt-3 flex-wrap">
    <?php for($p=1;$p<=$pages;$p++): ?>
      <a href="?page=<?= $p ?><?= $sid?('&student='.$sid):'' ?>" class="w-9 h-9 rounded-lg text-xs font-bold flex items-center justify-center transition <?= $p===$page?'bg-primary text-white':'bg-gray-50 text-gray-500 border border-gray-100 hover:bg-gray-100' ?>"><?= pnum($p) ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php require __DIR__.'/_footer.php'; ?>
