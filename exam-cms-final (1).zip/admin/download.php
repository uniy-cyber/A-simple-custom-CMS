<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();

/* دانلود فایل پیوست اطلاعیه (سمت مدیر) */
if (isset($_GET['ann'])) {
  $afid=(int)$_GET['ann'];
  $af=DB::one("SELECT * FROM announcement_files WHERE id=?", [$afid]);
  if(!$af){ http_response_code(404); die('فایل یافت نشد.'); }
  $real=realpath(APP_ROOT.'/uploads/'.$af['file_path']); $base=realpath(APP_ROOT.'/uploads');
  if(!$real || strpos($real,$base)!==0 || !is_file($real)){ http_response_code(404); die('فایل روی سرور موجود نیست.'); }
  $name=$af['original_name'] ?: basename($real);
  header('Content-Description: File Transfer');
  header('Content-Type: application/octet-stream');
  header('Content-Disposition: attachment; filename="'.addslashes($name).'"');
  header('Content-Length: '.filesize($real));
  header('Cache-Control: must-revalidate'); header('Pragma: public');
  readfile($real); exit;
}

$id=(int)($_GET['id']??0);
$sub=DB::one("SELECT * FROM submissions WHERE id=?", [$id]);
if(!$sub){ http_response_code(404); die('فایل یافت نشد.'); }

$path=$name=null;
if (isset($_GET['i']) && !empty($sub['files_json'])) {
  $files=json_decode($sub['files_json'],true)?:[];
  $i=(int)$_GET['i'];
  if(isset($files[$i])){ $path=$files[$i]['p']??null; $name=$files[$i]['n']??null; }
} elseif (($_GET['f']??'')==='2') {
  $path=$sub['file_path2']??null; $name=$sub['original_name2']??null;
} else {
  $path=$sub['file_path']??null; $name=$sub['original_name']??null;
}
if(empty($path)){ http_response_code(404); die('این فایل وجود ندارد.'); }

$real=realpath(APP_ROOT.'/uploads/'.$path); $base=realpath(APP_ROOT.'/uploads');
if(!$real || strpos($real,$base)!==0 || !is_file($real)){ http_response_code(404); die('فایل روی سرور موجود نیست.'); }
$name=$name ?: basename($real);
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.addslashes($name).'"');
header('Content-Length: '.filesize($real));
header('Cache-Control: must-revalidate'); header('Pragma: public');
readfile($real); exit;
