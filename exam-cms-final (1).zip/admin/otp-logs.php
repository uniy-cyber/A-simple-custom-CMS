<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  $act=$_POST['act']??'';
  if ($act==='delete') { DB::q("DELETE FROM sms_logs WHERE id=?", [(int)($_POST['id']??0)]); $_SESSION['flash']='لاگ حذف شد.'; }
  elseif ($act==='clear') { DB::q("DELETE FROM sms_logs"); $_SESSION['flash']='همه‌ی لاگ‌ها پاک شد.'; }
  header('Location: otp-logs.php'.(isset($_POST['page'])?('?page='.(int)$_POST['page']):'')); exit;
}

$per=20;
$total=(int)(DB::one("SELECT COUNT(*) n FROM sms_logs")['n'] ?? 0);
$pages=max(1,(int)ceil($total/$per));
$page=max(1,min($pages,(int)($_GET['page']??1)));
$off=($page-1)*$per;
$logs=DB::all("SELECT * FROM sms_logs ORDER BY id DESC LIMIT $per OFFSET $off");

$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$active='otp-logs'; $heading='لاگ پیامک‌ها';
require __DIR__.'/_header.php';
function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
$badge=['sent'=>'bg-emerald-50 text-emerald-600','failed'=>'bg-red-50 text-red-500','simulated'=>'bg-amber-50 text-amber-600'];
$label=['sent'=>'ارسال شد','failed'=>'ناموفق','simulated'=>'شبیه‌سازی'];
?>
<?= flashbox($flash ?? null) ?>
<div class="card-modern p-5">
  <div class="flex items-center justify-between gap-2 mb-4 flex-wrap">
    <h3 class="font-extrabold text-gray-800"><i class="fa-solid fa-clock-rotate-left text-blue-500 ml-1.5"></i>لاگ ارسال پیامک <span class="text-xs text-gray-400 font-bold">(<?= toPersianNumPHP($total) ?> مورد)</span></h3>
    <?php if($total): ?>
    <form method="post" data-confirm="همه‌ی لاگ‌های پیامک حذف شوند؟ این عمل بازگشت‌ناپذیر است.">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="clear">
      <button class="text-[11px] font-bold text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2 hover:bg-red-100 transition"><i class="fa-solid fa-trash-can text-[10px] ml-1"></i>پاک‌سازی همه</button>
    </form>
    <?php endif; ?>
  </div>
  <?php if(!$logs): ?><p class="text-center text-xs text-gray-400 py-10">لاگی ثبت نشده است.</p>
  <?php else: ?>
  <div class="overflow-x-auto"><table class="w-full text-sm whitespace-nowrap">
    <thead><tr class="text-[11px] text-gray-400 border-b border-gray-100"><th class="text-right py-2 font-bold">موبایل</th><th class="text-right font-bold">متن پیام</th><th class="text-right font-bold">وضعیت</th><th class="text-right font-bold">زمان</th><th class="text-center font-bold">حذف</th></tr></thead>
    <tbody>
    <?php foreach($logs as $l): ?>
      <tr class="border-b border-gray-50">
        <td class="py-2.5 text-gray-600 text-xs tabular-nums" dir="ltr"><?= htmlspecialchars($l['mobile']) ?></td>
        <td class="text-gray-500 text-xs max-w-[280px] truncate"><?= htmlspecialchars($l['message']) ?></td>
        <td><span class="text-[10px] font-bold px-2 py-1 rounded <?= $badge[$l['status']]??'bg-gray-100 text-gray-500' ?>"><?= $label[$l['status']]??$l['status'] ?></span></td>
        <td class="text-gray-400 text-xs tabular-nums"><?= jdatetime((int)$l['created_at']) ?></td>
        <td class="text-center">
          <form method="post" data-confirm="این لاگ حذف شود؟">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $l['id'] ?>"><input type="hidden" name="page" value="<?= $page ?>">
            <button class="w-7 h-7 rounded-lg bg-red-50 text-red-500 inline-flex items-center justify-center hover:bg-red-100 transition" title="حذف"><i class="fa-solid fa-trash text-[11px]"></i></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php if($pages>1): ?>
  <div class="flex items-center justify-center gap-1.5 mt-5 flex-wrap">
    <?php for($p=1;$p<=$pages;$p++): ?>
      <a href="?page=<?= $p ?>" class="w-9 h-9 rounded-lg text-xs font-bold flex items-center justify-center transition <?= $p===$page?'bg-primary text-white':'bg-gray-50 text-gray-500 border border-gray-100 hover:bg-gray-100' ?>"><?= toPersianNumPHP($p) ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?php require __DIR__.'/_footer.php'; ?>
