<?php
require __DIR__.'/../includes/bootstrap.php'; require_admin();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_form();
  $act=$_POST['act']??'';
  if ($act==='delete') { DB::q("DELETE FROM students WHERE id=?", [(int)$_POST['id']]); $_SESSION['flash']=['success','دانشجو حذف شد.']; }
  elseif ($act==='save') {
    $id=(int)($_POST['id']??0);
    $fn=clean($_POST['first_name']??''); $ln=clean($_POST['last_name']??'');
    $sid=fa2en(clean($_POST['student_id']??'')); $mob=fa2en(clean($_POST['mobile']??''));
    if($fn===''||$ln===''){ $_SESSION['flash']=['error','نام و نام خانوادگی الزامی است.']; }
    elseif(!valid_student_id($sid)){ $_SESSION['flash']=['error','شماره دانشجویی نامعتبر است.']; }
    elseif(!valid_mobile($mob)){ $_SESSION['flash']=['error','شماره موبایل نامعتبر است.']; }
    elseif(DB::one("SELECT id FROM students WHERE student_id=? AND id<>?", [$sid,$id])){ $_SESSION['flash']=['error','این شماره دانشجویی قبلاً ثبت شده است.']; }
    else {
      DB::q("UPDATE students SET first_name=?,last_name=?,student_id=?,mobile=? WHERE id=?", [$fn,$ln,$sid,$mob,$id]);
      // هماهنگ‌سازی دروس (افزودن/حذف برای تصحیح ثبت‌نام اشتباه)
      if (isset($_POST['courses_submitted'])) {
        $selected = array_map('intval', $_POST['courses'] ?? []);
        $existing = array_map('intval', array_column(DB::all("SELECT course_id FROM enrollments WHERE student_id=?", [$id]), 'course_id'));
        foreach (array_diff($selected,$existing) as $cid) DB::q("INSERT IGNORE INTO enrollments (student_id,course_id,created_at) VALUES (?,?,?)", [$id,$cid,ServerTime::now()]);
        foreach (array_diff($existing,$selected) as $cid) {
          foreach (DB::all("SELECT * FROM submissions WHERE student_id=? AND course_id=?", [$id,$cid]) as $sub) {
            $paths=[]; if(!empty($sub['files_json'])){ foreach((json_decode($sub['files_json'],true)?:[]) as $pf) if(!empty($pf['p'])) $paths[]=$pf['p']; }
            foreach(['file_path','file_path2'] as $col) if(!empty($sub[$col])) $paths[]=$sub[$col];
            foreach($paths as $p){ $abs=APP_ROOT.'/uploads/'.$p; if(is_file($abs)) @unlink($abs); }
          }
          DB::q("DELETE FROM submissions WHERE student_id=? AND course_id=?", [$id,$cid]);
          DB::q("DELETE FROM enrollments WHERE student_id=? AND course_id=?", [$id,$cid]);
        }
      }
      $_SESSION['flash']=['success','اطلاعات دانشجو ویرایش شد.'];
    }
  }
  header('Location: students.php'); exit;
}
$edit = isset($_GET['edit']) ? DB::one("SELECT * FROM students WHERE id=?", [(int)$_GET['edit']]) : null;
$allCourses = $edit ? DB::all("SELECT id,title FROM courses ORDER BY title") : [];
$enrolledIds = $edit ? array_map('intval', array_column(DB::all("SELECT course_id FROM enrollments WHERE student_id=?", [$edit['id']]), 'course_id')) : [];
$q=trim($_GET['q']??'');
if($q!==''){
  $like='%'.fa2en($q).'%';
  $students=DB::all("SELECT s.*, (SELECT COUNT(*) FROM enrollments e WHERE e.student_id=s.id) en FROM students s WHERE s.first_name LIKE ? OR s.last_name LIKE ? OR s.student_id LIKE ? OR s.mobile LIKE ? ORDER BY s.id DESC",[$like,$like,$like,$like]);
}else{
  $students=DB::all("SELECT s.*, (SELECT COUNT(*) FROM enrollments e WHERE e.student_id=s.id) en FROM students s ORDER BY s.id DESC");
}
$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
$active='students'; $heading='دانشجویان';
require __DIR__.'/_header.php';
function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
?>
<?= flashbox($flash ?? null) ?>

<?php if($edit): ?>
<div class="card-modern p-5 mb-4 border-r-4 border-amber-400">
  <h3 class="font-extrabold text-gray-800 mb-4"><i class="fa-solid fa-user-pen text-amber-500 ml-1.5"></i>ویرایش دانشجو</h3>
  <form method="post" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $edit['id'] ?>">
    <div><label class="block font-bold text-[11px] text-gray-600 mb-1">نام</label><input name="first_name" class="input-modern text-sm" value="<?= htmlspecialchars($edit['first_name']) ?>"></div>
    <div><label class="block font-bold text-[11px] text-gray-600 mb-1">نام خانوادگی</label><input name="last_name" class="input-modern text-sm" value="<?= htmlspecialchars($edit['last_name']) ?>"></div>
    <div><label class="block font-bold text-[11px] text-gray-600 mb-1">شماره دانشجویی</label><input name="student_id" class="input-modern text-sm tabular-nums" dir="ltr" value="<?= htmlspecialchars($edit['student_id']) ?>"></div>
    <div><label class="block font-bold text-[11px] text-gray-600 mb-1">موبایل</label><input name="mobile" class="input-modern text-sm tabular-nums" dir="ltr" value="<?= htmlspecialchars($edit['mobile']) ?>"></div>
    <div class="sm:col-span-2 lg:col-span-4 flex gap-2">
      <button class="px-5 py-2.5 rounded-xl bg-primary text-white text-sm font-bold hover:bg-blue-800 transition"><i class="fa-solid fa-floppy-disk ml-1"></i>ذخیره</button>
      <a href="students.php" class="px-5 py-2.5 rounded-xl bg-gray-100 text-gray-600 text-sm font-bold hover:bg-gray-200 transition">انصراف</a>
    </div>
    <div class="sm:col-span-2 lg:col-span-4 border-t border-gray-100 pt-3 mt-1">
      <input type="hidden" name="courses_submitted" value="1">
      <p class="font-extrabold text-xs text-gray-700 mb-2"><i class="fa-solid fa-book text-blue-500 ml-1"></i>دروس دانشجو (برای تصحیح، تیک بزنید یا بردارید)</p>
      <?php if(!$allCourses): ?>
        <p class="text-[11px] text-gray-400">درسی تعریف نشده است.</p>
      <?php else: ?>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        <?php foreach($allCourses as $co): ?>
          <label class="flex items-center gap-2 text-xs font-bold text-gray-600 bg-gray-50 border border-gray-100 rounded-lg px-3 py-2 cursor-pointer hover:bg-gray-100">
            <input type="checkbox" name="courses[]" value="<?= $co['id'] ?>" class="w-4 h-4 accent-primary" <?= in_array((int)$co['id'],$enrolledIds,true)?'checked':'' ?>>
            <?= htmlspecialchars($co['title']) ?>
          </label>
        <?php endforeach; ?>
      </div>
      <p class="text-[10px] text-red-400 mt-2 text-justify leading-relaxed">توجه: با برداشتن تیک یک درس، ثبت‌نام و همه‌ی فایل‌های پاسخ دانشجو در آن درس حذف می‌شود.</p>
      <?php endif; ?>
    </div>
  </form>
</div>
<?php endif; ?>
<div class="card-modern p-5">
  <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
    <h3 class="font-extrabold text-gray-800"><i class="fa-solid fa-users text-blue-500 ml-1.5"></i>دانشجویان <span class="text-xs text-gray-400 font-bold">(<?= toPersianNumPHP(count($students)) ?>)</span></h3>
    <form method="get" class="flex items-center gap-2">
      <input name="q" value="<?= htmlspecialchars($q) ?>" placeholder="جستجوی نام / شماره / موبایل" class="input-modern text-xs py-2 w-60">
      <button class="px-4 py-2 rounded-xl bg-primary text-white text-xs font-bold"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>
  <?php if(!$students): ?><p class="text-center text-xs text-gray-400 py-10">دانشجویی یافت نشد.</p>
  <?php else: ?>
  <div class="overflow-x-auto"><table class="w-full text-sm whitespace-nowrap">
    <thead><tr class="text-[11px] text-gray-400 border-b border-gray-100">
      <th class="text-right py-2 font-bold">نام</th><th class="text-right font-bold">شماره دانشجویی</th><th class="text-right font-bold">موبایل</th><th class="text-right font-bold">دروس</th><th class="text-right font-bold">تاریخ ثبت‌نام</th><th class="text-center font-bold">عملیات</th>
    </tr></thead>
    <tbody>
    <?php foreach($students as $s): ?>
      <tr class="border-b border-gray-50 hover:bg-gray-50/50">
        <td class="py-2.5 font-bold text-gray-700"><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></td>
        <td class="text-gray-500 text-xs tabular-nums" dir="ltr"><?= htmlspecialchars($s['student_id']) ?></td>
        <td class="text-gray-500 text-xs tabular-nums" dir="ltr"><?= htmlspecialchars($s['mobile']) ?></td>
        <td class="text-gray-500 text-xs"><?= toPersianNumPHP($s['en']) ?></td>
        <td class="text-gray-400 text-xs tabular-nums"><?= jdate((int)$s['created_at']) ?></td>
        <td class="text-center">
          <div class="flex items-center justify-center gap-1.5">
            <a href="students.php?edit=<?= $s['id'] ?>" class="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 inline-flex items-center justify-center hover:bg-amber-100 transition" title="ویرایش"><i class="fa-solid fa-pen text-xs"></i></a>
            <form method="post" data-confirm="این دانشجو و تمام داده‌هایش حذف شود؟">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>">
              <button class="w-8 h-8 rounded-lg bg-red-50 text-red-500 inline-flex items-center justify-center hover:bg-red-100 transition" title="حذف"><i class="fa-solid fa-trash text-xs"></i></button>
            </form>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</div>
<?php require __DIR__.'/_footer.php'; ?>
