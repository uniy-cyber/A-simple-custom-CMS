<?php
require __DIR__.'/includes/bootstrap.php';
$s = require_student();
$now = ServerTime::now();

$rows = DB::all(
  "SELECT c.id, c.title, c.exam_end, c.appeal_start, c.appeal_end,
          e.grade, e.grade_published,
          sub.original_name, sub.submitted_at,
          ap.id AS ap_id, ap.status AS ap_status, ap.message AS ap_message, ap.admin_reply AS ap_reply, ap.created_at AS ap_created
   FROM courses c
   JOIN enrollments e ON e.course_id=c.id AND e.student_id=?
   LEFT JOIN submissions sub ON sub.course_id=c.id AND sub.student_id=?
   LEFT JOIN appeals ap ON ap.course_id=c.id AND ap.student_id=?
   WHERE c.active=1
   ORDER BY c.exam_start IS NULL, c.exam_start", [$s['id'],$s['id'],$s['id']]);

function appeal_window(array $r, int $now): array {
  if (empty($r['appeal_start']) || empty($r['appeal_end'])) return ['open'=>false,'reason'=>'بازه‌ی اعتراض برای این درس تعیین نشده است.'];
  if ($now < (int)$r['appeal_start']) return ['open'=>false,'reason'=>'بازه‌ی اعتراض هنوز آغاز نشده است.'];
  if ($now > (int)$r['appeal_end'])   return ['open'=>false,'reason'=>'مهلت اعتراض به پایان رسیده است.'];
  return ['open'=>true,'reason'=>''];
}

function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
function gradeFmt($g){ if($g===null) return null; $g=rtrim(rtrim(number_format((float)$g,2,'.',''),'0'),'.'); return toPersianNumPHP($g); }
$st_map=['pending'=>['در حال بررسی','bg-amber-50 text-amber-600'],'accepted'=>['پذیرفته شد','bg-emerald-50 text-emerald-600'],'rejected'=>['رد شد','bg-red-50 text-red-500']];
$page_title='کارنامه - '.setting('site_name','پورتال آموزشی');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<div id="toast-container"></div>
<?php require __DIR__.'/partials/header-student.php'; ?>

<main class="flex-1 pt-20 pb-10 px-4">
  <div class="max-w-4xl mx-auto space-y-5 fade-in">
    <div class="flex items-end justify-between">
      <div>
        <h2 class="font-extrablack text-xl md:text-2xl text-gray-800 tracking-tight"><i class="fa-solid fa-file-lines text-amber-500 ml-2"></i>کارنامه‌ی من</h2>
        <p class="text-xs text-gray-500 mt-1">نمرات دروس و وضعیت اعتراض‌ها</p>
      </div>
      <a href="<?= base_url('dashboard.php') ?>" class="text-[11px] font-bold text-gray-500 hover:text-gray-700"><i class="fa-solid fa-arrow-right text-[9px]"></i> داشبورد</a>
    </div>

    <?php if(!$rows): ?>
      <div class="card-modern p-8 text-center text-sm text-gray-400"><i class="fa-solid fa-folder-open text-2xl mb-2 block"></i>درسی برای نمایش وجود ندارد.</div>
    <?php else: foreach($rows as $r): $g=gradeFmt($r['grade']); $published=(int)$r['grade_published']===1; ?>
      <div class="card-modern p-4 md:p-5">
        <div class="flex items-center justify-between gap-3 flex-wrap">
          <div class="flex items-center gap-3 min-w-0">
            <div class="w-11 h-11 rounded-xl bg-blue-50 text-primary flex items-center justify-center shrink-0"><i class="fa-solid fa-book-open"></i></div>
            <div class="min-w-0">
              <p class="font-extrabold text-sm text-gray-800 truncate"><?= htmlspecialchars($r['title']) ?></p>
              <p class="text-[11px] text-gray-400 mt-0.5">
                <?php if($r['submitted_at']): ?><i class="fa-solid fa-paperclip text-[9px]"></i> پاسخ ارسال شده<?php else: ?>پاسخی ارسال نشده<?php endif; ?>
              </p>
            </div>
          </div>
          <!-- نمره -->
          <div class="text-center shrink-0">
            <?php if($published && $g!==null):
              $gv=(float)$r['grade']; $pass=$gv>=10;
              $cBox=$pass?'bg-emerald-50 border-emerald-100':'bg-red-50 border-red-100';
              $cNum=$pass?'text-emerald-600':'text-red-500';
              $cTag=$pass?'bg-emerald-500':'bg-red-500';
            ?>
              <div class="rounded-2xl border <?= $cBox ?> px-3 py-2 flex flex-col items-center justify-center min-w-[88px]">
                <span class="font-extrablack text-2xl <?= $cNum ?> tabular-nums leading-none"><?= $g ?></span>
                <span class="text-[10px] font-bold text-gray-500 mt-1 leading-tight"><?= htmlspecialchars(num2fa_words($gv)) ?></span>
                <span class="mt-1.5 text-[10px] font-extrabold text-white <?= $cTag ?> rounded-full px-2.5 py-0.5"><?= $pass?'قبول':'مردود' ?></span>
              </div>
            <?php else: ?>
              <div class="px-3 py-2 rounded-xl bg-gray-50 border border-gray-100 text-[11px] font-bold text-gray-400">اعلام نشده</div>
            <?php endif; ?>
          </div>
        </div>

        <!-- بخش اعتراض -->
        <?php if($published && $g!==null): $win=appeal_window($r,$now); ?>
          <div class="mt-4 pt-3 border-t border-gray-100">
            <?php if($r['ap_id']): $stt=$st_map[$r['ap_status']]??['نامشخص','bg-gray-100 text-gray-500']; ?>
              <div class="bg-gray-50/70 rounded-xl p-3">
                <div class="flex items-center justify-between mb-1.5">
                  <span class="text-[11px] font-extrabold text-gray-600"><i class="fa-solid fa-gavel text-amber-500 ml-1"></i>اعتراض شما</span>
                  <span class="text-[10px] font-bold px-2 py-0.5 rounded <?= $stt[1] ?>"><?= $stt[0] ?></span>
                </div>
                <p class="text-[11px] text-gray-500 leading-relaxed text-justify"><?= nl2br(htmlspecialchars($r['ap_message'])) ?></p>
                <?php if($r['ap_reply']): ?>
                  <div class="mt-2 pt-2 border-t border-gray-200/70">
                    <span class="text-[10px] font-extrabold text-primary"><i class="fa-solid fa-reply text-[9px] ml-1"></i>پاسخ مدیر:</span>
                    <p class="text-[11px] text-gray-600 leading-relaxed mt-1 text-justify"><?= nl2br(htmlspecialchars($r['ap_reply'])) ?></p>
                  </div>
                <?php endif; ?>
              </div>
            <?php elseif($win['open']): ?>
              <div class="flex items-center justify-between gap-2 flex-wrap">
                <button onclick="openAppeal(<?= (int)$r['id'] ?>,'<?= htmlspecialchars(addslashes($r['title'])) ?>')" class="text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 hover:bg-amber-100 transition">
                  <i class="fa-solid fa-gavel text-[10px] ml-1"></i>اعتراض به نمره
                </button>
                <span class="text-[10px] text-gray-400 tabular-nums">مهلت اعتراض تا <?= jdatetime((int)$r['appeal_end']) ?></span>
              </div>
            <?php else: ?>
              <p class="text-[11px] text-gray-400 bg-gray-50/70 rounded-lg px-3 py-2 text-justify leading-relaxed"><i class="fa-regular fa-circle-xmark text-gray-300 ml-1"></i><?= htmlspecialchars($win['reason']) ?></p>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; endif; ?>
  </div>
</main>

<!-- مُدال اعتراض -->
<div id="appeal-modal" class="modal-overlay" style="display:none">
  <div class="modal-box" style="max-width:430px">
    <div class="modal-icon" style="background:#fef3c7;color:#d97706"><i class="fa-solid fa-gavel"></i></div>
    <p class="modal-title">اعتراض به نمره</p>
    <p class="modal-text" id="appeal-course" style="text-align:center"></p>
    <textarea id="appeal-text" rows="4" class="input-modern mt-2" style="text-align:justify;font-weight:500" placeholder="دلیل اعتراض خود را به‌صورت کامل بنویسید..."></textarea>
    <div class="modal-actions">
      <button class="btn-modal-cancel" onclick="closeAppeal()">انصراف</button>
      <button class="btn-modal-ok" id="appeal-submit" onclick="submitAppeal()">ثبت اعتراض</button>
    </div>
  </div>
</div>

<script src="<?= asset('assets/js/app.js') ?>"></script>
<script>
let appealCourse=0;
const am=document.getElementById('appeal-modal');
function openAppeal(cid,title){
  appealCourse=cid;
  document.getElementById('appeal-course').textContent='درس: '+title;
  document.getElementById('appeal-text').value='';
  am.style.display='flex'; requestAnimationFrame(()=>am.classList.add('show'));
}
function closeAppeal(){ am.classList.remove('show'); setTimeout(()=>am.style.display='none',200); }
am.addEventListener('click',e=>{ if(e.target===am) closeAppeal(); });
async function submitAppeal(){
  const msg=document.getElementById('appeal-text').value.trim();
  if(msg.length<5){ showToast('متن اعتراض را کامل‌تر بنویسید.'); return; }
  const btn=document.getElementById('appeal-submit'); btn.disabled=true; btn.textContent='در حال ثبت...';
  try{
    const j=await apiPost('api/appeal.php',{course_id:appealCourse,message:msg});
    if(!j.ok){ showToast(j.message||'خطا در ثبت اعتراض.'); btn.disabled=false; btn.textContent='ثبت اعتراض'; return; }
    showToast(j.message,'success'); closeAppeal();
    setTimeout(()=>location.reload(),1200);
  }catch(e){ showToast('خطا در ارتباط با سرور.'); btn.disabled=false; btn.textContent='ثبت اعتراض'; }
}
</script>
</body>
</html>
