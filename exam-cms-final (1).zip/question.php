<?php
require __DIR__.'/includes/bootstrap.php';
$s = require_student();
$cid = (int)($_GET['course'] ?? 0);

$c = DB::one("SELECT c.* FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE c.id=? AND e.student_id=? AND c.active=1", [$cid,$s['id']]);
if (!$c || empty($c['question_file'])) { http_response_code(404); die('فایل سوالات موجود نیست.'); }

// فقط در بازه‌ی آزمون (از ۵ دقیقه قبل تا پایان)
$now = ServerTime::now();
if ($c['exam_start']===null || $now < $c['exam_start']-300) { http_response_code(403); die('هنوز زمان دسترسی به سوالات فرا نرسیده است.'); }
if ($c['exam_end']!==null && $now > $c['exam_end']) { http_response_code(403); die('مهلت آزمون به پایان رسیده است.'); }

$real = realpath(APP_ROOT.'/uploads/'.$c['question_file']);
$base = realpath(APP_ROOT.'/uploads');
if (!$real || strpos($real,$base)!==0 || !is_file($real)) { http_response_code(404); die('فایل روی سرور موجود نیست.'); }

log_activity($s['id'],'question','دریافت سوالات درس: '.$c['title']);
$name = $c['question_original'] ?: basename($real);
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.addslashes($name).'"');
header('Content-Length: '.filesize($real));
header('Cache-Control: must-revalidate');
readfile($real); exit;
