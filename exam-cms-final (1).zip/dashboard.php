<?php
require __DIR__.'/includes/bootstrap.php';
$s = require_student();
$now = ServerTime::now();

$courses = DB::all("SELECT c.* FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE e.student_id=? AND c.active=1 ORDER BY c.exam_start IS NULL, c.exam_start", [$s['id']]);
$courseIds = array_column($courses,'id');

// اطلاعیه‌های منتشرشده (عمومی یا مربوط به دروس دانشجو)
$ann = [];
if ($courseIds) {
  $ph = implode(',', array_fill(0,count($courseIds),'?'));
  $ann = DB::all("SELECT a.*, c.title AS course_title FROM announcements a LEFT JOIN courses c ON c.id=a.course_id
                  WHERE a.publish_at<=? AND (a.course_id IS NULL OR a.course_id IN ($ph)) ORDER BY a.publish_at DESC LIMIT 20",
                  array_merge([$now], $courseIds));
} else {
  $ann = DB::all("SELECT a.*, NULL AS course_title FROM announcements a WHERE a.publish_at<=? AND a.course_id IS NULL ORDER BY a.publish_at DESC LIMIT 20", [$now]);
}

// فایل‌های پیوست اطلاعیه‌ها (گروه‌بندی بر اساس اطلاعیه)
$annFiles = [];
if ($ann) {
  $aids = array_column($ann,'id');
  $ph2 = implode(',', array_fill(0,count($aids),'?'));
  try {
    foreach (DB::all("SELECT * FROM announcement_files WHERE announcement_id IN ($ph2) ORDER BY id", $aids) as $f) {
      $annFiles[(int)$f['announcement_id']][] = $f;
    }
  } catch (Throwable $e) { $annFiles = []; }
}

function exam_state(array $c, int $now): array {
  if ($c['exam_start']===null || $c['exam_end']===null) return ['label'=>'زمان آزمون اعلام نشده','color'=>'gray','can'=>false];
  if ($now < $c['exam_start']-300) return ['label'=>'آزمون در انتظار','color'=>'amber','can'=>false];
  if ($now <= $c['exam_end'])      return ['label'=>'آزمون فعال است','color'=>'emerald','can'=>true];
  return ['label'=>'آزمون پایان یافته','color'=>'red','can'=>false];
}
$page_title = 'داشبورد - '.setting('site_name','پورتال آموزشی');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<div id="toast-container"></div>
<?php require __DIR__.'/partials/header-student.php'; ?>

<main class="flex-1 pt-20 pb-10 px-4">
  <div class="max-w-5xl mx-auto space-y-5 fade-in">
    <!-- خوش‌آمد -->
    <div class="card-modern p-5 md:p-6 flex items-center justify-between">
      <div>
        <h2 class="font-extrablack text-xl text-gray-800">سلام، <?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?> 👋</h2>
        <p class="text-xs text-gray-500 mt-1.5 tabular-nums" dir="ltr"><?= htmlspecialchars($s['student_id']) ?></p>
      </div>
      <div class="w-12 h-12 rounded-2xl bg-blue-50 text-primary flex items-center justify-center text-xl border border-blue-100"><i class="fa-solid fa-user-graduate"></i></div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
      <!-- دروس و آزمون‌ها -->
      <div class="lg:col-span-2 space-y-4">
        <h3 class="font-extrabold text-base text-gray-700"><i class="fa-solid fa-layer-group text-blue-500 ml-1.5"></i>دروس و آزمون‌های من</h3>
        <?php if(!$courses): ?>
          <div class="card-modern p-8 text-center text-sm text-gray-400"><i class="fa-solid fa-folder-open text-2xl mb-2 block"></i>هنوز در درسی ثبت‌نام نکرده‌اید.</div>
        <?php else: foreach($courses as $c): $st=exam_state($c,$now);
          $colors=['gray'=>'bg-gray-100 text-gray-500','amber'=>'bg-amber-50 text-amber-600','emerald'=>'bg-emerald-50 text-emerald-600','red'=>'bg-red-50 text-red-500']; ?>
          <div class="card-modern p-4 md:p-5 flex items-center justify-between gap-3">
            <div class="flex items-center gap-3 min-w-0">
              <div class="w-11 h-11 rounded-xl bg-blue-50 text-primary flex items-center justify-center shrink-0"><i class="fa-solid fa-book-open"></i></div>
              <div class="min-w-0">
                <p class="font-extrabold text-sm text-gray-800 truncate"><?= htmlspecialchars($c['title']) ?></p>
                <p class="text-[11px] text-gray-400 mt-0.5">
                  <?php if($c['exam_start']): ?><i class="fa-regular fa-clock"></i> <?= jdatetime((int)$c['exam_start']) ?><?php else: ?>زمان نامشخص<?php endif; ?>
                </p>
              </div>
            </div>
            <div class="flex flex-col items-end gap-2 shrink-0">
              <span class="text-[10px] font-bold px-2.5 py-1 rounded-md <?= $colors[$st['color']] ?>"><?= $st['label'] ?></span>
              <?php if($st['can']): ?>
                <a href="<?= base_url('exam.php?course='.$c['id']) ?>" class="text-[11px] font-bold text-white bg-primary px-3 py-1.5 rounded-lg hover:bg-blue-800 transition flex items-center gap-1.5">ورود <i class="fa-solid fa-arrow-left text-[9px]"></i></a>
              <?php else: ?>
                <a href="<?= base_url('exam.php?course='.$c['id']) ?>" class="text-[11px] font-bold text-gray-400 px-3 py-1.5">مشاهده</a>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>

      <!-- تایم‌لاین اطلاعیه‌ها -->
      <div class="space-y-4">
        <h3 class="font-extrabold text-base text-gray-700"><i class="fa-solid fa-bullhorn text-amber-500 ml-1.5"></i>اطلاعیه‌ها</h3>
        <div class="card-modern p-5">
          <?php if(!$ann): ?>
            <p class="text-center text-xs text-gray-400 py-4">اطلاعیه‌ای موجود نیست.</p>
          <?php else: ?>
            <div class="space-y-0">
              <?php foreach($ann as $a): ?>
                <div class="timeline-item">
                  <div class="timeline-dot"></div>
                  <p class="font-extrabold text-sm text-gray-800 leading-7 no-justify"><?= htmlspecialchars($a['title']) ?></p>
                  <?php if($a['course_title']): ?><span class="text-[9px] bg-blue-50 text-primary font-bold px-1.5 py-0.5 rounded"><?= htmlspecialchars($a['course_title']) ?></span><?php endif; ?>
                  <p class="text-[11px] text-gray-500 mt-1 leading-relaxed"><?= nl2br(htmlspecialchars($a['body'])) ?></p>
                  <?php $afs=$annFiles[(int)$a['id']]??[]; if($afs): ?>
                    <div class="mt-2 space-y-1.5">
                      <?php foreach($afs as $f): $ic=file_icon($f['original_name']); ?>
                        <a href="<?= base_url('download-file.php?f='.$f['id']) ?>" class="group flex items-center gap-2 bg-gray-50 hover:bg-amber-50 rounded-xl p-2 transition border border-transparent hover:border-amber-200">
                          <div class="w-8 h-8 rounded-lg <?= $ic[1] ?> flex items-center justify-center shrink-0"><i class="fa-solid <?= $ic[0] ?> text-xs"></i></div>
                          <div class="min-w-0 flex-1">
                            <p class="font-bold text-[11px] text-gray-700 truncate"><?= htmlspecialchars($f['description'] ?: $f['original_name']) ?></p>
                            <p class="text-[9px] text-gray-400 tabular-nums mt-0.5"><?= $ic[2] ?> · <?= human_size((int)$f['file_size']) ?> · <i class="fa-solid fa-download"></i> <?= pnum((int)$f['download_count']) ?></p>
                          </div>
                          <i class="fa-solid fa-circle-down text-gray-300 group-hover:text-amber-500 transition shrink-0"></i>
                        </a>
                      <?php endforeach; ?>
                    </div>
                  <?php endif; ?>
                  <p class="text-[9px] text-gray-300 mt-1.5 tabular-nums"><?= jdatetime((int)$a['publish_at']) ?></p>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</main>

<script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>
