-- ساختار دیتابیس سیستم آزمون آنلاین
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS settings (
  skey   VARCHAR(64) PRIMARY KEY,
  svalue TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  created_at INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(80) NOT NULL,
  last_name  VARCHAR(80) NOT NULL,
  student_id VARCHAR(20) UNIQUE NOT NULL,
  mobile     VARCHAR(15) NOT NULL,
  created_at INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  code  VARCHAR(40) NULL,
  reg_start INT NULL,
  reg_end   INT NULL,
  reg_unlimited TINYINT(1) NOT NULL DEFAULT 0,
  exam_start INT NULL,
  exam_end   INT NULL,
  max_file_mb INT NOT NULL DEFAULT 10,
  allowed_types VARCHAR(255) NOT NULL DEFAULT 'pdf,zip,rar,docx',
  active TINYINT(1) NOT NULL DEFAULT 1,
  appeal_start INT NULL,
  appeal_end   INT NULL,
  question_file VARCHAR(255) NULL,
  question_original VARCHAR(255) NULL,
  question_desc TEXT NULL,
  created_at INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id  INT NOT NULL,
  created_at INT NOT NULL,
  grade DECIMAL(5,2) NULL,
  grade_published TINYINT(1) NOT NULL DEFAULT 0,
  graded_at INT NULL,
  UNIQUE KEY uniq_enroll (student_id, course_id),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS submissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id  INT NOT NULL,
  file_path  VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  file_size  INT NOT NULL,
  file_path2  VARCHAR(255) NULL,
  original_name2 VARCHAR(255) NULL,
  file_size2  INT NULL,
  files_json TEXT NULL,
  submitted_at INT NOT NULL,
  ip VARCHAR(45) NULL,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS appeals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id  INT NOT NULL,
  message TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  admin_reply TEXT NULL,
  created_at INT NOT NULL,
  replied_at INT NULL,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NULL,
  title VARCHAR(180) NOT NULL,
  body  TEXT NOT NULL,
  publish_at INT NOT NULL,
  created_at INT NOT NULL,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcement_files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  announcement_id INT NOT NULL,
  file_path     VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  file_size     INT NOT NULL DEFAULT 0,
  description   VARCHAR(500) NULL,
  download_count INT NOT NULL DEFAULT 0,
  created_at    INT NOT NULL,
  KEY k_annfile_ann (announcement_id),
  FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS otp_codes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  mobile VARCHAR(15) NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  expires_at INT NOT NULL,
  used TINYINT(1) NOT NULL DEFAULT 0,
  created_at INT NOT NULL,
  ip VARCHAR(45) NULL,
  INDEX idx_student (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sms_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  mobile VARCHAR(15) NOT NULL,
  message TEXT NOT NULL,
  status VARCHAR(20) NOT NULL,
  response VARCHAR(500) NULL,
  created_at INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  body TEXT NULL,
  type VARCHAR(20) NOT NULL DEFAULT 'info',
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at INT NOT NULL,
  KEY k_notif_student (student_id),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activity_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  action VARCHAR(50) NOT NULL,
  detail VARCHAR(300) NULL,
  ip VARCHAR(45) NULL,
  created_at INT NOT NULL,
  KEY k_act_student (student_id),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
