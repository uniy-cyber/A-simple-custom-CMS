<?php
/* ============================================================
   نصب‌کننده‌ی تحت وب سیستم آزمون آنلاین (Installation Wizard)
   ============================================================ */
declare(strict_types=1);
error_reporting(E_ALL); ini_set('display_errors','1');
session_start();

define('APP_ROOT', dirname(__DIR__));
$lockFile   = APP_ROOT.'/config/installed.lock';
$configFile = APP_ROOT.'/config/config.php';

/* اگر قبلاً نصب شده، جلوگیری از اجرای مجدد */
if (file_exists($lockFile) || file_exists($configFile)) {
  http_response_code(403);
  echo installed_page();
  exit;
}

$step  = (int)($_GET['step'] ?? 1);
$error = '';
$ok    = '';

/* ---------- پردازش هر مرحله ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'db') {
    $_SESSION['db'] = [
      'host'=>trim($_POST['db_host']??''), 'name'=>trim($_POST['db_name']??''),
      'user'=>trim($_POST['db_user']??''), 'pass'=>$_POST['db_pass']??'',
    ];
    try {
      $dsn='mysql:host='.$_SESSION['db']['host'].';dbname='.$_SESSION['db']['name'].';charset=utf8mb4';
      new PDO($dsn,$_SESSION['db']['user'],$_SESSION['db']['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
      header('Location: ?step=3'); exit;
    } catch (Throwable $e) { $error='اتصال به دیتابیس ناموفق بود: '.$e->getMessage(); $step=2; }
  }

  if ($action === 'settings') {
    $_SESSION['cfg'] = [
      'site_name'=>trim($_POST['site_name']??'پورتال آموزشی'),
      'timezone'=>trim($_POST['timezone']??'Asia/Tehran'),
    ];
    header('Location: ?step=4'); exit;
  }

  if ($action === 'finish') {
    $admin_user = trim($_POST['admin_user']??'');
    $admin_pass = $_POST['admin_pass']??'';
    $admin_name = trim($_POST['admin_name']??'');
    if (strlen($admin_user)<3 || strlen($admin_pass)<6 || $admin_name==='') {
      $error='اطلاعات مدیر ناقص است (نام کاربری ≥۳، رمز ≥۶ کاراکتر).'; $step=4;
    } else {
      try {
        $db=$_SESSION['db']; $cfg=$_SESSION['cfg']??['site_name'=>'پورتال آموزشی','timezone'=>'Asia/Tehran'];
        $dsn='mysql:host='.$db['host'].';dbname='.$db['name'].';charset=utf8mb4';
        $pdo=new PDO($dsn,$db['user'],$db['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);

        // اجرای اسکیما
        $sql=file_get_contents(__DIR__.'/schema.sql');
        foreach (array_filter(array_map('trim', explode(';',$sql))) as $stmt) {
          if ($stmt!=='' && stripos($stmt,'SET NAMES')!==0) $pdo->exec($stmt);
          elseif (stripos($stmt,'SET NAMES')===0) $pdo->exec($stmt);
        }

        $now=time();
        // ادمین اصلی
        $st=$pdo->prepare("INSERT INTO admins (username,password_hash,full_name,created_at) VALUES (?,?,?,?)");
        $st->execute([$admin_user, password_hash($admin_pass,PASSWORD_DEFAULT), $admin_name, $now]);

        // تنظیمات پیش‌فرض
        $defaults=[
          'site_name'=>$cfg['site_name'], 'timezone'=>$cfg['timezone'],
          'kavenegar_apikey'=>'', 'kavenegar_sender'=>'', 'kavenegar_template'=>'', 'sms_enabled'=>'0',
          'otp_validity_minutes'=>'60', 'otp_resend_seconds'=>'120',
          'login_enabled'=>'1', 'register_enabled'=>'1',
          'login_disabled_msg'=>'ورود به سیستم موقتاً غیرفعال است.',
          'register_disabled_msg'=>'ثبت‌نام موقتاً غیرفعال است.',
          'answer_max_files'=>'1',
        ];
        $sst=$pdo->prepare("INSERT INTO settings (skey,svalue) VALUES (?,?) ON DUPLICATE KEY UPDATE svalue=VALUES(svalue)");
        foreach ($defaults as $k=>$v) $sst->execute([$k,$v]);

        // نوشتن config.php
        $key=bin2hex(random_bytes(16));
        $conf="<?php\n".
          "define('DB_HOST', ".var_export($db['host'],true).");\n".
          "define('DB_NAME', ".var_export($db['name'],true).");\n".
          "define('DB_USER', ".var_export($db['user'],true).");\n".
          "define('DB_PASS', ".var_export($db['pass'],true).");\n".
          "define('DB_CHARSET', 'utf8mb4');\n".
          "define('APP_KEY', '$key');\n".
          "define('APP_INSTALLED', true);\n";
        if (!is_dir(APP_ROOT.'/config')) mkdir(APP_ROOT.'/config',0755,true);
        file_put_contents($configFile, $conf);
        file_put_contents($lockFile, 'installed at '.date('c'));
        @chmod($configFile, 0444);

        unset($_SESSION['db'],$_SESSION['cfg']);
        $step=5;
      } catch (Throwable $e) { $error='خطا در نصب: '.$e->getMessage(); $step=4; }
    }
  }
}

/* ---------- بررسی پیش‌نیازها ---------- */
function checks(): array {
  return [
    ['PHP نسخه ≥ 8.0', version_compare(PHP_VERSION,'8.0.0','>=')],
    ['افزونه PDO', extension_loaded('pdo')],
    ['افزونه PDO MySQL', extension_loaded('pdo_mysql')],
    ['افزونه mbstring', extension_loaded('mbstring')],
    ['افزونه JSON', function_exists('json_encode')],
    ['دسترسی نوشتن در config/', is_writable(APP_ROOT.'/config') || @mkdir(APP_ROOT.'/config',0755,true)],
    ['دسترسی نوشتن در uploads/', is_writable(APP_ROOT.'/uploads') || @mkdir(APP_ROOT.'/uploads',0755,true)],
  ];
}
function checks_pass(): bool { foreach (checks() as $c) if (!$c[1]) return false; return true; }

function installed_page(): string {
  return '<!DOCTYPE html><html dir="rtl" lang="fa"><meta charset="utf-8"><body style="font-family:Tahoma;background:#f8fafc;display:flex;height:100vh;align-items:center;justify-content:center"><div style="background:#fff;padding:2rem 3rem;border-radius:1rem;box-shadow:0 8px 30px rgba(0,0,0,.08);text-align:center"><h2 style="color:#dc2626">⛔ سیستم قبلاً نصب شده است</h2><p style="color:#475569">برای نصب مجدد، فایل <code>config/config.php</code> و <code>config/installed.lock</code> را حذف کنید.</p></div></body></html>';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>نصب سیستم آزمون آنلاین</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer"/>
<link rel="stylesheet" href="../assets/css/app.css">
<script>tailwind.config={theme:{extend:{colors:{primary:{DEFAULT:'#1e3a8a',light:'#dbeafe'},accent:{DEFAULT:'#f59e0b'}}}}}</script>
</head>
<body class="min-h-screen flex items-center justify-center px-4 py-10">
<div class="w-full max-w-xl fade-in">
  <div class="text-center mb-6">
    <div class="w-14 h-14 bg-blue-50 text-primary rounded-2xl flex items-center justify-center text-xl mx-auto mb-3 border border-blue-100">
      <i class="fa-solid fa-cubes"></i>
    </div>
    <h1 class="font-extrablack text-2xl text-gray-800">نصب‌کننده‌ی سیستم آزمون آنلاین</h1>
    <p class="text-xs text-gray-500 mt-1.5">مرحله <?= $step ?> از ۵</p>
  </div>

  <!-- نوار مراحل -->
  <div class="wizard-tabs">
    <?php $icons=['fa-list-check','fa-database','fa-sliders','fa-user-shield','fa-circle-check'];
    for($i=1;$i<=5;$i++): ?>
      <div class="wizard-step-indicator <?= $i<$step?'completed':($i==$step?'active':'pending') ?> mx-auto">
        <i class="fa-solid <?= $icons[$i-1] ?> text-sm"></i>
      </div>
      <?php if($i<5): ?><div class="wizard-line <?= $i<$step?'completed':'' ?>"></div><?php endif; ?>
    <?php endfor; ?>
  </div>

  <div class="card-modern p-6 md:p-8">
    <?php if($error): ?><div class="mb-4 bg-red-50 border border-red-200 text-red-700 text-xs font-bold rounded-lg p-3"><i class="fa-solid fa-circle-exclamation ml-1"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <?php if($step==1): ?>
      <h3 class="font-extrabold text-lg text-gray-800 mb-4"><i class="fa-solid fa-list-check text-blue-500 ml-1.5"></i>بررسی پیش‌نیازها</h3>
      <div class="space-y-2">
        <?php foreach(checks() as $c): ?>
          <div class="flex items-center justify-between bg-gray-50 border border-gray-100 rounded-lg px-4 py-2.5">
            <span class="text-sm font-bold text-gray-700"><?= $c[0] ?></span>
            <?php if($c[1]): ?><span class="text-emerald-500 text-sm"><i class="fa-solid fa-circle-check"></i></span>
            <?php else: ?><span class="text-red-500 text-sm"><i class="fa-solid fa-circle-xmark"></i></span><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
      <?php if(checks_pass()): ?>
        <a href="?step=2" class="mt-6 w-full py-3 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2 text-sm">ادامه <i class="fa-solid fa-arrow-left text-xs"></i></a>
      <?php else: ?>
        <p class="mt-5 text-center text-xs text-red-500 font-bold">برخی پیش‌نیازها برقرار نیستند. لطفاً ابتدا آن‌ها را رفع کنید.</p>
      <?php endif; ?>

    <?php elseif($step==2): ?>
      <h3 class="font-extrabold text-lg text-gray-800 mb-4"><i class="fa-solid fa-database text-blue-500 ml-1.5"></i>تنظیمات دیتابیس</h3>
      <form method="post">
        <input type="hidden" name="action" value="db">
        <div class="grid grid-cols-1 gap-3">
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">هاست دیتابیس</label><input name="db_host" value="localhost" class="input-modern" dir="ltr"></div>
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">نام دیتابیس</label><input name="db_name" required class="input-modern" dir="ltr"></div>
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">نام کاربری</label><input name="db_user" required class="input-modern" dir="ltr"></div>
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">رمز عبور</label><input name="db_pass" type="password" class="input-modern" dir="ltr"></div>
        </div>
        <button class="mt-6 w-full py-3 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2 text-sm">بررسی اتصال و ادامه <i class="fa-solid fa-arrow-left text-xs"></i></button>
      </form>

    <?php elseif($step==3): ?>
      <h3 class="font-extrabold text-lg text-gray-800 mb-4"><i class="fa-solid fa-sliders text-blue-500 ml-1.5"></i>تنظیمات اولیه</h3>
      <form method="post">
        <input type="hidden" name="action" value="settings">
        <div class="grid grid-cols-1 gap-3">
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">نام سایت</label><input name="site_name" value="پورتال آموزشی" required class="input-modern"></div>
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">منطقه زمانی</label>
            <select name="timezone" class="input-modern">
              <option value="Asia/Tehran" selected>Asia/Tehran</option>
              <option value="UTC">UTC</option>
            </select>
          </div>
        </div>
        <button class="mt-6 w-full py-3 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2 text-sm">ادامه <i class="fa-solid fa-arrow-left text-xs"></i></button>
      </form>

    <?php elseif($step==4): ?>
      <h3 class="font-extrabold text-lg text-gray-800 mb-4"><i class="fa-solid fa-user-shield text-blue-500 ml-1.5"></i>ایجاد مدیر اصلی</h3>
      <form method="post">
        <input type="hidden" name="action" value="finish">
        <div class="grid grid-cols-1 gap-3">
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">نام و نام خانوادگی مدیر</label><input name="admin_name" required class="input-modern"></div>
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">نام کاربری</label><input name="admin_user" required class="input-modern" dir="ltr"></div>
          <div><label class="block font-bold text-xs text-gray-700 mb-1.5">رمز عبور (حداقل ۶ کاراکتر)</label><input name="admin_pass" type="password" required class="input-modern" dir="ltr"></div>
        </div>
        <button class="mt-6 w-full py-3 rounded-xl bg-emerald-500 text-white font-bold shadow-md hover:bg-emerald-600 transition flex items-center justify-center gap-2 text-sm"><i class="fa-solid fa-rocket text-xs"></i> نصب نهایی</button>
      </form>

    <?php elseif($step==5): ?>
      <div class="text-center py-4">
        <div class="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center text-2xl mx-auto mb-4"><i class="fa-solid fa-check"></i></div>
        <h3 class="font-extrablack text-xl text-gray-800 mb-2">نصب با موفقیت انجام شد!</h3>
        <p class="text-xs text-gray-500 mb-2">برای امنیت، پوشه‌ی <code class="bg-gray-100 px-1 rounded">install/</code> را حذف کنید.</p>
        <div class="flex gap-2 mt-6">
          <a href="../index.php" class="flex-1 py-3 rounded-xl bg-primary text-white font-bold text-sm flex items-center justify-center gap-2"><i class="fa-solid fa-house text-xs"></i> صفحه اصلی</a>
          <a href="../admin/login.php" class="flex-1 py-3 rounded-xl bg-gray-100 text-gray-700 font-bold text-sm flex items-center justify-center gap-2"><i class="fa-solid fa-user-shield text-xs"></i> ورود مدیر</a>
        </div>
      </div>
    <?php endif; ?>
  </div>
  <p class="text-center text-[10px] text-gray-400 mt-5"><i class="fa-solid fa-shield-halved"></i> نصب‌کننده پس از اتمام به‌صورت خودکار قفل می‌شود.</p>
</div>
</body>
</html>
