-- ============================================================
-- فایل ارتقا (Migration) — برای نصب‌هایی که از قبل انجام شده‌اند
-- یک‌بار در phpMyAdmin (تب SQL) روی دیتابیس پروژه اجرا کنید.
-- اجرای دوباره‌ی آن بی‌خطر است.
-- اگر هاست شما MySQL خالص است (نه MariaDB) و روی «IF NOT EXISTS» خطای
-- سینتکس گرفتید، عبارت «IF NOT EXISTS» را از خطوط ADD COLUMN حذف کنید.
-- ============================================================

-- ۱) نمره روی جدول ثبت‌نام‌ها (تا برای دانشجوی بدون پاسخ هم قابل ثبت باشد)
ALTER TABLE enrollments
  ADD COLUMN IF NOT EXISTS grade DECIMAL(5,2) NULL,
  ADD COLUMN IF NOT EXISTS grade_published TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS graded_at INT NULL;

-- ۲) بازه‌ی زمانی اعتراض برای هر درس
ALTER TABLE courses
  ADD COLUMN IF NOT EXISTS appeal_start INT NULL,
  ADD COLUMN IF NOT EXISTS appeal_end   INT NULL;

-- ۳) جدول اعتراض‌ها
CREATE TABLE IF NOT EXISTS appeals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id  INT NOT NULL,
  message TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  admin_reply TEXT NULL,
  created_at INT NOT NULL,
  replied_at INT NULL,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- اگر در نسخه‌ی قبلی ستون‌های نمره روی جدول submissions ساخته شده‌اند،
-- بی‌استفاده می‌مانند و نیازی به حذفشان نیست (در صورت تمایل می‌توانید حذف کنید).

-- ۴) فایل دوم اختیاری برای پاسخ‌ها
ALTER TABLE submissions
  ADD COLUMN IF NOT EXISTS file_path2 VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS original_name2 VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS file_size2 INT NULL;

-- ۵) پشتیبانی از چند فایل پاسخ (فهرست فایل‌ها به‌صورت JSON)
ALTER TABLE submissions
  ADD COLUMN IF NOT EXISTS files_json TEXT NULL;

-- ۶) اعلان‌های دانشجو و لاگ فعالیت
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  body TEXT NULL,
  type VARCHAR(20) NOT NULL DEFAULT 'info',
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at INT NOT NULL,
  KEY k_notif_student (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activity_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  action VARCHAR(50) NOT NULL,
  detail VARCHAR(300) NULL,
  ip VARCHAR(45) NULL,
  created_at INT NOT NULL,
  KEY k_act_student (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ۷) فایل سوالات و توضیحات برای هر درس (اختیاری)
ALTER TABLE courses
  ADD COLUMN IF NOT EXISTS question_file VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS question_original VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS question_desc TEXT NULL;

-- ۸) فایل‌های پیوست اطلاعیه‌ها (با توضیحات و شمارش دانلود)
CREATE TABLE IF NOT EXISTS announcement_files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  announcement_id INT NOT NULL,
  file_path     VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  file_size     INT NOT NULL DEFAULT 0,
  description   VARCHAR(500) NULL,
  download_count INT NOT NULL DEFAULT 0,
  created_at    INT NOT NULL,
  KEY k_annfile_ann (announcement_id),
  FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
