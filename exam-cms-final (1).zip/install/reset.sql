-- ============================================================
-- پاک‌سازی کامل دیتابیس (اختیاری) — برای نصب کاملاً تازه
-- هشدار: این فایل تمام جدول‌ها و داده‌های موجود را حذف می‌کند!
-- آن را در phpMyAdmin (تب SQL) روی دیتابیس پروژه اجرا کنید،
-- سپس به آدرس /install/ بروید تا ویزارد همه‌چیز را از نو بسازد.
-- ============================================================
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS sms_logs, otp_codes, announcements, appeals, submissions, enrollments, courses, students, admins, settings;
SET FOREIGN_KEY_CHECKS=1;
