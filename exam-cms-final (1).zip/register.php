<?php
require __DIR__.'/includes/bootstrap.php';
if (current_student()) { header('Location: '.base_url('dashboard.php')); exit; }
if (setting('register_enabled','1')!=='1') {
  $notice = setting('register_disabled_msg','ثبت‌نام موقتاً غیرفعال است.');
  $notice_title = 'ثبت‌نام غیرفعال است';
  $page_title = 'ثبت‌نام غیرفعال - '.setting('site_name','پورتال آموزشی');
  require __DIR__.'/partials/notice.php'; exit;
}
$page_title = 'ثبت‌نام دانشجو - '.setting('site_name','پورتال آموزشی');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<div id="toast-container"></div>
<?php require __DIR__.'/partials/header-student.php'; ?>

<main class="flex-1 flex items-center justify-center px-4 pt-20 pb-10">
  <div class="w-full max-w-2xl mx-auto fade-in">
    <div class="text-center mb-6">
      <h2 class="font-extrablack text-2xl text-gray-800 tracking-tight">فرم ثبت‌نام دانشجو</h2>
      <p class="font-normal text-xs text-gray-500 mt-1.5">اطلاعات را با دقت تکمیل کنید.</p>
    </div>

    <div class="card-modern">
      <div class="p-5 md:p-8 flex flex-col">
        <!-- نوار مراحل -->
        <div class="wizard-tabs">
          <div class="text-center"><div id="circle-1" class="wizard-step-indicator active mx-auto shadow-sm"><i class="fa-solid fa-id-card text-sm"></i></div></div>
          <div id="line-1" class="wizard-line"></div>
          <div class="text-center"><div id="circle-2" class="wizard-step-indicator pending mx-auto"><i class="fa-solid fa-book text-sm"></i></div></div>
          <div id="line-2" class="wizard-line"></div>
          <div class="text-center"><div id="circle-3" class="wizard-step-indicator pending mx-auto"><i class="fa-solid fa-check-double text-sm"></i></div></div>
        </div>

        <!-- مرحله ۱: اطلاعات فردی -->
        <div id="step-1" class="wizard-step block">
          <h3 class="font-extrabold text-lg text-gray-800 mb-4"><i class="fa-solid fa-id-card text-blue-500 ml-1.5"></i>اطلاعات فردی</h3>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div><label class="block font-bold text-xs text-gray-700 mb-1.5">نام</label><input id="first_name" oninput="checkPersian(this)" class="input-modern" placeholder="نام (فارسی)"><p id="err-first_name" class="hidden text-[11px] font-bold text-red-500 mt-1"><i class="fa-solid fa-circle-exclamation ml-1"></i>نام باید فقط با حروف فارسی باشد.</p></div>
            <div><label class="block font-bold text-xs text-gray-700 mb-1.5">نام خانوادگی</label><input id="last_name" oninput="checkPersian(this)" class="input-modern" placeholder="نام خانوادگی (فارسی)"><p id="err-last_name" class="hidden text-[11px] font-bold text-red-500 mt-1"><i class="fa-solid fa-circle-exclamation ml-1"></i>نام خانوادگی باید فقط با حروف فارسی باشد.</p></div>
            <div><label class="block font-bold text-xs text-gray-700 mb-1.5">شماره دانشجویی</label><input id="student_id" class="input-modern tabular-nums tracking-widest text-left" dir="ltr" inputmode="numeric" placeholder="402113245"></div>
            <div><label class="block font-bold text-xs text-gray-700 mb-1.5">شماره موبایل</label><input id="mobile" class="input-modern tabular-nums tracking-widest text-left" dir="ltr" inputmode="numeric" placeholder="09xxxxxxxxx"></div>
          </div>
          <button onclick="toStep(2)" class="mt-6 w-full py-3 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2 text-sm">انتخاب دروس <i class="fa-solid fa-arrow-left text-xs"></i></button>
        </div>

        <!-- مرحله ۲: انتخاب دروس -->
        <div id="step-2" class="wizard-step">
          <h3 class="font-extrabold text-lg text-gray-800 mb-4"><i class="fa-solid fa-book text-blue-500 ml-1.5"></i>انتخاب دروس</h3>
          <div id="courses-list" class="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            <p class="text-center text-xs text-gray-400 py-6">در حال بارگذاری دروس...</p>
          </div>
          <div class="flex gap-2 mt-6">
            <button onclick="toStep(1)" class="px-5 py-3 rounded-xl bg-gray-100 text-gray-600 font-bold text-sm"><i class="fa-solid fa-arrow-right text-xs"></i></button>
            <button onclick="toStep(3)" class="flex-1 py-3 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2 text-sm">بازبینی نهایی <i class="fa-solid fa-arrow-left text-xs"></i></button>
          </div>
        </div>

        <!-- مرحله ۳: بازبینی و ثبت -->
        <div id="step-3" class="wizard-step">
          <h3 class="font-extrabold text-lg text-gray-800 mb-4"><i class="fa-solid fa-check-double text-blue-500 ml-1.5"></i>بازبینی و تایید</h3>
          <div id="review" class="bg-gray-50 border border-gray-100 rounded-xl p-4 text-sm space-y-2"></div>
          <div class="flex gap-2 mt-6">
            <button onclick="toStep(2)" class="px-5 py-3 rounded-xl bg-gray-100 text-gray-600 font-bold text-sm"><i class="fa-solid fa-arrow-right text-xs"></i></button>
            <button id="btn-submit" onclick="submitForm()" class="flex-1 py-3 rounded-xl bg-emerald-500 text-white font-bold shadow-md hover:bg-emerald-600 transition flex items-center justify-center gap-2 text-sm">
              <span class="btn-text">ثبت‌نام نهایی</span><i class="fa-solid fa-paper-plane btn-icon text-xs"></i><div class="loader"></div>
            </button>
          </div>
        </div>
      </div>
    </div>
    <p class="text-center text-[11px] text-gray-500 mt-4">قبلاً ثبت‌نام کرده‌اید؟ <a href="<?= base_url('login.php') ?>" class="text-blue-600 font-bold">ورود به سیستم</a></p>
  </div>
</main>

<script src="<?= asset('assets/js/app.js') ?>"></script>
<script>
let coursesData=[], current=1;
const form={first_name:'',last_name:'',student_id:'',mobile:'',courses:[]};
// اعتبارسنجی نام فارسی: بدون حروف/ارقام لاتین و ارقام فارسی، فقط حروف فارسی و فاصله
function isPersianName(v){
  v=(v||'').trim();
  if(v==='') return false;
  if(/[A-Za-z0-9]/.test(v)) return false;
  if(/[\u0660-\u0669\u06F0-\u06F9]/.test(v)) return false;
  return /^[\u0600-\u06FF\u200C\s]+$/.test(v);
}
function checkPersian(el){
  const err=document.getElementById('err-'+el.id);
  const bad = el.value.trim()!=='' && !isPersianName(el.value);
  if(err) err.classList.toggle('hidden', !bad);
  el.classList.toggle('border-red-400', bad);
  el.classList.toggle('bg-red-50', bad);
}

async function loadCourses(){
  try{
    const r=await fetch('api/courses.php');const j=await r.json();
    coursesData=j.courses||[];
    const box=document.getElementById('courses-list');
    if(!coursesData.length){box.innerHTML='<p class="text-center text-xs text-gray-400 py-6">درس فعالی برای ثبت‌نام وجود ندارد.</p>';return;}
    box.innerHTML=coursesData.map(c=>`
      <label class="relative block">
        <input type="checkbox" class="peer sr-only course-cb" value="${c.id}" ${c.open?'':'disabled'}>
        <div class="course-card ${c.open?'':'opacity-50'}">
          <div class="flex items-center gap-3">
            <div class="checkbox-indicator"></div>
            <div><p class="font-bold text-sm text-gray-800">${c.title}</p>
            <p class="text-[10px] ${c.open?'text-emerald-600':'text-red-500'} font-bold">${c.open?'ثبت‌نام باز است':'خارج از بازه ثبت‌نام'}</p></div>
          </div>
          ${c.code?`<span class="text-[10px] text-gray-400 tabular-nums">${c.code}</span>`:''}
        </div>
      </label>`).join('');
  }catch(e){document.getElementById('courses-list').innerHTML='<p class="text-center text-xs text-red-500 py-6">خطا در بارگذاری دروس.</p>';}
}

function setStep(n){
  current=n;
  for(let i=1;i<=3;i++){
    document.getElementById('step-'+i).classList.toggle('block',i===n);
    document.getElementById('step-'+i).classList.toggle('hidden',i!==n);
    const c=document.getElementById('circle-'+i);
    c.className='wizard-step-indicator mx-auto '+(i<n?'completed':(i===n?'active shadow-sm':'pending'));
  }
  document.getElementById('line-1').classList.toggle('completed',n>1);
  document.getElementById('line-2').classList.toggle('completed',n>2);
}
function toStep(n){
  if(n>=2){
    form.first_name=document.getElementById('first_name').value.trim();
    form.last_name=document.getElementById('last_name').value.trim();
    form.student_id=toEnglishNum(document.getElementById('student_id').value.trim());
    form.mobile=toEnglishNum(document.getElementById('mobile').value.trim());
    if(form.first_name.length<2||form.last_name.length<2){showToast('نام و نام خانوادگی را کامل وارد کنید.');return setStep(1);}
    if(!isPersianName(form.first_name)){checkPersian(document.getElementById('first_name'));showToast('نام باید فقط با حروف فارسی وارد شود.');return setStep(1);}
    if(!isPersianName(form.last_name)){checkPersian(document.getElementById('last_name'));showToast('نام خانوادگی باید فقط با حروف فارسی وارد شود.');return setStep(1);}
    if(form.student_id.length<5){showToast('شماره دانشجویی معتبر نیست.');return setStep(1);}
    if(!/^09\d{9}$/.test(form.mobile)){showToast('شماره موبایل معتبر نیست.');return setStep(1);}
  }
  if(n>=3){
    form.courses=[...document.querySelectorAll('.course-cb:checked')].map(c=>parseInt(c.value));
    if(!form.courses.length){showToast('حداقل یک درس انتخاب کنید.');return setStep(2);}
    const names=coursesData.filter(c=>form.courses.includes(c.id)).map(c=>c.title);
    document.getElementById('review').innerHTML=`
      <div class="flex justify-between"><span class="text-gray-500 font-bold">نام:</span><span class="font-black text-gray-800">${form.first_name} ${form.last_name}</span></div>
      <div class="flex justify-between"><span class="text-gray-500 font-bold">شماره دانشجویی:</span><span class="font-black tabular-nums text-gray-800" dir="ltr">${toPersianNum(form.student_id)}</span></div>
      <div class="flex justify-between"><span class="text-gray-500 font-bold">موبایل:</span><span class="font-black tabular-nums text-gray-800" dir="ltr">${toPersianNum(form.mobile)}</span></div>
      <div class="pt-2 border-t border-gray-200"><span class="text-gray-500 font-bold">دروس:</span><div class="flex flex-wrap gap-1.5 mt-1.5">${names.map(n=>`<span class="bg-blue-50 text-primary text-[11px] font-bold px-2 py-1 rounded-md">${n}</span>`).join('')}</div></div>`;
  }
  setStep(n);
}
async function submitForm(){
  const btn=document.getElementById('btn-submit');btn.classList.add('btn-loading');
  try{
    const r=await apiPost('api/register.php',form);
    if(!r.ok){showToast(r.message||'خطا در ثبت‌نام.');return;}
    showToast(r.message,'success');
    setTimeout(()=>location.href=r.redirect,1200);
  }catch(e){showToast('خطا در ارتباط با سرور.');}
  finally{btn.classList.remove('btn-loading');}
}
loadCourses();
</script>
</body>
</html>
