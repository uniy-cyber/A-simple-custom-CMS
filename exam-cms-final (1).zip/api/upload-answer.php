<?php require __DIR__.'/../includes/bootstrap.php';
csrf_check();
$s = current_student();
if (!$s) fail('برای ارسال پاسخ باید وارد شوید.', 401);

$cid = (int)($_POST['course_id'] ?? 0);
$c = DB::one("SELECT * FROM courses WHERE id=? AND active=1", [$cid]);
if (!$c) fail('درس یافت نشد.', 404);
if (!DB::one("SELECT id FROM enrollments WHERE student_id=? AND course_id=?", [$s['id'],$cid])) fail('شما در این درس ثبت‌نام نکرده‌اید.', 403);

// کنترل زمان (سرور)
$now = ServerTime::now();
if ($c['exam_start']===null || $c['exam_end']===null) fail('زمان آزمون این درس تنظیم نشده است.', 422);
if ($now < $c['exam_start']-300) fail('هنوز زمان ورود به آزمون فرا نرسیده است.', 423);
if ($now > $c['exam_end']) fail('مهلت آزمون به پایان رسیده است.', 423);

$maxFiles = max(1,(int)setting('answer_max_files',1));
$maxBytes = (int)$c['max_file_mb'] * 1024 * 1024;
$allowed  = array_filter(array_map('trim', explode(',', strtolower($c['allowed_types']))));
$dir = APP_ROOT.'/uploads/course_'.$cid;
if (!is_dir($dir)) @mkdir($dir,0755,true);

// جمع‌آوری فایل‌های ورودی (answer[]) به‌صورت یکنواخت
$in = [];
if (!empty($_FILES['answer']) && is_array($_FILES['answer']['name'])) {
  foreach ($_FILES['answer']['name'] as $k=>$nm) {
    if (($_FILES['answer']['error'][$k] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
    $in[] = ['name'=>$nm,'tmp_name'=>$_FILES['answer']['tmp_name'][$k],'size'=>$_FILES['answer']['size'][$k],'error'=>$_FILES['answer']['error'][$k]];
  }
}
if (!$in) fail('هیچ فایلی دریافت نشد.');
if (count($in) > $maxFiles) fail('حداکثر '.$maxFiles.' فایل مجاز است.');

$saved = [];
foreach ($in as $idx=>$f) {
  if ($f['error'] !== UPLOAD_ERR_OK) fail('خطا در آپلود فایل '.($idx+1).'.');
  if ($f['size'] > $maxBytes) fail('حجم فایل «'.$f['name'].'» بیش از حد مجاز است.', 413);
  $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
  if (!in_array($ext, $allowed, true)) fail('نوع فایل «'.$f['name'].'» مجاز نیست.', 415);
  $safe = $s['student_id'].'_'.$now.'_'.bin2hex(random_bytes(4)).'.'.$ext;
  if (!move_uploaded_file($f['tmp_name'], $dir.'/'.$safe)) fail('ذخیره‌ی فایل ناموفق بود.', 500);
  $saved[] = ['p'=>'course_'.$cid.'/'.$safe, 'n'=>$f['name'], 's'=>(int)$f['size']];
}

// حذف فایل‌های قبلی (جایگزینی پاسخ نهایی)
$prev = DB::one("SELECT * FROM submissions WHERE student_id=? AND course_id=? ORDER BY id DESC LIMIT 1", [$s['id'],$cid]);
$delPaths = [];
if ($prev) {
  if (!empty($prev['files_json'])) { foreach ((json_decode($prev['files_json'],true)?:[]) as $pf) if(!empty($pf['p'])) $delPaths[]=$pf['p']; }
  foreach (['file_path','file_path2'] as $col) if (!empty($prev[$col])) $delPaths[]=$prev[$col];
  foreach ($delPaths as $p) { $abs=APP_ROOT.'/uploads/'.$p; if (is_file($abs)) @unlink($abs); }
}

$json = json_encode($saved, JSON_UNESCAPED_UNICODE);
$first = $saved[0];
if ($prev) {
  DB::q("UPDATE submissions SET file_path=?,original_name=?,file_size=?,file_path2=NULL,original_name2=NULL,file_size2=NULL,files_json=?,submitted_at=?,ip=? WHERE id=?",
    [$first['p'],$first['n'],$first['s'],$json,$now,$_SERVER['REMOTE_ADDR']??'',$prev['id']]);
  $msg='پاسخ نهایی شما جایگزین شد.';
} else {
  DB::insert("INSERT INTO submissions (student_id,course_id,file_path,original_name,file_size,files_json,submitted_at,ip) VALUES (?,?,?,?,?,?,?,?)",
    [$s['id'],$cid,$first['p'],$first['n'],$first['s'],$json,$now,$_SERVER['REMOTE_ADDR']??'']);
  $msg='پاسخ نهایی شما ثبت شد.';
}
log_activity($s['id'],'upload','ارسال پاسخ درس: '.$c['title'].' ('.count($saved).' فایل)');
ok(['message'=>$msg, 'count'=>count($saved)]);
