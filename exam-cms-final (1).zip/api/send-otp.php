<?php require __DIR__.'/../includes/bootstrap.php';
csrf_check();
if (setting('login_enabled','1')!=='1') fail('ورود به سیستم غیرفعال است.', 403);
$id = (int)($_SESSION['login_sid'] ?? 0);
if (!$id) fail('نشست نامعتبر است. دوباره شماره دانشجویی را وارد کنید.', 440);
$s = DB::one("SELECT * FROM students WHERE id=?", [$id]);
if (!$s) fail('دانشجو یافت نشد.', 404);

// resend=true یعنی کاربر صریحاً دکمه‌ی «ارسال مجدد» را زده است
$explicit = !empty(input_json()['resend']);
$r = otp_request($id, $s['mobile'], $explicit);

if (!empty($r['sent'])) {
  Kavenegar::sendOtp($s['mobile'], $r['code']);
  $extra = Kavenegar::enabled() ? [] : ['dev_code'=>$r['code']];
  ok([
    'sent'=>true,
    'resend_seconds'=>$r['resend'],
    'message'=>'کد تأیید ارسال شد و تا '.$r['validity'].' دقیقه معتبر است.'
  ] + $extra);
} else {
  // کد فعال قبلی هنوز معتبر است؛ کد جدیدی ساخته نشد
  ok([
    'sent'=>false,
    'resend_seconds'=>$r['resend'],
    'valid_left_min'=>$r['valid_left_min'] ?? null,
    'message'=>'کد تأیید قبلی هنوز معتبر است؛ همان کد را وارد کنید.'
  ]);
}
