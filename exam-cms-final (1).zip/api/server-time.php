<?php require __DIR__.'/../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['epoch'=>ServerTime::now(), 'iso'=>ServerTime::format('c')]);
