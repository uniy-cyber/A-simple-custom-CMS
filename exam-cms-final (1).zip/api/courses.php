<?php require __DIR__.'/../includes/bootstrap.php';
$now = ServerTime::now();
$rows = DB::all("SELECT id,title,code,reg_start,reg_end,reg_unlimited FROM courses WHERE active=1 ORDER BY title");
$out=[];
foreach($rows as $c){
  $open = $c['reg_unlimited']==1 || (
    ($c['reg_start']===null || $now>=$c['reg_start']) &&
    ($c['reg_end']===null   || $now<=$c['reg_end'])
  );
  $out[]=['id'=>(int)$c['id'],'title'=>$c['title'],'code'=>$c['code'],'open'=>$open];
}
json_out(['ok'=>true,'courses'=>$out]);
