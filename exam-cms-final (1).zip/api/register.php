<?php require __DIR__.'/../includes/bootstrap.php';
csrf_check();
if (setting('register_enabled','1')!=='1') fail('ثبت‌نام غیرفعال است.', 403);
$in = input_json();
$first  = clean($in['first_name'] ?? '');
$last   = clean($in['last_name'] ?? '');
$sid    = fa2en(clean($in['student_id'] ?? ''));
$mobile = fa2en(clean($in['mobile'] ?? ''));
$courses= array_values(array_unique(array_map('intval', $in['courses'] ?? [])));

if (mb_strlen($first)<2 || mb_strlen($last)<2) fail('نام و نام خانوادگی را کامل وارد کنید.');
if (!valid_persian_name($first)) fail('نام باید فقط با حروف فارسی وارد شود.');
if (!valid_persian_name($last))  fail('نام خانوادگی باید فقط با حروف فارسی وارد شود.');
if (!valid_student_id($sid)) fail('شماره دانشجویی معتبر نیست.');
if (!valid_mobile($mobile)) fail('شماره موبایل معتبر نیست (مثال: 09xxxxxxxxx).');
if (!$courses) fail('حداقل یک درس انتخاب کنید.');

if (DB::one("SELECT id FROM students WHERE student_id=?", [$sid])) fail('این شماره دانشجویی قبلاً ثبت شده است.', 409);

$now = ServerTime::now();
// اعتبارسنجی پنجره‌ی زمانی ثبت‌نام برای هر درس (سمت سرور)
$valid = [];
foreach ($courses as $cid) {
  $c = DB::one("SELECT * FROM courses WHERE id=? AND active=1", [$cid]);
  if (!$c) continue;
  $open = $c['reg_unlimited']==1 || (
    ($c['reg_start']===null || $now>=$c['reg_start']) &&
    ($c['reg_end']===null   || $now<=$c['reg_end'])
  );
  if ($open) $valid[] = $cid;
}
if (!$valid) fail('بازه‌ی ثبت‌نام دروس انتخابی فعال نیست.', 422);

try {
  DB::conn()->beginTransaction();
  $studentId = DB::insert("INSERT INTO students (first_name,last_name,student_id,mobile,created_at) VALUES (?,?,?,?,?)",
    [$first,$last,$sid,$mobile,$now]);
  foreach ($valid as $cid) {
    DB::q("INSERT IGNORE INTO enrollments (student_id,course_id,created_at) VALUES (?,?,?)", [$studentId,$cid,$now]);
  }
  DB::conn()->commit();
  log_activity($studentId,'register','ثبت‌نام در '.count($valid).' درس');
} catch (Throwable $e) {
  DB::conn()->rollBack();
  fail('خطا در ثبت‌نام. دوباره تلاش کنید.', 500);
}
ok(['message'=>'ثبت‌نام با موفقیت انجام شد.', 'redirect'=>base_url('login.php')]);
