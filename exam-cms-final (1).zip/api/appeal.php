<?php
require __DIR__.'/../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
csrf_check();
$s = current_student();
if (!$s) fail('برای ثبت اعتراض باید وارد شوید.', 401);

$in = input_json();
$cid = (int)($in['course_id'] ?? 0);
$msg = trim((string)($in['message'] ?? ''));

if ($cid<=0) fail('درس نامعتبر است.');
if (mb_strlen($msg) < 5) fail('متن اعتراض را کامل‌تر بنویسید.');
if (mb_strlen($msg) > 2000) fail('متن اعتراض بیش از حد طولانی است.');

// باید در درس ثبت‌نام شده باشد + نمره منتشر شده باشد (نمره روی enrollments)
$enr = DB::one("SELECT id, grade, grade_published FROM enrollments WHERE student_id=? AND course_id=?", [$s['id'],$cid]);
if (!$enr) fail('شما در این درس ثبت‌نام نشده‌اید.', 403);
if ((int)$enr['grade_published']!==1 || $enr['grade']===null) fail('تا زمانی که نمره اعلام نشده باشد امکان اعتراض وجود ندارد.');

// بازه‌ی زمانی اعتراض (از روی درس)
$c = DB::one("SELECT appeal_start, appeal_end FROM courses WHERE id=?", [$cid]);
$now = ServerTime::now();
if (empty($c['appeal_start']) || empty($c['appeal_end'])) fail('بازه‌ی اعتراض برای این درس تعیین نشده است.');
if ($now < (int)$c['appeal_start']) fail('بازه‌ی اعتراض هنوز آغاز نشده است.');
if ($now > (int)$c['appeal_end'])   fail('مهلت اعتراض به پایان رسیده است.');

// فقط یک اعتراض فعال در هر درس
$exists = DB::one("SELECT id FROM appeals WHERE student_id=? AND course_id=?", [$s['id'],$cid]);
if ($exists) fail('شما قبلاً برای این درس اعتراض ثبت کرده‌اید.');

DB::insert("INSERT INTO appeals (student_id,course_id,message,status,created_at) VALUES (?,?,?,'pending',?)",
  [$s['id'],$cid,$msg,$now]);
$cinfo = DB::one("SELECT title FROM courses WHERE id=?", [$cid]);
log_activity($s['id'],'appeal','ثبت اعتراض برای درس: '.($cinfo['title']??$cid));

ok(['message'=>'اعتراض شما ثبت شد و پس از بررسی پاسخ داده می‌شود.']);
