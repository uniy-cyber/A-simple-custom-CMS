<?php
require __DIR__.'/includes/bootstrap.php';
$s = require_student();
$logs = [];
try { $logs = DB::all("SELECT * FROM activity_log WHERE student_id=? ORDER BY id DESC LIMIT 100", [$s['id']]); } catch (Throwable $e) {}

$page_title='فعالیت‌های من - '.setting('site_name','پورتال آموزشی');
$meta=[
  'login'=>['fa-right-to-bracket','text-blue-500 bg-blue-50','ورود به سیستم'],
  'register'=>['fa-user-plus','text-emerald-500 bg-emerald-50','ثبت‌نام'],
  'upload'=>['fa-cloud-arrow-up','text-amber-500 bg-amber-50','ارسال پاسخ'],
  'appeal'=>['fa-gavel','text-rose-500 bg-rose-50','ثبت اعتراض'],
  'question'=>['fa-file-circle-question','text-indigo-500 bg-indigo-50','دریافت سوالات'],
];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<div id="toast-container"></div>
<?php require __DIR__.'/partials/header-student.php'; ?>

<main class="flex-1 pt-20 pb-10 px-4">
  <div class="max-w-2xl mx-auto fade-in">
    <div class="flex items-end justify-between mb-5">
      <div>
        <h2 class="font-extrablack text-xl md:text-2xl text-gray-800 tracking-tight"><i class="fa-solid fa-timeline text-blue-500 ml-2"></i>فعالیت‌های من</h2>
        <p class="text-xs text-gray-500 mt-1">سابقه‌ی فعالیت‌های شما در سامانه</p>
      </div>
      <a href="<?= base_url('dashboard.php') ?>" class="text-[11px] font-bold text-gray-500 hover:text-gray-700"><i class="fa-solid fa-arrow-right text-[9px]"></i> داشبورد</a>
    </div>

    <?php if(!$logs): ?>
      <div class="card-modern p-10 text-center text-sm text-gray-400"><i class="fa-solid fa-timeline text-3xl mb-3 block"></i>فعالیتی ثبت نشده است.</div>
    <?php else: ?>
    <div class="card-modern p-5">
      <div class="relative pr-3">
        <div class="absolute top-2 bottom-2 right-[22px] w-px bg-gray-100"></div>
        <?php foreach($logs as $l): $m=$meta[$l['action']]??['fa-circle-info','text-gray-400 bg-gray-50',$l['action']]; ?>
          <div class="relative flex items-start gap-3 pb-5">
            <div class="w-9 h-9 rounded-full <?= $m[1] ?> flex items-center justify-center shrink-0 z-10 ring-4 ring-white"><i class="fa-solid <?= $m[0] ?> text-xs"></i></div>
            <div class="min-w-0 flex-1 pt-1">
              <p class="font-extrabold text-sm text-gray-800"><?= htmlspecialchars($m[2]) ?></p>
              <?php if($l['detail']): ?><p class="text-xs text-gray-500 mt-0.5 text-justify"><?= htmlspecialchars($l['detail']) ?></p><?php endif; ?>
              <p class="text-[10px] text-gray-300 mt-1 tabular-nums"><?= jdatetime((int)$l['created_at']) ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</main>
<script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>
