<?php
require __DIR__.'/includes/bootstrap.php';
if (current_student()) { header('Location: '.base_url('dashboard.php')); exit; }
if (setting('login_enabled','1')!=='1') {
  $notice = setting('login_disabled_msg','ورود به سیستم موقتاً غیرفعال است.');
  $notice_title = 'ورود غیرفعال است';
  $page_title = 'ورود غیرفعال - '.setting('site_name','پورتال آموزشی');
  require __DIR__.'/partials/notice.php'; exit;
}
$page_title = 'ورود به سیستم - '.setting('site_name','پورتال آموزشی');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<div id="toast-container"></div>
<?php require __DIR__.'/partials/header-student.php'; ?>

<main class="flex-1 flex items-center justify-center px-4 pt-14">
  <div class="w-full max-w-[360px] md:max-w-[400px]">
    <div class="text-center mb-6 fade-in">
      <div class="w-14 h-14 bg-blue-50 text-primary rounded-2xl flex items-center justify-center text-xl mx-auto mb-3 border border-blue-100"><i class="fa-solid fa-fingerprint"></i></div>
      <h2 class="font-extrablack text-xl md:text-2xl text-gray-800 tracking-tight">ورود به سیستم</h2>
      <p class="font-normal text-xs text-gray-500 mt-1.5">جهت دسترسی، اطلاعات خود را وارد کنید.</p>
    </div>

    <div class="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden fade-in relative">
      <!-- مرحله ۱: شماره دانشجویی -->
      <div id="step-1" class="p-6 md:p-8 block">
        <form onsubmit="event.preventDefault(); verifyStudentId();">
          <div class="mb-5">
            <label class="block font-bold text-xs text-gray-700 mb-2">شماره دانشجویی</label>
            <div class="relative flex items-center">
              <i class="fa-solid fa-id-badge absolute right-3 text-gray-400 text-sm"></i>
              <input type="text" id="student-id" class="w-full pl-3 pr-9 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold text-gray-700 tabular-nums tracking-widest outline-none transition focus:bg-white focus:border-primary focus:ring-2 focus:ring-blue-100 text-left" dir="ltr" placeholder="مثال: 402113245" autocomplete="off" inputmode="numeric">
            </div>
          </div>
          <button type="submit" id="btn-check-id" class="w-full py-3 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2 text-sm">
            <span class="btn-text">بررسی و ادامه</span><i class="fa-solid fa-arrow-left btn-icon text-xs"></i><div class="loader"></div>
          </button>
        </form>
        <div class="mt-5 text-center border-t border-gray-50 pt-4 flex items-center justify-center gap-3">
          <a href="<?= base_url('register.php') ?>" class="font-bold text-[10px] text-blue-600 hover:text-blue-800 transition">ثبت‌نام دانشجوی جدید</a>
        </div>
      </div>

      <!-- مرحله ۲: کد تایید -->
      <div id="step-2" class="p-6 md:p-8 hidden">
        <button onclick="backToStep1()" class="text-gray-400 hover:text-gray-600 mb-4 transition text-[10px] font-bold flex items-center gap-1.5"><i class="fa-solid fa-arrow-right"></i> اصلاح شماره دانشجویی</button>
        <div class="bg-blue-50/50 border border-blue-100 rounded-xl p-3 flex items-center gap-3 mb-5">
          <div class="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xs shadow-sm"><i class="fa-solid fa-user"></i></div>
          <div>
            <p class="font-black text-sm text-gray-800" id="display-name">—</p>
            <p class="font-medium text-[9px] text-gray-500 mt-0.5">کد تایید به <span id="display-mobile" class="tabular-nums text-gray-700" dir="ltr">—</span> ارسال شد.</p>
          </div>
        </div>
        <form onsubmit="event.preventDefault(); verifyOtp();">
          <div class="mb-6 flex justify-center gap-2 md:gap-3" dir="ltr" id="otp-container">
            <?php for($i=0;$i<5;$i++): ?>
            <input type="text" maxlength="1" class="otp-input tabular-nums w-11 h-12 text-center text-lg font-black text-gray-700 bg-gray-50 border border-gray-200 rounded-xl outline-none transition focus:bg-white focus:border-primary focus:ring-2 focus:ring-blue-100" pattern="[0-9]*" inputmode="numeric" <?= $i===0?'autocomplete="one-time-code" autofocus':'' ?>>
            <?php endfor; ?>
          </div>
          <button type="submit" id="btn-verify-otp" class="w-full py-3 rounded-xl bg-emerald-500 text-white font-bold shadow-md hover:bg-emerald-600 transition flex items-center justify-center gap-2 text-sm">
            <span class="btn-text">ورود به داشبورد</span><i class="fa-solid fa-check-to-slot btn-icon text-xs"></i><div class="loader"></div>
          </button>
        </form>
        <div class="mt-4 text-center">
          <p id="otp-timer-text" class="font-bold text-[11px] text-gray-500">ارسال مجدد کد تا <span id="otp-countdown" class="tabular-nums text-primary mx-0.5" dir="ltr">02:00</span> دیگر</p>
          <button id="btn-resend-otp" onclick="resendOtp()" class="hidden font-bold text-[11px] text-blue-600 hover:text-blue-800 transition mx-auto flex items-center gap-1.5"><i class="fa-solid fa-rotate-right"></i> ارسال مجدد کد تایید</button>
        </div>
      </div>
    </div>

    <div class="text-center mt-5 font-light text-[9px] text-gray-400 flex items-center justify-center gap-1.5"><i class="fa-solid fa-shield-halved text-gray-300"></i> اتصال شما با پروتکل امن برقرار است.</div>
  </div>
</main>

<script src="<?= asset('assets/js/app.js') ?>"></script>
<script>
let otpInterval;
async function verifyStudentId(){
  const input=document.getElementById('student-id'); const sid=toEnglishNum(input.value.trim()); const btn=document.getElementById('btn-check-id');
  if(sid.length<5){showToast('شماره دانشجویی معتبر نیست.');input.focus();return;}
  btn.classList.add('btn-loading');
  try{
    const r=await apiPost('api/check-student.php',{student_id:sid});
    if(!r.ok){showToast(r.message||'خطا');return;}
    document.getElementById('display-name').textContent=r.name;
    document.getElementById('display-mobile').textContent=toPersianNum(r.mobile_masked);
    await resendOtp(true);
    document.getElementById('step-1').classList.add('hidden');
    const s2=document.getElementById('step-2'); s2.classList.remove('hidden'); s2.classList.add('fade-in');
    document.querySelector('.otp-input').focus();
    startWebOtp();
  }catch(e){showToast('خطا در ارتباط با سرور.');}
  finally{btn.classList.remove('btn-loading');}
}
function backToStep1(){
  document.getElementById('step-2').classList.add('hidden');
  document.getElementById('step-1').classList.remove('hidden');
  clearInterval(otpInterval);
  document.querySelectorAll('.otp-input').forEach(i=>i.value='');
}
async function verifyOtp(){
  let code='';document.querySelectorAll('.otp-input').forEach(i=>code+=toEnglishNum(i.value));
  const btn=document.getElementById('btn-verify-otp');
  if(code.length<5){showToast('کد ۵ رقمی را کامل وارد کنید.');return;}
  btn.classList.add('btn-loading');
  try{
    const r=await apiPost('api/verify-otp.php',{code});
    if(!r.ok){showToast(r.message||'کد نادرست است.');return;}
    showToast('ورود با موفقیت انجام شد.','success');
    clearInterval(otpInterval);
    setTimeout(()=>location.href=r.redirect,900);
  }catch(e){showToast('خطا در ارتباط با سرور.');}
  finally{btn.classList.remove('btn-loading');}
}
async function resendOtp(silent){
  try{
    // در شروع مرحله (silent) کد جدید اجباری نیست؛ با کلیک کاربر، ارسال مجدد صریح است
    const r=await apiPost('api/send-otp.php', silent?{}:{resend:true});
    if(!r.ok){showToast(r.message||'خطا');if(r.wait||r.resend_seconds)startOtpTimer(r.wait||r.resend_seconds);return;}
    if(r.sent){
      if(!silent)showToast('کد تایید جدید ارسال شد.','success');
      if(r.dev_code){ showToast('کد تست (SMS غیرفعال): '+toPersianNum(r.dev_code),'info'); fillOtp(r.dev_code); }
    } else {
      // کد قبلی هنوز معتبر است
      showToast(r.message||'کد قبلی هنوز معتبر است.','info');
    }
    startOtpTimer(r.resend_seconds||120);
  }catch(e){showToast('خطا در ارسال کد.');}
}
function startOtpTimer(duration){
  const display=document.getElementById('otp-countdown'),timerText=document.getElementById('otp-timer-text'),resendBtn=document.getElementById('btn-resend-otp');
  clearInterval(otpInterval); timerText.classList.remove('hidden'); resendBtn.classList.add('hidden');
  otpInterval=setInterval(()=>{
    let m=Math.floor(duration/60),s=duration%60; m=m<10?'0'+m:m; s=s<10?'0'+s:s;
    display.textContent=toPersianNum(`${m}:${s}`);
    if(--duration<0){clearInterval(otpInterval);timerText.classList.add('hidden');resendBtn.classList.remove('hidden');}
  },1000);
}
// پر کردن خودکار خانه‌های کد و ارسال خودکار در صورت کامل بودن
function fillOtp(code){
  code = toEnglishNum(String(code)).replace(/\D/g,'');
  if(!code) return;
  const boxes=document.querySelectorAll('.otp-input');
  for(let i=0;i<boxes.length;i++) boxes[i].value = code[i] || '';
  const last=Math.min(code.length, boxes.length)-1;
  if(last>=0) boxes[Math.max(0,last)].focus();
  if(code.length>=boxes.length){ setTimeout(()=>verifyOtp(), 250); } // ارسال خودکار
}
// خواندن خودکار کد از پیامک (WebOTP - مرورگرهای پشتیبان مثل کروم اندروید)
let _otpAbort;
function startWebOtp(){
  if(!('OTPCredential' in window)) return;
  try{ if(_otpAbort) _otpAbort.abort(); }catch(e){}
  _otpAbort=new AbortController();
  navigator.credentials.get({otp:{transport:['sms']}, signal:_otpAbort.signal})
    .then(o=>{ if(o && o.code) fillOtp(o.code); })
    .catch(()=>{});
}

const inputs=document.querySelectorAll('.otp-input');
inputs.forEach((input,index)=>{
  // اگر مرورگر (مثل iOS) کل کد را در یک خانه ریخت، بین خانه‌ها پخش شود
  input.addEventListener('input',function(){
    const v=toEnglishNum(this.value);
    if(v.length>1){ fillOtp(v); return; }
    this.value=v;
  });
  input.addEventListener('keyup',function(e){
    if(this.value.length===1&&index<inputs.length-1&&e.key!=='Backspace')inputs[index+1].focus();
    if(e.key==='Backspace'&&index>0&&this.value.length===0)inputs[index-1].focus();
  });
  input.addEventListener('paste',function(e){
    e.preventDefault();const d=toEnglishNum((e.clipboardData||window.clipboardData).getData('text').trim());
    if(/^\d+$/.test(d)){ fillOtp(d); }
  });
});
</script>
</body>
</html>
