/* ابزارهای مشترک کلاینت — توست، اعداد فارسی، ساعت سرور */
function toPersianNum(str){const p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];return str.toString().replace(/\d/g,x=>p[x]);}
function toEnglishNum(str){return str.toString().replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));}
function showToast(message,type='error'){
  let c=document.getElementById('toast-container');
  if(!c){c=document.createElement('div');c.id='toast-container';document.body.appendChild(c);}
  const t=document.createElement('div');t.className=`custom-toast ${type}`;
  const icon=type==='error'?'fa-circle-exclamation':(type==='success'?'fa-check-circle':'fa-circle-info');
  t.innerHTML=`<i class="fa-solid ${icon} text-sm"></i><span class="font-bold text-[11px]">${message}</span>`;
  c.appendChild(t);
  setTimeout(()=>t.classList.add('show'),10);
  setTimeout(()=>{t.classList.remove('show');setTimeout(()=>t.remove(),300);},3500);
}
/* فراخوانی استاندارد API با CSRF */
async function apiPost(url,data){
  const token=document.querySelector('meta[name="csrf-token"]')?.content||'';
  const res=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':token},body:JSON.stringify(data)});
  let json;try{json=await res.json();}catch(e){throw new Error('پاسخ نامعتبر از سرور');}
  return json;
}
/* ساعت سرور — هر بار از سرور همگام و سپس محلی پیش می‌رود */
let _serverOffset=0;
async function syncServerClock(){
  try{
    const base=(window.APP_BASE||'');
    const r=await fetch(base+'api/server-time.php',{cache:'no-store'});
    const j=await r.json();
    if(j&&j.epoch){_serverOffset=(j.epoch*1000)-Date.now();}
  }catch(e){}
}
function serverNow(){return new Date(Date.now()+_serverOffset);}
function tickHeaderClock(){
  const els=document.querySelectorAll('.js-clock, #header-time');if(!els.length)return;
  const n=serverNow();
  const h=String(n.getHours()).padStart(2,'0'),m=String(n.getMinutes()).padStart(2,'0'),s=String(n.getSeconds()).padStart(2,'0');
  const t=toPersianNum(`${h}:${m}:${s}`);
  els.forEach(el=>el.textContent=t);
}
document.addEventListener('DOMContentLoaded',()=>{
  if(document.querySelector('.js-clock, #header-time')){
    syncServerClock().then(()=>{tickHeaderClock();setInterval(tickHeaderClock,1000);});
    setInterval(syncServerClock,60000);
  }
});

/* ---------- مُدال تأیید داخل‌صفحه‌ای (جایگزین confirm مرورگر) ---------- */
/* استفاده: const ok = await confirmDialog({title, text, okText, cancelText, variant}); */
function confirmDialog(opts){
  opts = opts || {};
  const variant = opts.variant || 'primary'; // primary | danger | success
  const icons = { primary:'fa-circle-question', danger:'fa-triangle-exclamation', success:'fa-circle-check' };
  const iconBg = { primary:'background:#dbeafe;color:#1e3a8a', danger:'background:#ffe4e6;color:#e11d48', success:'background:#d1fae5;color:#059669' };
  return new Promise(resolve=>{
    const ov=document.createElement('div'); ov.className='modal-overlay';
    ov.innerHTML =
      '<div class="modal-box" role="dialog" aria-modal="true">'
      + '<div class="modal-icon" style="'+iconBg[variant]+'"><i class="fa-solid '+icons[variant]+'"></i></div>'
      + (opts.title ? '<p class="modal-title">'+opts.title+'</p>' : '')
      + (opts.text ? '<p class="modal-text">'+opts.text+'</p>' : '')
      + '<div class="modal-actions">'
      + '<button class="btn-modal-cancel">'+(opts.cancelText||'انصراف')+'</button>'
      + '<button class="btn-modal-ok '+(variant==='danger'?'danger':variant==='success'?'success':'')+'">'+(opts.okText||'تأیید')+'</button>'
      + '</div></div>';
    document.body.appendChild(ov);
    requestAnimationFrame(()=>ov.classList.add('show'));
    const close=(val)=>{ ov.classList.remove('show'); setTimeout(()=>ov.remove(),200); resolve(val); };
    ov.querySelector('.btn-modal-cancel').onclick=()=>close(false);
    ov.querySelector('.btn-modal-ok').onclick=()=>close(true);
    ov.addEventListener('click',e=>{ if(e.target===ov) close(false); });
    document.addEventListener('keydown',function esc(e){ if(e.key==='Escape'){document.removeEventListener('keydown',esc);close(false);} });
  });
}

/* فرم‌هایی با data-confirm به‌جای confirm مرورگر از مُدال استفاده می‌کنند */
document.addEventListener('submit', function(e){
  const f=e.target;
  if(f && f.dataset && f.dataset.confirm && !f.dataset._ok){
    e.preventDefault();
    confirmDialog({
      title: f.dataset.confirmTitle || 'تأیید عملیات',
      text:  f.dataset.confirm,
      okText: f.dataset.confirmOk || 'تأیید',
      cancelText: 'انصراف',
      variant: f.dataset.confirmVariant || 'danger'
    }).then(ok=>{ if(ok){ f.dataset._ok='1'; f.submit(); } });
  }
}, true);
