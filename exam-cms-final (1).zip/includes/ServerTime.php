<?php
/* کنترل زمان مبتنی بر سرور — هماهنگ با NTP (ntp.time.ir) و fallback به ساعت سرور
   تمام تصمیمات زمانی سیستم باید از ServerTime::now() استفاده کنند، نه از کلاینت. */
class ServerTime {
  private static ?int $offset = null; // اختلاف NTP با ساعت سرور (ثانیه)

  /** تلاش برای گرفتن زمان از NTP با تایم‌اوت کوتاه؛ نتیجه در سشن کش می‌شود */
  private static function loadOffset(): int {
    if (self::$offset !== null) return self::$offset;
    if (isset($_SESSION['ntp_offset'], $_SESSION['ntp_offset_at']) && (time()-$_SESSION['ntp_offset_at'] < 1800)) {
      return self::$offset = (int)$_SESSION['ntp_offset'];
    }
    $ntp = self::queryNtp('ntp.time.ir');
    if ($ntp === null) $ntp = self::queryNtp('time.google.com');
    $off = ($ntp === null) ? 0 : ($ntp - time());
    self::$offset = $off;
    $_SESSION['ntp_offset'] = $off;
    $_SESSION['ntp_offset_at'] = time();
    return $off;
  }

  /** پرس‌وجوی پروتکل NTP (UDP/123) — برمی‌گرداند epoch یا null */
  private static function queryNtp(string $host): ?int {
    if (!function_exists('fsockopen')) return null;
    $sock = @fsockopen('udp://'.$host, 123, $errno, $errstr, 2);
    if (!$sock) return null;
    stream_set_timeout($sock, 2);
    $req = "\x1b".str_repeat("\0",47);
    @fwrite($sock, $req);
    $resp = @fread($sock, 48);
    fclose($sock);
    if ($resp === false || strlen($resp) < 48) return null;
    $data = unpack('N12', $resp);
    $sec = $data[9] ?? 0;
    if (!$sec) return null;
    return $sec - 2208988800; // تبدیل از مبدأ ۱۹۰۰ به یونیکس
  }

  /** زمان معتبر سرور (یونیکس) */
  public static function now(): int { return time() + self::loadOffset(); }
  public static function nowMs(): int { return self::now()*1000; }
  public static function format(string $fmt='Y-m-d H:i:s'): string { return date($fmt, self::now()); }
}
