<?php
/* بوت‌استرپ مرکزی — در ابتدای هر صفحه include می‌شود (idempotent / امن در برابر include چندباره) */
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0'); // در محیط توسعه می‌توانید 1 کنید

if (!defined('APP_ROOT')) define('APP_ROOT', dirname(__DIR__));

/* اگر نصب نشده، به نصب‌کننده هدایت شو */
if (!file_exists(APP_ROOT.'/config/config.php')) {
  if (!str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/install/')) {
    $b = rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'])),'/');
    $b = preg_replace('#/(admin|api)$#','',$b);
    header('Location: '.$b.'/install/index.php'); exit;
  }
}
if (file_exists(APP_ROOT.'/config/config.php')) require_once APP_ROOT.'/config/config.php';

require_once APP_ROOT.'/includes/helpers.php';

/* سشن امن */
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>(($_SERVER['HTTPS']??'')==='on')]);
  session_name('EXAMCMS');
  session_start();
}

if (defined('APP_INSTALLED') && APP_INSTALLED) {
  require_once APP_ROOT.'/includes/db.php';
  require_once APP_ROOT.'/includes/settings.php';
  require_once APP_ROOT.'/includes/ServerTime.php';
  require_once APP_ROOT.'/includes/Kavenegar.php';
  require_once APP_ROOT.'/includes/auth.php';
  date_default_timezone_set(setting('timezone','Asia/Tehran'));
}
