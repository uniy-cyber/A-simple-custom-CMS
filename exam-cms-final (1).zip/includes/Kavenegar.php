<?php
/* سرویس پیامک کاوه‌نگار — ارسال OTP (با تمپلیت Verify Lookup یا پیامک معمولی) و ثبت لاگ */
class Kavenegar {
  public static function enabled(): bool { return setting('sms_enabled','0') === '1'; }

  /** ارسال کد OTP؛ اگر تمپلیت تنظیم شده باشد از Verify Lookup استفاده می‌شود */
  public static function sendOtp(string $mobile, string $code): array {
    $mobile  = fa2en($mobile);
    $apikey  = trim((string)setting('kavenegar_apikey',''));
    $template= trim((string)setting('kavenegar_template',''));

    if (!self::enabled() || $apikey === '') {
      self::log($mobile, 'OTP: '.$code, 'simulated', 'سرویس غیرفعال یا کلید تنظیم نشده');
      return ['ok'=>true, 'simulated'=>true];
    }
    if ($template !== '') {
      // ارسال با تمپلیت تأییدیه (روش پیشنهادی کاوه‌نگار برای کد یک‌بارمصرف)
      $url  = 'https://api.kavenegar.com/v1/'.rawurlencode($apikey).'/verify/lookup.json';
      $post = http_build_query(['receptor'=>$mobile, 'token'=>$code, 'template'=>$template]);
      return self::http($url, $post, $mobile, 'تمپلیت: '.$template.' | کد: '.$code);
    }
    // در غیر این صورت ارسال پیامک متنی معمولی
    return self::send($mobile, 'کد ورود شما به '.setting('site_name','پورتال').': '.$code);
  }

  /** ارسال پیامک متنی معمولی (مثلاً پیام آزمایشی) */
  public static function send(string $mobile, string $message): array {
    $mobile = fa2en($mobile);
    $apikey = trim((string)setting('kavenegar_apikey',''));
    $sender = trim((string)setting('kavenegar_sender',''));
    if (!self::enabled() || $apikey === '') {
      self::log($mobile, $message, 'simulated', 'سرویس غیرفعال یا کلید تنظیم نشده');
      return ['ok'=>true, 'simulated'=>true];
    }
    $url  = 'https://api.kavenegar.com/v1/'.rawurlencode($apikey).'/sms/send.json';
    $post = http_build_query(['receptor'=>$mobile, 'sender'=>$sender, 'message'=>$message]);
    return self::http($url, $post, $mobile, $message);
  }

  /** هسته‌ی ارسال HTTP و تفسیر پاسخ کاوه‌نگار */
  private static function http(string $url, string $post, string $mobile, string $logMsg): array {
    $status='failed'; $resp='';
    if (function_exists('curl_init')) {
      $ch=curl_init($url);
      curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$post,CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>true]);
      $resp=curl_exec($ch); $err=curl_error($ch); $http=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
      if ($resp!==false){ $j=json_decode($resp,true); $status=(($j['return']['status']??0)==200)?'sent':'failed'; }
      else { $resp=$err; }
    } else {
      $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>'Content-Type: application/x-www-form-urlencoded','content'=>$post,'timeout'=>15,'ignore_errors'=>true]]);
      $resp=@file_get_contents($url,false,$ctx);
      if ($resp!==false){ $j=json_decode($resp,true); $status=(($j['return']['status']??0)==200)?'sent':'failed'; }
    }
    self::log($mobile, $logMsg, $status, is_string($resp)?$resp:'');
    return ['ok'=>$status==='sent', 'status'=>$status, 'response'=>is_string($resp)?$resp:''];
  }

  private static function log(string $mobile,string $msg,string $status,string $resp): void {
    DB::q("INSERT INTO sms_logs (mobile,message,status,response,created_at) VALUES (?,?,?,?,?)",
      [$mobile,$msg,$status,mb_substr($resp,0,500),ServerTime::now()]);
  }
}
