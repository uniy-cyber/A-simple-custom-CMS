<?php
/* توابع کمکی عمومی */

/* مسیر پایه‌ی برنامه نسبت به ریشه‌ی وب */
function base_url(string $path=''): string {
  $base = rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'])), '/');
  // اگر داخل admin/ یا api/ هستیم، یک سطح بالا برو تا ریشه
  $base = preg_replace('#/(admin|api|install)$#','',$base);
  return ($base === '' ? '' : $base) . ($path ? '/'.ltrim($path,'/') : '/');
}

/* مثل base_url ولی با نسخه‌گذاری خودکار برای جلوگیری از کش مرورگر */
function asset(string $path): string {
  $url = base_url($path);
  $abs = defined('APP_ROOT') ? APP_ROOT.'/'.ltrim($path,'/') : '';
  $v = ($abs && is_file($abs)) ? filemtime($abs) : date('Ymd');
  return $url.'?v='.$v;
}

/* خروجی JSON استاندارد و پایان اجرا */
function json_out(array $data, int $code=200): void {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}
function ok(array $d=[]): void { json_out(['ok'=>true]+$d); }
function fail(string $msg, int $code=400, array $d=[]): void { json_out(['ok'=>false,'message'=>$msg]+$d, $code); }

/* دریافت بدنه‌ی JSON ورودی */
function input_json(): array {
  $raw = file_get_contents('php://input');
  $d = json_decode($raw, true);
  return is_array($d) ? $d : [];
}

/* CSRF */
function csrf_token(): string {
  if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
  return $_SESSION['csrf'];
}
function csrf_check(): void {
  $sent = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
  if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) fail('توکن امنیتی نامعتبر است. صفحه را تازه کنید.', 419);
}

/* پاکسازی و تبدیل اعداد فارسی/عربی به انگلیسی */
function fa2en(string $s): string {
  $fa=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; $ar=['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
  return str_replace(array_merge($fa,$ar), range(0,9), $s);
}
function clean(string $s): string { return trim($s); }

/* اعتبارسنجی موبایل ایران */
function valid_mobile(string $m): bool { $m=fa2en($m); return (bool)preg_match('/^09\d{9}$/', $m); }
function valid_student_id(string $s): bool { $s=fa2en($s); return (bool)preg_match('/^\d{5,15}$/', $s); }
function valid_persian_name(string $s): bool {
  $s = trim($s);
  if ($s==='') return false;
  if (preg_match('/[A-Za-z0-9]/u', $s)) return false;                          // حروف یا ارقام لاتین ممنوع
  if (preg_match('/[\x{0660}-\x{0669}\x{06F0}-\x{06F9}]/u', $s)) return false;  // ارقام عربی/فارسی ممنوع
  return (bool)preg_match('/^[\x{0600}-\x{06FF}\x{200C}\s]+$/u', $s);           // فقط حروف فارسی + فاصله + نیم‌فاصله
}
/* تبدیل ارقام به فارسی (نمایش) */
function pnum($n): string { $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
/* تبدیل نمره به حروف فارسی (مناسب ۰ تا ۲۰ با اعشار رایج) */
function num2fa_words($num): string {
  $num=(float)$num; $int=(int)floor($num); $frac=round($num-$int,2);
  $ones=['صفر','یک','دو','سه','چهار','پنج','شش','هفت','هشت','نه','ده','یازده','دوازده','سیزده','چهارده','پانزده','شانزده','هفده','هجده','نوزده'];
  $tens=['','','بیست','سی','چهل','پنجاه','شصت','هفتاد','هشتاد','نود'];
  $w=function($n) use($ones,$tens){ $n=(int)$n; if($n<20) return $ones[$n]??''; $t=intdiv($n,10); $o=$n%10; return ($tens[$t]??'').($o? ' و '.$ones[$o] : ''); };
  $res=$w($int);
  if (abs($frac-0.25)<0.001) $res.=' و ربع';
  elseif (abs($frac-0.5)<0.001) $res.=' و نیم';
  elseif (abs($frac-0.75)<0.001) $res.=' و سه‌ربع';
  elseif ($frac>0) { $res.=' ممیز '.$w((int)round($frac*100)).' صدم'; }
  return $res;
}
/* ثبت فعالیت دانشجو در لاگ (بی‌خطر اگر جدول موجود نباشد) */
function log_activity(int $student_id, string $action, string $detail=''): void {
  try {
    DB::q("INSERT INTO activity_log (student_id,action,detail,ip,created_at) VALUES (?,?,?,?,?)",
      [$student_id,$action,mb_substr($detail,0,300),$_SERVER['REMOTE_ADDR']??'',ServerTime::now()]);
  } catch (Throwable $e) {}
}
/* ایجاد اعلان برای دانشجو */
function notify_student(int $student_id, string $title, string $body='', string $type='info'): void {
  try {
    DB::q("INSERT INTO notifications (student_id,title,body,type,is_read,created_at) VALUES (?,?,?,?,0,?)",
      [$student_id,mb_substr($title,0,255),mb_substr($body,0,500),$type,ServerTime::now()]);
  } catch (Throwable $e) {}
}
/* جعبه‌ی پیام یکدست برای پنل (خطا=قرمز، موفقیت=سبز) */
function flashbox($f): string {
  if (!$f) return '';
  if (is_array($f)) { $type=$f[0]??'success'; $msg=$f[1]??''; } else { $type='success'; $msg=(string)$f; }
  $err = ($type==='error');
  $cls = $err ? 'bg-red-50 border-red-200 text-red-700' : 'bg-emerald-50 border-emerald-200 text-emerald-700';
  $ic  = $err ? 'fa-circle-exclamation' : 'fa-circle-check';
  return '<div class="mb-4 '.$cls.' border text-xs font-bold rounded-lg p-3 flex items-center gap-2"><i class="fa-solid '.$ic.'"></i><span>'.htmlspecialchars($msg).'</span></div>';
}

/* حجم فایل به‌صورت خوانا (با ارقام فارسی) */
function human_size(int $bytes): string {
  $u=['بایت','کیلوبایت','مگابایت','گیگابایت']; $i=0; $b=(float)$bytes;
  while ($b>=1024 && $i<3){ $b/=1024; $i++; }
  $num = ($i===0) ? (string)(int)$b : number_format($b, ($b<10?1:0));
  return pnum($num).' '.$u[$i];
}
/* آیکون و رنگ بر اساس پسوند فایل (FontAwesome) — خروجی: [icon_class, color_classes, label] */
function file_icon(string $name): array {
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  $map = [
    'pdf'  => ['fa-file-pdf',        'text-red-500 bg-red-50',       'PDF'],
    'doc'  => ['fa-file-word',       'text-blue-600 bg-blue-50',     'Word'],
    'docx' => ['fa-file-word',       'text-blue-600 bg-blue-50',     'Word'],
    'xls'  => ['fa-file-excel',      'text-emerald-600 bg-emerald-50','Excel'],
    'xlsx' => ['fa-file-excel',      'text-emerald-600 bg-emerald-50','Excel'],
    'csv'  => ['fa-file-csv',        'text-emerald-600 bg-emerald-50','CSV'],
    'ppt'  => ['fa-file-powerpoint', 'text-orange-500 bg-orange-50', 'PowerPoint'],
    'pptx' => ['fa-file-powerpoint', 'text-orange-500 bg-orange-50', 'PowerPoint'],
    'zip'  => ['fa-file-zipper',     'text-amber-600 bg-amber-50',   'فشرده'],
    'rar'  => ['fa-file-zipper',     'text-amber-600 bg-amber-50',   'فشرده'],
    '7z'   => ['fa-file-zipper',     'text-amber-600 bg-amber-50',   'فشرده'],
    'jpg'  => ['fa-file-image',      'text-purple-500 bg-purple-50', 'تصویر'],
    'jpeg' => ['fa-file-image',      'text-purple-500 bg-purple-50', 'تصویر'],
    'png'  => ['fa-file-image',      'text-purple-500 bg-purple-50', 'تصویر'],
    'gif'  => ['fa-file-image',      'text-purple-500 bg-purple-50', 'تصویر'],
    'webp' => ['fa-file-image',      'text-purple-500 bg-purple-50', 'تصویر'],
    'txt'  => ['fa-file-lines',      'text-gray-500 bg-gray-100',    'متن'],
    'mp4'  => ['fa-file-video',      'text-pink-500 bg-pink-50',     'ویدیو'],
    'mp3'  => ['fa-file-audio',      'text-indigo-500 bg-indigo-50', 'صوت'],
  ];
  return $map[$ext] ?? ['fa-file', 'text-gray-500 bg-gray-100', strtoupper($ext)?:'فایل'];
}

/* تاریخ شمسی ساده (بدون افزونه) از روی timestamp */
function jdate(int $ts): string {
  $g_y=(int)date('Y',$ts); $g_m=(int)date('n',$ts); $g_d=(int)date('j',$ts);
  $g_days=[0,31,59,90,120,151,181,212,243,273,304,334];
  $gy=$g_y-1600; $gm=$g_m-1; $gd=$g_d-1;
  $g_day_no=365*$gy + intdiv($gy+3,4) - intdiv($gy+99,100) + intdiv($gy+399,400);
  $g_day_no += $g_days[$gm];
  if ($gm>1 && (($g_y%4==0 && $g_y%100!=0)||($g_y%400==0))) $g_day_no++;
  $g_day_no += $gd;
  $j_day_no=$g_day_no-79;
  $j_np=intdiv($j_day_no,12053); $j_day_no%=12053;
  $jy=979+33*$j_np+4*intdiv($j_day_no,1461); $j_day_no%=1461;
  if ($j_day_no>=366){ $jy+=intdiv($j_day_no-366,365)+1; $j_day_no=($j_day_no-366)%365; }
  $j_days=[31,31,31,31,31,31,30,30,30,30,30,29];
  $i=0; while($i<11 && $j_day_no>=$j_days[$i]){ $j_day_no-=$j_days[$i]; $i++; }
  $jm=$i+1; $jd=$j_day_no+1;
  return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
}
function jdatetime(int $ts): string { return jdate($ts).' '.date('H:i',$ts); }

/* بررسی CSRF برای فرم‌های POST کلاسیک (نه Ajax) */
function csrf_form(): void {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); die('توکن امنیتی نامعتبر است.'); }
}
/* تبدیل رشته‌ی datetime-local به timestamp سرور (یا null) */
function dt_to_ts(?string $v): ?int {
  $v = trim((string)$v); if ($v==='') return null;
  $ts = strtotime($v); return $ts ?: null;
}
function ts_to_dt(?int $ts): string { return $ts ? date('Y-m-d\TH:i', $ts) : ''; }
