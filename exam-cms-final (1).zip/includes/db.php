<?php
/* لایه‌ی دیتابیس مبتنی بر PDO (Singleton) */
class DB {
  private static ?PDO $pdo = null;
  public static function conn(): PDO {
    if (self::$pdo === null) {
      $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
      self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
      ]);
    }
    return self::$pdo;
  }
  public static function q(string $sql, array $params = []): PDOStatement {
    $st = self::conn()->prepare($sql);
    $st->execute($params);
    return $st;
  }
  public static function one(string $sql, array $params = []) { return self::q($sql,$params)->fetch() ?: null; }
  public static function all(string $sql, array $params = []): array { return self::q($sql,$params)->fetchAll(); }
  public static function insert(string $sql, array $params = []): int { self::q($sql,$params); return (int)self::conn()->lastInsertId(); }
}
