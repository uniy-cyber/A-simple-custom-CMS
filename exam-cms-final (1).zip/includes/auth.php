<?php
/* مدیریت احراز هویت دانشجو و مدیر */

function current_student(): ?array {
  if (empty($_SESSION['student_id'])) return null;
  return DB::one("SELECT * FROM students WHERE id=?", [$_SESSION['student_id']]);
}
function require_student(): array {
  $s = current_student();
  if (!$s) { header('Location: '.base_url('login.php')); exit; }
  return $s;
}
function login_student(int $id): void { session_regenerate_id(true); $_SESSION['student_id']=$id; log_activity($id,'login','ورود به سیستم'); }

function current_admin(): ?array {
  if (empty($_SESSION['admin_id'])) return null;
  return DB::one("SELECT * FROM admins WHERE id=?", [$_SESSION['admin_id']]);
}
function require_admin(): array {
  $a = current_admin();
  if (!$a) { header('Location: '.base_url('admin/login.php')); exit; }
  return $a;
}
function login_admin(int $id): void { session_regenerate_id(true); $_SESSION['admin_id']=$id; }

/* OTP: تولید، ذخیره‌ی هش‌شده، و تایید */
function otp_request(int $student_id, string $mobile, bool $explicit=false): array {
  $validity = (int)setting('otp_validity_minutes', 60); if ($validity<=0) $validity=60;
  $resend   = (int)setting('otp_resend_seconds', 120); if ($resend<0) $resend=0;
  $now = ServerTime::now();

  // کد فعال فعلی (استفاده‌نشده و منقضی‌نشده)
  $active = DB::one("SELECT * FROM otp_codes WHERE student_id=? AND used=0 AND expires_at>=? ORDER BY id DESC LIMIT 1",[$student_id,$now]);
  $last   = DB::one("SELECT created_at FROM otp_codes WHERE student_id=? ORDER BY id DESC LIMIT 1",[$student_id]);
  $sinceLast   = $last ? ($now-(int)$last['created_at']) : PHP_INT_MAX;
  $throttleLeft = max(0, $resend - $sinceLast);

  // اگر کد فعالی هست: تا زمانی که کاربر صریحاً «ارسال مجدد» را پس از پایان بازه نزده، کد جدید نمی‌سازیم
  // به این ترتیب همان کد قبلی تا پایان اعتبار (مثلاً ۶۰ دقیقه) معتبر می‌ماند.
  if ($active && (!$explicit || $throttleLeft>0)) {
    $validLeftMin = max(1, (int)ceil(((int)$active['expires_at']-$now)/60));
    return ['ok'=>true,'sent'=>false,'reused'=>true,'resend'=>$throttleLeft,'validity'=>$validity,'valid_left_min'=>$validLeftMin];
  }

  // کد جدید: همه‌ی کدهای فعال قبلی باطل می‌شوند تا فقط یک کد معتبر وجود داشته باشد
  DB::q("UPDATE otp_codes SET used=1 WHERE student_id=? AND used=0",[$student_id]);
  $code = str_pad((string)random_int(0,99999),5,'0',STR_PAD_LEFT);
  DB::q("INSERT INTO otp_codes (student_id,mobile,code_hash,expires_at,used,created_at,ip) VALUES (?,?,?,?,0,?,?)",
    [$student_id, fa2en($mobile), password_hash($code,PASSWORD_DEFAULT), $now+$validity*60, $now, $_SERVER['REMOTE_ADDR']??'']);
  return ['ok'=>true,'sent'=>true,'code'=>$code,'resend'=>$resend,'validity'=>$validity];
}
function otp_verify(int $student_id, string $code): bool {
  $code = fa2en($code);
  $now = ServerTime::now();
  // هر کد استفاده‌نشده‌ی منقضی‌نشده‌ی این دانشجو را بررسی کن (نه فقط آخرین)
  $rows = DB::all("SELECT * FROM otp_codes WHERE student_id=? AND used=0 AND expires_at>=? ORDER BY id DESC",[$student_id,$now]);
  foreach ($rows as $row) {
    if (password_verify($code, $row['code_hash'])) {
      DB::q("UPDATE otp_codes SET used=1 WHERE id=?", [$row['id']]);
      return true;
    }
  }
  return false;
}
