<?php
/* مدیریت تنظیمات سیستم (جدول settings) با کش حافظه‌ای */
class Settings {
  private static ?array $cache = null;
  private static function load(): array {
    if (self::$cache === null) {
      self::$cache = [];
      foreach (DB::all("SELECT skey, svalue FROM settings") as $r) self::$cache[$r['skey']] = $r['svalue'];
    }
    return self::$cache;
  }
  public static function get(string $k, $default=null) { $a=self::load(); return $a[$k] ?? $default; }
  public static function set(string $k, $v): void {
    DB::q("INSERT INTO settings (skey,svalue) VALUES (?,?) ON DUPLICATE KEY UPDATE svalue=VALUES(svalue)", [$k,(string)$v]);
    if (self::$cache!==null) self::$cache[$k]=(string)$v;
  }
}
function setting(string $k, $default=null) { return Settings::get($k,$default); }
