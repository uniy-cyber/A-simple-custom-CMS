<?php
/* این فایل توسط نصب‌کننده ساخته می‌شود. نمونه‌ی ساختار: */
define('DB_HOST', 'localhost');
define('DB_NAME', 'exam_cms');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');
define('APP_KEY', 'random-generated-key');
define('APP_INSTALLED', true);
