<?php
require __DIR__.'/includes/bootstrap.php';
$s = require_student();
$cid = (int)($_GET['course'] ?? 0);
$c = DB::one("SELECT c.* FROM courses c JOIN enrollments e ON e.course_id=c.id WHERE c.id=? AND e.student_id=? AND c.active=1", [$cid,$s['id']]);
if (!$c) { header('Location: '.base_url('dashboard.php')); exit; }
$now = ServerTime::now();

$alreadySubmitted = DB::one("SELECT * FROM submissions WHERE student_id=? AND course_id=? ORDER BY id DESC LIMIT 1", [$s['id'],$cid]);
$maxFiles = max(1,(int)setting('answer_max_files',1));
$subFiles = [];
if ($alreadySubmitted) {
  if (!empty($alreadySubmitted['files_json'])) $subFiles = json_decode($alreadySubmitted['files_json'],true) ?: [];
  if (!$subFiles) {
    if (!empty($alreadySubmitted['file_path']))  $subFiles[]=['n'=>$alreadySubmitted['original_name'], 's'=>$alreadySubmitted['file_size']];
    if (!empty($alreadySubmitted['file_path2'])) $subFiles[]=['n'=>$alreadySubmitted['original_name2'],'s'=>$alreadySubmitted['file_size2']];
  }
}
$page_title = 'جلسه آزمون - '.htmlspecialchars($c['title']);

function toPersianNumPHP($n){ $p=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']; return str_replace(range(0,9),$p,(string)$n); }
function fsizePHP($b){ $u=['B','KB','MB','GB']; $i=0; while($b>=1024&&$i<3){$b/=1024;$i++;} return toPersianNumPHP(round($b,1)).' '.$u[$i]; }
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<div id="toast-container"></div>
<?php require __DIR__.'/partials/header-student.php'; ?>

<main class="flex-1 pt-20 pb-10 px-4">
  <div class="max-w-4xl mx-auto fade-in space-y-4">
    <div class="flex justify-between items-end mb-2">
      <div>
        <h2 class="font-extrablack text-xl md:text-2xl text-gray-800 tracking-tight">ورود به جلسه آزمون</h2>
        <p class="text-xs text-gray-500 mt-1"><?= htmlspecialchars($c['title']) ?></p>
      </div>
      <a href="<?= base_url('dashboard.php') ?>" class="text-[11px] font-bold text-gray-500 hover:text-gray-700"><i class="fa-solid fa-arrow-right text-[9px]"></i> داشبورد</a>
    </div>

    <div class="card-modern relative">
      <div id="ribbon-timer" class="timer-ribbon">
        <span class="tr-label" id="tr-label">زمان باقی‌مانده</span>
        <span class="tr-time" id="countdown">--:--:--</span>
      </div>

      <!-- کارت هویت -->
      <div class="px-5 md:px-8 pt-20 md:pt-12 pb-5 border-b border-gray-100 bg-gray-50/50">
        <div class="identity-badge grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <p class="text-[10px] text-blue-200 font-bold mb-0.5">دانشجو</p>
            <p class="font-black text-base"><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></p>
            <p class="text-[11px] text-blue-100 tabular-nums mt-0.5" dir="ltr"><?= htmlspecialchars($s['student_id']) ?></p>
          </div>
          <div class="md:text-left border-t md:border-t-0 md:border-l border-blue-400/30 pt-3 md:pt-0 md:pl-5 flex flex-col justify-center">
            <p class="text-[10px] text-blue-200 font-bold mb-0.5">درس</p>
            <p class="font-black text-base"><?= htmlspecialchars($c['title']) ?></p>
            <p class="text-[11px] text-blue-100 mt-0.5">پایان: <span class="tabular-nums"><?= jdatetime((int)$c['exam_end']) ?></span></p>
          </div>
        </div>
      </div>

      <div class="p-5 md:p-8">
        <!-- حالت قفل (قبل از شروع یا بعد از پایان) -->
        <div id="exam-locked" class="hidden text-center py-10">
          <div id="lock-icon" class="w-16 h-16 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center text-2xl mx-auto mb-4"><i class="fa-solid fa-lock"></i></div>
          <p id="lock-msg" class="font-extrabold text-gray-700">آزمون هنوز فعال نشده است.</p>
          <p class="text-xs text-gray-400 mt-2">دسترسی از ۵ دقیقه قبل از شروع تا پایان آزمون فعال است.</p>
        </div>

        <!-- حالت فعال -->
        <div id="exam-active" class="hidden">

          <?php if(!empty($c['question_desc']) || !empty($c['question_file'])): ?>
          <div class="bg-blue-50/50 border border-blue-100 rounded-xl p-4 mb-5">
            <p class="font-extrabold text-sm text-primary mb-2"><i class="fa-solid fa-file-circle-question ml-1.5"></i>سوالات آزمون</p>
            <?php if(!empty($c['question_desc'])): ?>
              <p class="text-xs text-gray-600 leading-relaxed text-justify whitespace-pre-line mb-3"><?= htmlspecialchars($c['question_desc']) ?></p>
            <?php endif; ?>
            <?php if(!empty($c['question_file'])): ?>
              <a href="<?= base_url('question.php?course='.(int)$cid) ?>" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-white text-xs font-bold hover:bg-blue-800 transition shadow-sm">
                <i class="fa-solid fa-download text-[11px]"></i> دانلود فایل سوالات
              </a>
            <?php endif; ?>
          </div>
          <?php endif; ?>

          <!-- وضعیت پاسخ نهاییِ ثبت‌شده -->
          <div id="submitted-box" class="<?= $alreadySubmitted?'':'hidden' ?> bg-emerald-50 border border-emerald-200 rounded-xl p-4 mb-5">
            <div class="flex items-start gap-3">
              <div class="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0"><i class="fa-solid fa-circle-check"></i></div>
              <div class="min-w-0 flex-1">
                <p class="font-extrabold text-emerald-800 text-sm">پاسخ نهایی شما ثبت شد ✓</p>
                <?php if($alreadySubmitted): ?>
                <?php foreach($subFiles as $sf): ?>
                <p class="text-xs text-emerald-700 mt-1 truncate"><i class="fa-solid fa-paperclip text-[10px] ml-1"></i><?= htmlspecialchars($sf['n']??'فایل') ?> <span class="text-emerald-500">(<?= fsizePHP((int)($sf['s']??0)) ?>)</span></p>
                <?php endforeach; ?>
                <p class="text-[11px] text-emerald-600 mt-0.5 tabular-nums">زمان ثبت: <?= jdatetime((int)$alreadySubmitted['submitted_at']) ?></p>
                <?php endif; ?>
                <p class="text-[11px] text-emerald-600/80 mt-2 leading-relaxed">تا پایان آزمون می‌توانید فایل را <b>جایگزین</b> کنید؛ فقط آخرین فایل به‌عنوان پاسخ نهایی نگه داشته می‌شود.</p>
                <button onclick="showUploader()" class="mt-3 text-xs font-bold text-emerald-700 bg-white border border-emerald-200 rounded-lg px-3 py-1.5 hover:bg-emerald-100 transition"><i class="fa-solid fa-arrows-rotate text-[10px] ml-1"></i>جایگزینی پاسخ</button>
              </div>
            </div>
          </div>

          <!-- فرم بارگذاری -->
          <div id="uploader" class="<?= $alreadySubmitted?'hidden':'' ?>">
            <h3 class="font-extrabold text-lg text-gray-800 mb-1"><i class="fa-solid fa-cloud-arrow-up text-blue-500 ml-1.5"></i><span id="uploader-title">بارگذاری پاسخ نهایی</span></h3>

            <!-- توضیح فایل‌ها -->
            <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 my-3 text-[11px] text-amber-800 leading-relaxed flex gap-2">
              <i class="fa-solid fa-circle-info text-amber-500 mt-0.5"></i>
              <span>فایل‌های انتخابی به‌عنوان <b>پاسخ نهایی</b> شما ثبت می‌شوند و با ارسال مجدد، جایگزین می‌گردند.<?php if($maxFiles>1): ?> می‌توانید تا <b><?= toPersianNumPHP($maxFiles) ?> فایل</b> اضافه کنید.<?php else: ?> فقط <b>یک فایل</b> قابل ارسال است.<?php endif; ?></span>
            </div>

            <p class="text-xs text-gray-500 mb-4">حداکثر حجم هر فایل: <span class="font-bold tabular-nums"><?= toPersianNumPHP($c['max_file_mb']) ?> مگابایت</span> — فرمت‌های مجاز: <span class="font-bold" dir="ltr"><?= htmlspecialchars($c['allowed_types']) ?></span></p>

            <div id="files-list" class="space-y-2"></div>

            <?php if($maxFiles>1): ?>
            <button type="button" id="add-file-btn" onclick="addFileRow()" class="mt-3 w-full py-2.5 rounded-xl border-2 border-dashed border-gray-200 text-gray-500 font-bold text-sm hover:border-primary hover:text-primary transition flex items-center justify-center gap-2"><i class="fa-solid fa-plus text-xs"></i> افزودن فایل</button>
            <?php endif; ?>

            <button id="btn-upload" onclick="uploadAnswer()" class="mt-5 w-full py-3 rounded-xl bg-emerald-500 text-white font-bold shadow-md hover:bg-emerald-600 transition flex items-center justify-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed" disabled>
              <span class="btn-text">ثبت پاسخ نهایی</span><i class="fa-solid fa-paper-plane btn-icon text-xs"></i><div class="loader"></div>
            </button>
          </div>

        </div>
      </div>
    </div>
  </div>
</main>

<script src="<?= asset('assets/js/app.js') ?>"></script>
<script>
const EXAM_START=<?= (int)$c['exam_start'] ?>, EXAM_END=<?= (int)$c['exam_end'] ?>, COURSE_ID=<?= (int)$cid ?>;
const HAS_SUBMISSION=<?= $alreadySubmitted?'true':'false' ?>;
const OVER_SUBMITTED=<?= json_encode(setting('exam_over_submitted_msg','پاسخ شما با موفقیت ثبت شده و مهلت آزمون به پایان رسیده است.'), JSON_UNESCAPED_UNICODE) ?>;
const OVER_NOSUBMIT=<?= json_encode(setting('exam_over_nosubmit_msg','مهلت آزمون به پایان رسیده و پاسخی از شما ثبت نشده است.'), JSON_UNESCAPED_UNICODE) ?>;
const ribbon=document.getElementById('ribbon-timer'),countdown=document.getElementById('countdown');
const locked=document.getElementById('exam-locked'),active=document.getElementById('exam-active');
const MAX_FILES=<?= (int)$maxFiles ?>;
const filesList=document.getElementById('files-list');
const rows=new Map(); let rowSeq=0;

function fmt(sec){const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;
  return toPersianNum(`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`);}
function fsize(b){const u=['B','KB','MB','GB'];let i=0;while(b>=1024&&i<3){b/=1024;i++;}return toPersianNum((Math.round(b*10)/10)+' '+u[i]);}

function renderExam(){
  const now=Math.floor(serverNow().getTime()/1000);
  const trLabel=document.getElementById('tr-label');
  if(now < EXAM_START-300){
    locked.classList.remove('hidden');active.classList.add('hidden');
    ribbon.className='timer-ribbon';
    trLabel.textContent='تا شروع آزمون';countdown.textContent=fmt(EXAM_START-now);
    document.getElementById('lock-msg').textContent='آزمون هنوز فعال نشده است.';
  } else if(now<=EXAM_END){
    locked.classList.add('hidden');active.classList.remove('hidden');
    const left=EXAM_END-now;
    ribbon.className='timer-ribbon '+(left<300?'danger':'');
    trLabel.textContent='زمان باقی‌مانده';countdown.textContent=fmt(left);
  } else {
    active.classList.add('hidden');locked.classList.remove('hidden');
    ribbon.className='timer-ribbon danger';
    trLabel.textContent='پایان آزمون';countdown.textContent='۰۰:۰۰:۰۰';
    document.getElementById('lock-icon').className='w-16 h-16 rounded-full '+(HAS_SUBMISSION?'bg-emerald-50 text-emerald-500':'bg-red-50 text-red-500')+' flex items-center justify-center text-2xl mx-auto mb-4';
    document.getElementById('lock-icon').innerHTML='<i class="fa-solid '+(HAS_SUBMISSION?'fa-circle-check':'fa-circle-xmark')+'"></i>';
    document.getElementById('lock-msg').textContent = HAS_SUBMISSION ? OVER_SUBMITTED : OVER_NOSUBMIT;
  }
}

// نمایش فرم بارگذاری برای جایگزینی
function showUploader(){
  document.getElementById('uploader').classList.remove('hidden');
  document.getElementById('uploader-title').textContent='جایگزینی پاسخ نهایی';
  document.getElementById('uploader').scrollIntoView({behavior:'smooth'});
}

function fileRowMarkup(){
  return '<div class="flex items-center gap-2">'
    +'<button type="button" class="pick flex-1 min-w-0 text-right flex items-center gap-2 px-2 py-2 rounded-lg hover:bg-white transition">'
    +'<span class="w-8 h-8 rounded-lg bg-blue-50 text-primary flex items-center justify-center shrink-0"><i class="fa-solid fa-paperclip text-xs"></i></span>'
    +'<span class="nm text-xs font-bold text-gray-500 truncate">برای انتخاب فایل کلیک کنید</span>'
    +'<span class="sz text-[10px] text-gray-400 tabular-nums shrink-0 mr-auto"></span></button>'
    +'<button type="button" class="rm w-8 h-8 rounded-lg bg-white border border-gray-200 text-gray-400 hover:text-red-500 flex items-center justify-center shrink-0"><i class="fa-solid fa-xmark text-xs"></i></button>'
    +'<input type="file" class="hidden"></div>';
}
function addFileRow(){
  if(rows.size>=MAX_FILES){ showToast('حداکثر تعداد فایل اضافه شده است.'); return; }
  const id=++rowSeq;
  const wrap=document.createElement('div');
  wrap.className='border border-gray-100 rounded-xl p-1.5 bg-gray-50/40';
  wrap.innerHTML=fileRowMarkup();
  const inp=wrap.querySelector('input'), nm=wrap.querySelector('.nm'), sz=wrap.querySelector('.sz');
  wrap.querySelector('.pick').onclick=()=>inp.click();
  inp.addEventListener('change',()=>{
    if(inp.files[0]){ nm.textContent=inp.files[0].name; nm.classList.remove('text-gray-500'); nm.classList.add('text-gray-700'); sz.textContent=fsize(inp.files[0].size); }
    refreshBtn();
  });
  wrap.querySelector('.rm').onclick=()=>{ rows.delete(id); wrap.remove(); ensureAtLeastOne(); refreshBtn(); updateAddBtn(); };
  rows.set(id,inp); filesList.appendChild(wrap); updateAddBtn();
}
function ensureAtLeastOne(){ if(rows.size===0) addFileRow(); }
function updateAddBtn(){ const b=document.getElementById('add-file-btn'); if(b) b.style.display = rows.size>=MAX_FILES?'none':'flex'; }
function selectedFiles(){ const a=[]; rows.forEach(inp=>{ if(inp.files[0]) a.push(inp.files[0]); }); return a; }
function refreshBtn(){ document.getElementById('btn-upload').disabled = selectedFiles().length===0; }
addFileRow(); // ردیف اول

async function uploadAnswer(){
  const files=selectedFiles();
  if(files.length===0){showToast('حداقل یک فایل انتخاب کنید.');return;}
  let ok=true;
  if(typeof confirmDialog==='function'){
    ok = await confirmDialog({
      title: HAS_SUBMISSION ? 'جایگزینی پاسخ نهایی' : 'ثبت پاسخ نهایی',
      text: 'تعداد '+toPersianNum(files.length)+' فایل به‌عنوان پاسخ نهایی شما ثبت می‌شود.'
        + (HAS_SUBMISSION?' پاسخ قبلی جایگزین خواهد شد.':'') + ' تا پایان آزمون امکان جایگزینی وجود دارد.',
      okText: HAS_SUBMISSION ? 'جایگزین کن' : 'ثبت نهایی',
      cancelText: 'بازگشت', variant: 'success'
    });
  }
  if(!ok) return;
  const btn=document.getElementById('btn-upload');btn.classList.add('btn-loading');btn.disabled=true;
  const fd=new FormData();fd.append('course_id',COURSE_ID);
  files.forEach(f=>fd.append('answer[]',f));
  try{
    const token=document.querySelector('meta[name="csrf-token"]').content;
    const r=await fetch('api/upload-answer.php',{method:'POST',headers:{'X-CSRF-Token':token},body:fd});
    const j=await r.json();
    if(!j.ok){showToast(j.message||'خطا در ارسال.');btn.disabled=false;return;}
    showToast(j.message,'success');
    setTimeout(()=>location.reload(),1400);
  }catch(e){showToast('خطا در ارتباط با سرور.');btn.disabled=false;}
  finally{btn.classList.remove('btn-loading');}
}

syncServerClock().then(()=>{renderExam();setInterval(renderExam,1000);});
</script>
</body>
</html>
