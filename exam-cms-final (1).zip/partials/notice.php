<?php
/* صفحه‌ی پیام (مثلاً وقتی ورود یا ثبت‌نام غیرفعال است)
   متغیرها: $notice (متن پیام)، $notice_title (اختیاری)، $page_title */
$notice = $notice ?? 'این بخش موقتاً در دسترس نیست.';
$notice_title = $notice_title ?? 'دسترسی غیرفعال است';
$page_title = $page_title ?? setting('site_name','پورتال آموزشی');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<?php require __DIR__.'/header-student.php'; ?>
<main class="flex-1 flex items-center justify-center px-4 pt-14">
  <div class="w-full max-w-md text-center fade-in py-12">
    <div class="w-20 h-20 bg-amber-50 text-amber-500 rounded-3xl flex items-center justify-center text-3xl mx-auto mb-6 border border-amber-100"><i class="fa-solid fa-lock"></i></div>
    <h1 class="font-extrablack text-2xl text-gray-800 tracking-tight"><?= htmlspecialchars($notice_title) ?></h1>
    <p class="text-sm text-gray-500 mt-4 leading-relaxed text-justify"><?= nl2br(htmlspecialchars($notice)) ?></p>
    <a href="<?= base_url() ?>" class="inline-flex items-center gap-2 mt-8 px-6 py-3 rounded-xl bg-white border border-gray-200 text-gray-700 font-bold hover:bg-gray-50 transition"><i class="fa-solid fa-house text-xs"></i> بازگشت به صفحه‌ی اصلی</a>
  </div>
</main>
<script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>
