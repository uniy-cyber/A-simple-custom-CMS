<?php /* پارشال هد مشترک — متغیر $page_title قابل تنظیم است */ ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?= htmlspecialchars(csrf_token()) ?>">
<title><?= htmlspecialchars($page_title ?? 'پورتال آزمون آنلاین') ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="<?= asset('assets/css/app.css') ?>">
<script>window.APP_BASE = "<?= base_url() ?>";</script>
<script>
tailwind.config = { theme: { extend: {
  colors: { primary: { DEFAULT:'#1e3a8a', light:'#dbeafe' }, accent: { DEFAULT:'#f59e0b', light:'#fef3c7' } },
  fontWeight: { thin:'100', extralight:'200', light:'300', normal:'400', medium:'500', semibold:'600', bold:'700', extrabold:'800', black:'900', extrablack:'950' }
}}};
</script>
