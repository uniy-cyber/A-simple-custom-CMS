<?php /* هدر شیشه‌ای دانشجو */ $s = current_student(); ?>
<header class="glass-header fixed top-0 inset-x-0 h-14">
  <div class="max-w-5xl mx-auto px-4 h-full flex items-center justify-between">
    <a href="<?= base_url('dashboard.php') ?>" class="flex items-center gap-2">
      <div class="w-8 h-8 rounded-lg bg-primary text-white flex items-center justify-center shadow-sm">
        <i class="fa-solid fa-graduation-cap text-sm"></i>
      </div>
      <h1 class="font-black text-gray-800 text-sm tracking-tight leading-none"><?= htmlspecialchars(setting('site_name','پورتال آموزشی')) ?></h1>
    </a>
    <div class="flex items-center gap-3">
      <div class="hidden sm:flex bg-gray-50/80 px-2 py-1 rounded border border-gray-100 items-center gap-1.5 shadow-sm">
        <i class="fa-solid fa-server text-blue-500 text-[9px]"></i>
        <span class="js-clock tabular-nums font-medium text-[11px] text-gray-600 leading-none" dir="ltr">--:--:--</span>
      </div>
      <?php if ($s): ?>
      <?php $unread=0; try { $unread=(int)(DB::one("SELECT COUNT(*) n FROM notifications WHERE student_id=? AND is_read=0",[$s['id']])['n'] ?? 0); } catch (Throwable $e) {} ?>
      <a href="<?= base_url('notifications.php') ?>" class="relative w-9 h-9 flex items-center justify-center rounded-md bg-blue-50 text-blue-600 hover:bg-blue-100 transition shadow-sm" title="اعلان‌ها">
        <i class="fa-solid fa-bell text-xs"></i>
        <?php if($unread>0): ?><span class="absolute -top-1.5 -left-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-black flex items-center justify-center tabular-nums"><?= $unread>99?'۹۹+':pnum($unread) ?></span><?php endif; ?>
      </a>
      <a href="<?= base_url('transcript.php') ?>" class="h-9 px-2.5 flex items-center gap-1.5 rounded-md bg-amber-50 text-amber-600 hover:bg-amber-100 transition shadow-sm text-[11px] font-bold" title="کارنامه">
        <i class="fa-solid fa-file-lines text-xs"></i><span class="hidden sm:inline">کارنامه</span>
      </a>
      <a href="<?= base_url('activity.php') ?>" class="w-9 h-9 flex items-center justify-center rounded-md bg-gray-50 text-gray-500 hover:bg-gray-100 transition shadow-sm" title="فعالیت‌های من">
        <i class="fa-solid fa-timeline text-xs"></i>
      </a>
      <a href="<?= base_url('logout.php') ?>" class="w-9 h-9 flex items-center justify-center rounded-md bg-red-50 text-red-500 hover:bg-red-100 transition shadow-sm" title="خروج">
        <i class="fa-solid fa-right-from-bracket text-xs"></i>
      </a>
      <?php endif; ?>
    </div>
  </div>
</header>
<!-- نوار ساعت چسبیده زیر هدر — فقط موبایل و فقط در پنل دانشجو (ارتفاع ۲۴px هماهنگ با pt-20) -->
<?php if ($s): ?>
<div class="sm:hidden fixed top-14 inset-x-0 h-6 z-30 bg-white/85 backdrop-blur border-b border-gray-100 flex items-center justify-center gap-1.5">
  <i class="fa-solid fa-server text-blue-500 text-[9px]"></i>
  <span class="text-[10px] text-gray-400 font-bold">ساعت سرور</span>
  <span class="js-clock tabular-nums font-extrabold text-[11px] text-gray-700 leading-none" dir="ltr">--:--:--</span>
</div>
<?php endif; ?>
