<?php
/* دانلود امن فایل‌های پیوست اطلاعیه‌ها (سمت دانشجو) — با کنترل دسترسی و شمارش دانلود */
require __DIR__.'/includes/bootstrap.php';
$s = require_student();
$now = ServerTime::now();

$fid = (int)($_GET['f'] ?? 0);
$file = DB::one("SELECT af.*, a.publish_at, a.course_id
                 FROM announcement_files af
                 JOIN announcements a ON a.id = af.announcement_id
                 WHERE af.id=?", [$fid]);
if (!$file) { http_response_code(404); die('فایل یافت نشد.'); }

/* اطلاعیه باید منتشر شده باشد */
if ((int)$file['publish_at'] > $now) { http_response_code(403); die('این فایل هنوز در دسترس نیست.'); }

/* اگر اطلاعیه مخصوص یک درس است، دانشجو باید در آن درس ثبت‌نام کرده باشد */
if ($file['course_id'] !== null) {
  $enrolled = DB::one("SELECT id FROM enrollments WHERE student_id=? AND course_id=?", [$s['id'], (int)$file['course_id']]);
  if (!$enrolled) { http_response_code(403); die('شما به این فایل دسترسی ندارید.'); }
}

/* بررسی وجود فیزیکی فایل و جلوگیری از خروج از مسیر مجاز */
$real = realpath(APP_ROOT.'/uploads/'.$file['file_path']);
$base = realpath(APP_ROOT.'/uploads');
if (!$real || strpos($real,$base)!==0 || !is_file($real)) { http_response_code(404); die('فایل روی سرور موجود نیست.'); }

/* شمارش دانلود (بی‌خطر در صورت خطا) */
try { DB::q("UPDATE announcement_files SET download_count = download_count + 1 WHERE id=?", [$fid]); } catch (Throwable $e) {}
log_activity($s['id'],'download','دانلود پیوست اطلاعیه: '.$file['original_name']);

$name = $file['original_name'] ?: basename($real);
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.addslashes($name).'"');
header('Content-Length: '.filesize($real));
header('Cache-Control: must-revalidate'); header('Pragma: public');
readfile($real); exit;
