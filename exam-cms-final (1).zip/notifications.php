<?php
require __DIR__.'/includes/bootstrap.php';
$s = require_student();

// علامت‌گذاری همه به‌عنوان خوانده‌شده
try { DB::q("UPDATE notifications SET is_read=1 WHERE student_id=? AND is_read=0", [$s['id']]); } catch (Throwable $e) {}
$items = [];
try { $items = DB::all("SELECT * FROM notifications WHERE student_id=? ORDER BY id DESC LIMIT 100", [$s['id']]); } catch (Throwable $e) {}

$page_title='اعلان‌ها - '.setting('site_name','پورتال آموزشی');
$icon=['grade'=>['fa-award','text-emerald-500 bg-emerald-50'],'appeal'=>['fa-gavel','text-amber-500 bg-amber-50'],'info'=>['fa-bell','text-blue-500 bg-blue-50']];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<div id="toast-container"></div>
<?php require __DIR__.'/partials/header-student.php'; ?>

<main class="flex-1 pt-20 pb-10 px-4">
  <div class="max-w-2xl mx-auto fade-in">
    <div class="flex items-end justify-between mb-5">
      <div>
        <h2 class="font-extrablack text-xl md:text-2xl text-gray-800 tracking-tight"><i class="fa-solid fa-bell text-blue-500 ml-2"></i>اعلان‌ها</h2>
        <p class="text-xs text-gray-500 mt-1">رویدادهای مربوط به نمرات و اعتراض‌های شما</p>
      </div>
      <a href="<?= base_url('dashboard.php') ?>" class="text-[11px] font-bold text-gray-500 hover:text-gray-700"><i class="fa-solid fa-arrow-right text-[9px]"></i> داشبورد</a>
    </div>

    <?php if(!$items): ?>
      <div class="card-modern p-10 text-center text-sm text-gray-400"><i class="fa-regular fa-bell-slash text-3xl mb-3 block"></i>اعلانی وجود ندارد.</div>
    <?php else: ?>
      <div class="space-y-2">
      <?php foreach($items as $n): $ic=$icon[$n['type']]??$icon['info']; ?>
        <div class="card-modern p-4 flex items-start gap-3">
          <div class="w-10 h-10 rounded-xl <?= $ic[1] ?> flex items-center justify-center shrink-0"><i class="fa-solid <?= $ic[0] ?>"></i></div>
          <div class="min-w-0 flex-1">
            <p class="font-extrabold text-sm text-gray-800"><?= htmlspecialchars($n['title']) ?></p>
            <?php if($n['body']): ?><p class="text-xs text-gray-500 mt-1 leading-relaxed text-justify"><?= nl2br(htmlspecialchars($n['body'])) ?></p><?php endif; ?>
            <p class="text-[10px] text-gray-300 mt-1.5 tabular-nums"><?= jdatetime((int)$n['created_at']) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>
