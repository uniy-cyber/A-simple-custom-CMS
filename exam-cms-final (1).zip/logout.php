<?php
require __DIR__.'/includes/bootstrap.php';
$_SESSION=[]; session_destroy();
header('Location: '.base_url('login.php')); exit;
