<?php
require __DIR__.'/includes/bootstrap.php';
if (current_student()) { header('Location: '.base_url('dashboard.php')); exit; }
$page_title = setting('site_name','پورتال آموزشی').' - سامانه آزمون آنلاین';

$heroTitle = setting('home_hero_title','سامانه‌ی جامع آزمون آنلاین');
$heroSub   = setting('home_hero_subtitle','برگزاری امن آزمون‌های پایان ترم با کنترل زمان سرور، احراز هویت پیامکی و بارگذاری پاسخ‌ها.');
$cards = json_decode(setting('home_cards',''), true);
if(!is_array($cards)||!$cards) $cards=[['fa-shield-halved','کنترل زمان سرور'],['fa-comment-sms','تایید پیامکی OTP'],['fa-file-shield','بارگذاری امن'],['fa-bullhorn','تایم‌لاین اطلاعیه']];
$loginOn = setting('login_enabled','1')==='1';
$regOn   = setting('register_enabled','1')==='1';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><?php require __DIR__.'/partials/head.php'; ?></head>
<body class="flex flex-col min-h-screen">
<?php require __DIR__.'/partials/header-student.php'; ?>
<main class="flex-1 flex items-center justify-center px-4 pt-14">
  <div class="w-full max-w-2xl text-center fade-in py-12">
    <div class="w-20 h-20 bg-blue-50 text-primary rounded-3xl flex items-center justify-center text-3xl mx-auto mb-6 border border-blue-100"><i class="fa-solid fa-graduation-cap"></i></div>
    <h1 class="font-extrablack text-3xl md:text-4xl text-gray-800 tracking-tight"><?= htmlspecialchars($heroTitle) ?></h1>
    <p class="text-sm text-gray-500 mt-4 leading-relaxed max-w-lg mx-auto text-justify"><?= htmlspecialchars($heroSub) ?></p>
    <div class="flex flex-col sm:flex-row gap-3 justify-center mt-8">
      <?php if($loginOn): ?>
      <a href="login.php" class="px-8 py-3.5 rounded-xl bg-primary text-white font-bold shadow-md hover:bg-blue-800 transition flex items-center justify-center gap-2"><i class="fa-solid fa-right-to-bracket text-xs"></i> ورود به سیستم</a>
      <?php endif; ?>
      <?php if($regOn): ?>
      <a href="register.php" class="px-8 py-3.5 rounded-xl bg-white border border-gray-200 text-gray-700 font-bold hover:bg-gray-50 transition flex items-center justify-center gap-2"><i class="fa-solid fa-user-plus text-xs"></i> ثبت‌نام دانشجو</a>
      <?php endif; ?>
      <?php if(!$loginOn && !$regOn): ?>
      <p class="text-sm font-bold text-amber-600 bg-amber-50 border border-amber-200 rounded-xl px-5 py-3"><?= htmlspecialchars(setting('login_disabled_msg','دسترسی موقتاً غیرفعال است.')) ?></p>
      <?php endif; ?>
    </div>
    <?php if($cards): ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mt-12 text-right">
      <?php foreach($cards as $f): ?>
      <div class="card-modern p-4">
        <i class="fa-solid <?= htmlspecialchars($f[0]??'fa-circle-dot') ?> text-primary mb-2"></i>
        <p class="text-xs font-bold text-gray-700"><?= htmlspecialchars($f[1]??'') ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</main>
<script src="<?= asset('assets/js/app.js') ?>"></script>
</body>
</html>
